# GAMMALN state at 2026-07-11 session end (run 2)

SUPERSEDES the earlier Cephes-store-mask plan. Full evidence:
docs/function-lane/W109_GAMMALN_IDENTIFICATION_20260711.md

IDENTIFIED: x >= 11 -> plain-double Cephes lgam Stirling tail + UCRT-class
log (136/139; 3 rows are internal-log ULP deltas at 11.3, 12.75, 91.608499).
Boundary in (10.25, 11.0]. The old 83/83 x87-staged fit was an over-fit —
dense 10-13.5 probes killed it.

OPEN: (0,11) core = custom Microsoft rational. ALL public libraries ruled
out (see evidence doc table). Plan:
1. Bisect the Stirling boundary live (~40 probes).
2. Identify internal CRT log from Stirling-region bracketing constraints.
3. Recover custom kernel coefficients: map band edges from the
   ULP-error-vs-true curve (already have 0.02/0.04 grids; densify per
   edge), then integer-relation fit of anchored rational forms per band.
4. Then: gammaln promotion -> GAMMA (exp composition + sin reflection) ->
   COMBIN -> G3-01 re-race.

Corpus: answers-gammaln.json (79) + ../G4-04-combin/answers-gammaln.json
(14) + answers-r2.json (274 dense). GAMMA: answers-r0.json (156).
