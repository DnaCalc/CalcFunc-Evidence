# Ruled-out / negative cubes — lastbit-12h firehorse

Constraint notes only. Not closed. Not landed.

| when | cube | result |
|---|---|---|
| (pending) | leftover `lentz/as714/n12b2` | still running |
| 2026-09-12T01:21 | `cephes/pq` 17-bit | HIT not ruled out. mid 2451 `0x0509`, tail 1355 `0x5005`. Native cephes 1883/1156. x87 mask0 2409/1283. Constraint. |
| 2026-09-12T01:25 | compose NSWC+Cephes frozen masks | HIT mid **2686** `0x0509` cut=1.0; tail **1370** `0x5005` cut=4.9; dmid 91. Two graphs. Do not land. |
| 2026-09-12T01:26 | `math77/erc2/n16` | finished 2^16, no leader move. R0 mask0 492/0. Truncated Chebyshev not the body. |
| 2026-09-12T01:28 | `math77/erfcc/n16` | finished 2^16, no leader move. Same. |
| 2026-09-12T01:31 | `pmid/cephes/c10` | 17-bit stores, NSWC z<1.0. No mask beat frozen `0x0509` (2686). Cut=1.0 mid leader stays compose mask. |
| 2026-09-12T01:33 | `pmid/cephes/c16` | NSWC z<1.6 × Cephes 17-bit. No beat of 2686/1370. |
| 2026-09-12T01:35 | `pmid/cephes/c15` | NSWC z<1.5 × Cephes 17-bit. No beat of 2686/1370. |
| 2026-09-12T01:38 | `pmid/cephes/c20` | NSWC z<2.0 × Cephes 17-bit. No beat of 2686/1370. |
| 2026-09-12T01:40 | `ptail/cephes/c49` | NSWC z<4.9 × Cephes 17-bit tail. No mask beat frozen `0x5005` (1370). |
| 2026-09-12T01:42 | `p4/cephes/c40` | NSWC z<4.0 × Cephes 17-bit tail. No beat of 2686/1370. |
| 2026-09-12T01:43 | `ptail/cephes/c56` | NSWC z<5.6 × Cephes 17-bit. No beat of 2686/1370. All selected Cephes piecewise 17-bit cubes finished vs compose leaders. |
| 2026-09-12T01:43 | `pmid/as714/n16/c16` | NSWC z<1.6 × CF as714 n=16 den-store. No beat of 2686/1370. |
| 2026-09-12T01:43 | `ptail/as714/n16/c56` | NSWC z<5.6 × CF as714 n=16 den-store. No beat of 2686/1370. |
| 2026-09-12T01:52 | leftover `lentz/as714/n12b2` | 2^24 finished, `exit-regions`. HIT_TAIL still 1324 `lentz/as714/n24 /mask=0400000`. C+D n=12 stores not the identity. |
| 2026-09-12T01:53 | `compose/three` | NSWC+Cephes-mid-mask+Cephes-tail-mask grid. No beat of 2686/1370. Two-piece compose still leads. |
| 2026-09-12T01:54 | `ptail/cody/c49` | NSWC z<4.9 × Cody 16-bit. No tail beat of 1370. |
| 2026-09-12T01:56 | `compose/joint` | Cody-mid + Cephes-tail. Best joint 2976+1363 at cut=5.6. Tail 1363 < 1370. |
| 2026-09-12T01:58 | `cody/n16` global 16-bit | finished 2^16. No mask beat `0x74` (2976 mid). `0x74` is the 16-bit Cody mid leader. |
| 2026-09-12T01:58 | `pmid/as714/n21/c16` partial | skip remaining. cut=1.6 cannot beat Cody 2976 mid or Cephes 1370 tail (cut<4). chunk 0x7e000/0x200000, chunk_best 1224/1287. |
| 2026-09-12T02:01 | `cfacc/as714/n10` partial | skip remaining ~94%. n=10 too short: chunk_best mid=0 tail=855. |
| 2026-09-12T02:03 | `cody/n17` | 17-bit C/D + quotient store. No beat of 2976/1370. Quotient store bit does not improve `0x74`. |
