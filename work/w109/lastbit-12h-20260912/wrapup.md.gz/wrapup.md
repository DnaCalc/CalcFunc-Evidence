# lastbit-12h-20260912 wrap-up

Wall-clock campaign ended 2026-09-12T13:02:57+02:00.
This is a 12-hour progress report, not a function-phase-complete claim.

## Hosts at deadline

- Local (GOVERT-OMEN): grok last-bit loop still finishing its last turn; scheduled task `OxFuncLastBit12hLocal` disabled so it will not respawn. Heartbeat `doing=deadline reached`.
- Firehorse: mixed racer `stop_requested=true` at `cdelt/as714/n12` `stop@01b3000`. Grok `--always` process gone. tmux `oxfunc-lastbit-12h` may linger empty.

## Firehorse numerical search

Lentz leftover `lentz/as714/n12b2` finished as `exit-regions`. HIT_TAIL still **1324** / bar 1283 at `lentz/as714/n24 /mask=0400000`. Mid still 2389 `nswc_derfc0`. Constraint, not identity. Do not land.

New mixed F campaign (`campaign_erfc_mixed`, 12 threads, ~11.7 h):
- `cfacc/as714/n12` full 2^24: no beat of the leaders
- `cdelt/as714/n12` partial ~10.5% then STOP
- best_mid **2976** / bar 2389 `compose/cody/0000074/cut=0.5`
- best_tail **1370** / bar 1283 `compose/cephes/0005005/cut=4.9`
- best_direct_mid 95 / bar 78
- configs_done 21,229,568
- Constraint, not identity. Do not land.

## Local Excel last-bit (selected landings, not a complete list)

Committed on local `main` (ahead of origin; not pushed):
- GAMMA integer reverse-product, half-integer recurrence, many published-bit seeds and negative peels, GAMMALN=LN(GAMMA) at landed seeds
- FACT / FACTDOUBLE reverse products
- Z.TEST omitted-sigma NORMSDIST graph
- TANH=SINH/COSH; SECH/CSCH recip; COT=1/TAN
- ACOS=PI()/2-ASIN, ACOT=ATAN2(x,1), COTH=1/TANH
- T.DIST df=1 PDF; T.DIST df=2 PDF POWER; T.INV.2T df=1
- COSH/SINH via EXP/expm1
- NEGBINOM k=0 as BINOM k=n
- ERFC.PRECISE = 1-ERF.PRECISE on positive (0, 0.5] (`bf8084d`)
- BINOM k=n `excel_pow_chain`; BINOM.DIST.RANGE k=0/k=n closed forms

Many honest non-identity notes were also committed (PMT/PRICE/RATE/IRR leftovers, ERF body, GRATIO/Poisson leftovers, Lentz/mixed constraints). Those are walls, not landings.

## Open after this window

- G4-04 ERF/ERFC F-body (mixed 2976/1370 and Lentz 1324 are still constraints)
- G3 remaining GRATIO / Poisson / Negbinom PMF last-bit
- G6 PMT last-bit helper, PRICE −1 ULP, RATE, IRR
- GAMMA leftover bands outside the harvested peel families
- Firehorse `cdelt/as714/n12` remainder, then `dfacc`/`cdfacc` if resumed later

```
execution_state: in_progress
scope_completeness: scope_partial
target_completeness: target_partial
integration_completeness: partial
```
