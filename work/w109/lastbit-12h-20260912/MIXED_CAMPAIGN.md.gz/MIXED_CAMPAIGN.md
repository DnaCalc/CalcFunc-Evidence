# Mixed F-body campaign (firehorse lastbit-12h)

Not an identity. Not landed. Resume-safe binary:
`smart-fuzzer/tools/calc_graph_racer/src/bin/campaign_erfc_mixed.rs`

Out: `smart-fuzzer/work/w109/erfc-mixed-campaign/`

## Why this cube family

Selected Lentz n24 / F-body CF / NSWC PQR 26-bit cubes are exhausted.
This campaign searches axes those cubes did not:

1. Piecewise NSWC below a cut, CF as714 den-store above (`pmid`/`ptail`).
   Global CF store cubes never scored NSWC-on-low-z + stored-CF-on-high-z.
2. Mixed C / D / Facc / delta Lentz stores (`cfacc`, `dfacc`, `cdelt`, `cdfacc`).
   Leftover `lentz/as714/n12b2` is C+D only; facc was never an independent site.
3. Cephes erfce P/Q and MATH77 dcsevl b0 stores (x87).
4. Direct vs implied-Q split scoring (merged bars stay 2389/1283).

## Cube order

R0 named + native piece cuts + compose with HIT_TAIL graphs, then
`cephes/pq`, `math77/erc2/n16`, `math77/erfcc/n16`,
`pmid/as714/n16/c16`, `ptail/as714/n16/c56`,
`pmid/as714/n21/c16`, `ptail/as714/n21/c56`, `ptail/as714/n21/c49`,
`ptail/as714/n21/c62`, `cfacc/as714/n10`, `cfacc/as714/n12`,
`cdelt/as714/n12`, `dfacc/as714/n12`, `cdfacc/as714/n8`,
`cfacc/gaut/n12`, `cdfacc/gaut/n8`.

Threads: leftover n12b2 finished. Mixed at 12 threads. n21/c16 and cfacc n10 skipped as low-EV. `cody/n17` then `cfacc/as714/n12` 24-bit.

## Live leaders (constraint, not identity)

| kind | exact | graph |
|---|---:|---|
| merged mid | **2976** / bar 2389 | `compose/cody/0000074/cut=0.5` (global Cody `0x74`) |
| merged tail | 1370 / bar 1283 | `compose/cephes/0005005/cut=4.9` |
| direct mid | **92** / bar 78 | `pmid/cody/c10 /mask=0000210` |
| direct tail | 39 / bar 30 | `cephes/pq /mask=00024a5` |

Do not land. Direct ERFC.PRECISE still 91/226 mid, 39/124 tail.
