# Mixed F campaign STATUS

- region: `cfacc/as714/n12`
- chunk: `0022000`
- configs_done: 2416640
- best_mid: 2976 / bar 2389 `compose/cody/0000074/cut=0.5`
- best_tail: 1370 / bar 1283 `compose/cephes/0005005/cut=4.9`
- best_direct_mid: 95 / bar 78 `compose/cody/0000210/cut=0.9`
- best_direct_tail: 39 / bar 30 `cephes/pq /mask=00024a5`
- runtime_hours: 0.79 / 14
- threads: 12
- stop_requested: false

x87 lentz as714 n=12 24-bit cfacc stores
chunk_best_mid=0 tail=951 dmid=0

# Mixed F campaign REGION_MAP

| id | space | next | note |
|---|---|---|---|
| cephes/pq | 0..0x0020000 | done | x87 Cephes erfce P/Q (ax<8) R/S (ax>=8) Horner+div stores |
| cody/n16 | 0..0x0010000 | done | x87 Cody C/D Horner stores, no NSWC cut (global F) |
| cody/n17 | 0..0x0020000 | done | x87 Cody C/D Horner + quotient store (17-bit global F) |
| math77/erc2/n16 | 0..0x0010000 | done | x87 MATH77 dcsevl ERC2CS n=16 b0-store (ysq<=4) |
| math77/erfcc/n16 | 0..0x0010000 | done | x87 MATH77 dcsevl ERFCCS n=16 b0-store (ysq>4) |
| pmid/cephes/c10 | 0..0x0020000 | done | NSWC z<1 else x87 Cephes P/Q Horner+div stores |
| pmid/cephes/c16 | 0..0x0020000 | done | NSWC z<1.6 else x87 Cephes P/Q Horner+div stores |
| pmid/cephes/c15 | 0..0x0020000 | done | NSWC z<1.5 else x87 Cephes P/Q Horner+div stores |
| pmid/cephes/c20 | 0..0x0020000 | done | NSWC z<2 else x87 Cephes P/Q Horner+div stores |
| ptail/cephes/c49 | 0..0x0020000 | done | NSWC z<4.9 else x87 Cephes P/Q Horner+div stores |
| p4/cephes/c40 | 0..0x0020000 | done | NSWC z<4 else x87 Cephes P/Q Horner+div stores |
| ptail/cephes/c56 | 0..0x0020000 | done | NSWC z<5.6 else x87 Cephes P/Q Horner+div stores |
| pmid/cody/c10 | 0..0x0010000 | done | NSWC z<1 else x87 Cody C/D Horner stores |
| ptail/cody/c49 | 0..0x0010000 | done | NSWC z<4.9 else x87 Cody C/D Horner stores |
| pmid/as714/n16/c16 | 0..0x0010000 | done | NSWC z<1.6 else x87 CF as714 n=16 den-store |
| ptail/as714/n16/c56 | 0..0x0010000 | done | NSWC z<5.6 else x87 CF as714 n=16 den-store |
| pmid/as714/n21/c16 | 0..0x0200000 | 0x008d000/0x0200000 | NSWC z<1.6 else x87 CF as714 n=21 den-store |
| ptail/as714/n21/c56 | 0..0x0200000 | 0x0000000/0x0200000 | NSWC z<5.6 else x87 CF as714 n=21 den-store |
| ptail/as714/n21/c49 | 0..0x0200000 | 0x0000000/0x0200000 | NSWC z<4.9 else x87 CF as714 n=21 den-store |
| ptail/as714/n21/c62 | 0..0x0200000 | 0x0000000/0x0200000 | NSWC z<6.2 else x87 CF as714 n=21 den-store |
| cfacc/as714/n10 | 0..0x0100000 | 0x000f000/0x0100000 | x87 lentz as714 n=10 20-bit cfacc stores |
| cfacc/as714/n12 | 0..0x1000000 | 0x0022000/0x1000000 | x87 lentz as714 n=12 24-bit cfacc stores |
| cdelt/as714/n12 | 0..0x1000000 | 0x0000000/0x1000000 | x87 lentz as714 n=12 24-bit cdelt stores |
| dfacc/as714/n12 | 0..0x1000000 | 0x0000000/0x1000000 | x87 lentz as714 n=12 24-bit dfacc stores |
| cdfacc/as714/n8 | 0..0x1000000 | 0x0000000/0x1000000 | x87 lentz as714 n=8 24-bit cdfacc stores |
| cfacc/gaut/n12 | 0..0x1000000 | 0x0000000/0x1000000 | x87 lentz gaut n=12 24-bit cfacc stores |
| cdfacc/gaut/n8 | 0..0x1000000 | 0x0000000/0x1000000 | x87 lentz gaut n=8 24-bit cdfacc stores |

best_mid 2976 / bar 2389 `compose/cody/0000074/cut=0.5`
best_tail 1370 / bar 1283 `compose/cephes/0005005/cut=4.9`
best_direct_mid 95 / bar 78 `compose/cody/0000210/cut=0.9`
best_direct_tail 39 / bar 30 `cephes/pq /mask=00024a5`

