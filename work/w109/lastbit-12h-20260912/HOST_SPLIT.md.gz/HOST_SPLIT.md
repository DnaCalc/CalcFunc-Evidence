# Last-bit 12h campaign — host split

Started: 2026-09-12T01:02:57+02:00
Deadline: 2026-09-12T13:02:57+02:00
Campaign id: `lastbit-12h-20260912`

This is a 12-hour last-bit OxFunc↔Excel matching campaign on two machines.
It is in-progress work. Do not claim function-phase-complete, implemented,
closed, or done for any partial subset.

## Hosts

| Host | Role |
|---|---|
| `GOVERT-OMEN` (this Windows box) | Live Excel oracle, kernel landing, catalog/tests, G3/G6 last-bit identification |
| `dna-firehorse` (16-vCPU AMD EPYC KVM) | Offline x87 store-mask / racer cubes, new campaign bins, no Excel |

## File ownership (avoid collisions)

- Local owns: `crates/oxfunc_core/**`, `crates/oxfunc_value_types/**`, `docs/OXFUNC_EXCEL_DISCREPANCY_CATALOG.md`, `docs/function-lane/DISCREPANCY_*.csv`, `docs/function-lane/W109_WALL_CLUES_LEDGER.md`, tests that pin production kernels.
- Firehorse owns: `smart-fuzzer/tools/calc_graph_racer/src/bin/campaign_*`, new racer bins, `smart-fuzzer/work/w109/**` on that machine.
- Shared read-only: catalog, wall clues, GPT56 campaign prompt, W109 method docs.
- Do not `git push`. Local commits only after independently verified closures or reusable machinery. Firehorse may commit racer-bin/docs machinery locally; do not rewrite production kernels unless a graph is exact on a repo-owned corpus and local is not editing the same file.
- Preserve the existing uncommitted rustfmt-only diffs on local `acosh.rs` / `acoth.rs` / `asinh.rs` / `beta_gamma_stats_family.rs` / `chi_f_t_family.rs` / `discrete_dist_family.rs`.

## Firehorse state at launch (2026-09-12)

OxFunc git: `024020d` (one commit behind local `3e3ebb4`). Load ~0.1. No racer running.
tmux: only idle `DemiSeek`.

ERFC Lentz campaign: selected n24 cubes finished (`exit-regions`).
- configs_done: 104,747,008
- best_mid: 2389 / bar 2389 `nswc_derfc0`
- best_tail: **1324** / bar 1283 `lentz/as714/n24 /mask=0400000`
- HIT_TAIL written. Constraint, not identity. Do not land.
- Leftover: `lentz/as714/n12b2` at `0x0f92000/0x1000000` (~438k configs). Resume with `--max-hours 400` because original `started_unix` already exceeded 120h.
- `mlentz/as714/n12b2` was skipped as duplicate/low-EV.

F-body CF cubes: all selected cubes finished. Leaders still 2416/1294 piecewise cuts.
Original ERFC body 26-bit PQR cubes: exhausted. Do not restart them.

## Local state at launch

Uncommitted rustfmt-only diffs in hyperbolic/stats families. Leave them.
Live Excel is the unique resource. Use Value2 cell injection, never long decimal literals.

Open Category-2 catalog still has 16 rows. Highest last-bit leverage:
1. G4-04 leftover ERF.PRECISE / ERFC.PRECISE F-body (inherits GAUSS/NORMSDIST/CHIDIST df=1).
2. G3-01 remaining GRATIO / Poisson / Negbinom PMF last-bit.
3. G6-01 PMT last-bit helper; G6-03d PRICE −1 ULP residual; G6-05 RATE; G6-06 IRR.
4. G3-02 GAMMA/GAMMALN remaining bands.

## Heartbeats

Write JSON heartbeats at least every 20 minutes of wall clock:

- Local: `smart-fuzzer/work/w109/lastbit-12h-20260912/heartbeat-local.json`
- Firehorse: same relative path on that clone

Schema:

```json
{
  "host": "local|firehorse",
  "unix": 0,
  "iso": "",
  "hours_left": 0,
  "doing": "",
  "last_result": "",
  "open_next": "",
  "pid": 0
}
```
