# W109 — YIELD/ODDFYIELD: bond forward-kernel (PRICE) identified (2026-07-13)

## The plan's premise was WRONG
The dive plan assumed the forward `pcomp` price kernel was already bit-exact, so YIELD
would be "100% schedule." **It is not.** OxFunc's `pcomp` at yld=0.05 for the par bond
gives `0x4059000000000002` (100.00000000000003), but live Excel PRICE gives
`0x4059000000000000` (**exactly 100**). The 6/19-ULP YIELD drift traces to a forward-kernel
rounding difference, not (only) the schedule.

## Root cause: integer discount-factor powers
`pcomp` computes each discount factor as `base.powf(off + k)`. Rust's `f64::powf` evaluates
`exp·ln` even for **integer** exponents. Excel's bond code (ATP / C-runtime `pow`) uses the
**integer-exponent special case = binary exponentiation (square-and-multiply)**. For an
on-coupon bond (settle on a coupon date) `off = dsc/e = 1.0`, so every exponent `off+k` is a
positive integer and the whole discount ladder is binexp-multiply — which `powf` does not
reproduce.

## Identification (held-out validated)
Full-kernel race over 5 bonds / 25 live-Excel PRICE points (build 20131, AMD 4800H):
- **A_n3** on-coupon short (n=3), **B_frac** fractional-off, **C_n15** on-coupon long (n=15)
  = identification set (15 pts).
- **D_ho** (rate 7.5%, red 102, n=17), **E_ho** (fractional, rate 6%, red 103) = held-out (10 pts).

Winner: **`int=binexp-mul, coup-first`  →  15/15 identification AND 10/10 held-out.**
- Integer exponent → **binary exponentiation** (square-and-multiply, plain f64 multiply).
- Fractional exponent → `powf` (== x87 `exp·ln`; the two are indistinguishable on all 25 pts).
- Summation: **coupons ascending, then + redemption, − accrual** (pcomp's existing order).
- Add/div arithmetic: SSE vs x87 **indistinguishable** on all 25 pts (both 25/25).

Ruled out (held-out scores): naive left-to-right multiply `5/10` (fails n≥4 exponents),
`powf` integer `6/10`, x87 `exp·ln` integer `6/10`, redemption-first (getPrice_) order
`C 2/5`. So it is specifically **square-and-multiply**, not any other integer-power scheme,
and **not** LibreOffice's getPrice_ ordering.

This is exactly the C-runtime `pow(x, n)` integer special case. The fix: replace
`base.powf(exp)` in the bond discount factor with `if exp is a non-negative integer → binexp
double-multiply; else base.powf(exp)`.

## Impact
Shared by PRICE, YIELD (via pcomp), PRICEMAT, DURATION/MDURATION, and the odd-bond kernels
(`oddfprice_kernel`, etc. — not yet re-verified). **PRICE has latent binexp drift on
on-coupon bonds** that was never caught (no on-coupon integer-exponent PRICE witness in the
catalog): `pcomp` scored only 3/5 on the A ladder.

## YIELD residual = plateau publication (Phase-4 schedule, still open)
With the corrected (binexp) price, PRICE is flat at **exactly 95** across a yield band
`0x3fb61465bd6a9970` … `0x3fb61465bd6a9984` (all map to price 95 bit-exactly). Excel's
YIELD-catalog answer `0x3fb61465bd6a9983` sits **inside** this flat plateau, and YIELD-par
returns **exactly 0.05** (`0x3fa999999999999a`). So the remaining residual is purely **which
plateau point Excel's iteration publishes**. My libre false-position over the corrected price
gives catalog `0x…8d`, par `0x…75`; bisection gives `0x…76` / `0x…72` — neither matches
Excel's `0x…83` / exactly-0.05. This is the solver-VM schedule/publication reconstruction.

**COUPLING WARNING:** fixing `pcomp` alone (without the schedule) moves YIELD-par from 6 ULP
to ~40 ULP under the current bisection — the forward fix and the schedule are coupled. Land
them together; do NOT land the pcomp fix in isolation or it regresses YIELD.

## Next steps
1. Land `excel_bond_pow` (binexp integer / powf fractional) in `pcomp` **together with** the
   YIELD schedule fix. Re-verify PRICE bit-exact on all 5 ladders + a fresh held-out.
2. Reconstruct the YIELD schedule/publication (seed, false-position update, exact-price
   early-exit, publication rule) to land on Excel's plateau point + exactly-0.05 par. Needs
   the solver-VM. Capture: yield-vs-price plateau edges, par short-circuit test.
3. Apply the same `excel_bond_pow` fix to `oddfprice_kernel` (ODDFYIELD is ~3e5 ULP — likely
   the same integer-power bug amplified by the odd first period), then its schedule.

## Captured data (this dir)
`price_ladder_out.json` (bond A, 0.04–0.10 + flat-95 band + par + oddfprice),
`price_disambig_out.json` (bonds B/C), `price_heldout_out.json` (bonds D/E).
Bond params: A settle=44013 mat=44562; B settle=44058 mat=44562; C settle=44013 mat=46753;
D settle=44013 mat=47119 rate=.075 red=102; E settle=44094 mat=45658 rate=.06 red=103. All freq=2 basis=0.

## YIELD schedule identification — progress (2026-07-13, still open)
Captured a 19-point live-Excel YIELD corpus across the 5 bonds (`yield_corpus_out.json`).
Structure: on-coupon + redemption-100 par (A@100, C@100) returns EXACTLY the coupon 0.05;
off-coupon par (B@100) and redemption≠100 par (D@102) do NOT — so "par→coupon" is not a
general short-circuit, it falls out of the math for the on-coupon red=100 case.

Raced schedule candidates over the CORRECTED (binexp) price:
- **RN(continuous real-arithmetic root)** (mpmath, high precision, round to double): **3/19**
  (only the two par cases + D@95). Excel is NOT the correctly-rounded analytic root.
- LibreOffice getYield_ false-position, Newton (numeric deriv, seed=rate/0.1), secant,
  safeguarded Newton: all **0/19** bit-exact. Newton(rate) hits par exactly (seed=root) and
  A@95 to +1 ULP, but the rest miss by ~tens of ULP.
Residuals (value-wise, ignoring binade-crossing artifacts on A@98/102/105 whose roots straddle
powers of two): mostly +4..+93 ULP, sign varies, deterministic. Excel publishes a SPECIFIC
converged iterate over its double-precision price kernel — an iterate-publication signature,
not the rounded true root.

**Conclusion:** YIELD is a genuine iterative solver-publication ID (Phase-4 solver-VM), same
class as open RATE/IRR. Next: build the solver-VM racer over the corrected price and enumerate
{method: Newton/secant/regula-falsi/bisection-hybrid} × {seed} × {stopping: |f|<tol / |dy|<tol
/ fixed-count, tol values} × {publication: last iterate / prev / bracket edge}, scored jointly
across the 19-witness corpus (split ident/held-out). The exact Excel stopping tolerance
(documented "0.0000001") and publication rule are the unknowns. Corpus + this doc are the seed.

**LANDING STATUS:** forward-kernel binexp fix is validated but BLOCKED — it shares `pcomp`
with YIELD, and landing it alone regresses YIELD-par (6→~40 ULP under current bisection). PRICE
(G6-03b) would close cleanly with the fix alone IF decoupled from YIELD's `pcomp` (option:
give PRICE its own corrected kernel now, unify once the YIELD schedule lands). Otherwise land
forward-fix + YIELD-schedule together.

## Solver-VM enumeration result (2026-07-13)
Built + ran the solver-VM: {Newton numeric-central-deriv (h∈{1e-4,1e-6}), secant} ×
seed∈{0.05,0.07,0.10} × stop∈{|dy|,|f|} × tol∈{1e-4..1e-9} = 90 configs, scored on the 19
corpus. **Max 2/19** (only the two par cases, where seed 0.05 IS the root). So Excel's YIELD
is NOT a plain Newton/secant with simple early stopping over the corrected price. Untried
angles for next time (the likely differentiators of the exact converged iterate):
- **analytic derivative** (−½·[Σ coup·(off+k)/base^(off+k+1) + red·(off+n−1)/base^(off+n)])
  vs numeric — changes each iterate's low bits and thus the early-stop publication;
- **x87 arithmetic** inside the iteration (price + update) — Excel financial bodies are x87;
- a **price/duration-based seed** rather than a fixed 0.05;
- Excel's exact stopping (docs: 100 iters / accuracy 1e-7) + which iterate is published.
This is the same iterate-publication wall as open RATE (G6-05) / IRR (G6-06); best tackled by
a dedicated solver-VM workflow enumerating the iterate ARITHMETIC, not just the method knobs.

## PRICE landed + DURATION/PRICEMAT validation (2026-07-14)
**PRICE fix LANDED** (commit): `excel_bond_pow` (binexp integer / powf fractional) added;
`price_kernel` routed through `pcomp_disc(..,binexp=true)`. YIELD's solver + DURATION keep the
legacy `powf` `pcomp` (decoupled). Bit-exact on all 25 live-Excel PRICE points
(`price_binexp_matches_excel_ladders`); `yield_unchanged_by_price_fix` pins YIELD; 1504/1504 green.

Validated the other non-solver bond fns (`dur_capture_out.json`):
- **PRICEMAT: already bit-exact** (2/2) — interest-at-maturity single division, no discount
  powers, does NOT share the pattern. No action.
- **DURATION/MDURATION: partially explained by binexp.** DUR_A@0.05 OxFunc `…dbe8` vs Excel
  `…dbe9` (1 ULP) → binexp fixes it. But DUR_A@0.08 is `…4488` under BOTH powf and binexp vs
  Excel `…448a` (2 ULP) — a residual OUTSIDE the discount powers (in the `Σ t·cash/disc` sum,
  `t=(off+k)/freq`, or `w/dirty`). binexp is necessary-but-not-sufficient → NOT landed for
  DURATION; tracked as catalog G6-03c for its own staging ID. DUR_A@0.06, DUR_C@0.05, DUR_C@0.08
  already exact. MDURATION inherits (= DURATION/(1+yld/freq)).
