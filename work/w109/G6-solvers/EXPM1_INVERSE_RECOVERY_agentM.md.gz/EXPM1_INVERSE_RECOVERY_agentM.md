# PMT expm1 |tau|<1 — inverse-recovery methodology results (agent-M, 2026-07-23)

## Decisive negative result (exhaustive, model-free vs answers-pmt-po2n oracle, 234 rows)
Max match over the ENTIRE family = **163/234**, achieved ONLY by all-double Kahan
`em = RN53( RN53((u-1)*tau) / lnu )`, u=exp(tau), lnu=log(u):
- per-node precision {double,extended} on u,y=u-1,log,product; tau {double,ext};
  denominator {log(u),log1p(y)}; optional final double-round  -> 128-mask ceiling 163.
- u sourced from binexp (1+r)^-n instead of exp(tau): still 163.
- ANY "keep-extended" node makes it WORSE (all-ext single-round = 145; full x87 chain = 133).
=> REFUTES "single-rounded extended x87" and "which store-mask" for the expm1 combine.

## Other refutations (all in double, bit-exact)
fdlibm expm1 129 | cephes expm1 84 | correctly-rounded expm1(tau) 133 |
F2XM1 2^(tau*log2e)-1 BLOWS UP on tiny tau (to 511 ULP) | binexp v-1 any precision <=133
(p=64 garbage) | directed rounding TZ/floor/ceil <=112 | double-round combine ~165.

## Residual structure of the 71 Kahan misses
- delta(tau) = (em_pinned - CR_expm1(tau))/ulp is BIASED toward zero (+1:65, -1:34).
- TINY tau (|tau|<~1e-3): delta is bimodal EXACTLY {0.000, +1.000}. delta=+1 (em = nextToward0
  of RN(Kahan)) occurs precisely when n=2^j so tau=-n*ln(1+2^-k) is EXACT (pure exponent shift).
  Excel underestimates |expm1| by ~1 ULP there.
- MID tau (k=-5,-4, |tau|~0.03..0.98): delta drifts monotonically -1.1 -> +0.5 with |tau|
  (smooth minimax-error signature) => argument-reduced rational main path.
- Split = tiny-arg fast path + reduced rational path. em is NOT a function of Excel's
  observable EXP(tau)/LN(u); it is an opaque inline g(tau).

## Method pivot
Stop fitting exp/log Kahan. Recover g(tau) as an inline rational op-graph, driven by the
SIGNED residual delta(tau). Use the EXACT-TAU subset (n=2^j) as a confound-free isolator.
Bracket argument-reduction thresholds T in {0.5ln2, ln2, 0.5} to pin the reduction scheme.
