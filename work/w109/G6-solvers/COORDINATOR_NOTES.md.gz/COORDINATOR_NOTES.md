# Coordinator parallel findings (while pmt-closure-explore workflow ran)

## POWER provenance (NEW captures: answers-pow-{po2pos,po2neg,genneg}.json)
- Excel worksheet POWER(base, +n) = BINEXP (repeated squaring, RN each): 257/264. NOT CR pow (225/264).
- Excel worksheet POWER(base, -n) = RN(1.0/binexp(base,|n|)): 175/175 (binexp != CR on 145/175 -> decisive).
- => Confirms bond-function lineage: worksheet POWER uses C-runtime binexp for integer exponents.

## BUT PMT does NOT use binexp (REFUTED for PMT):
- em_pinned vs (1/binexp - 1): |tau|>=1 gives 18/24 (75%), vs exp-based u-1 = 100% (3840/3840).
- => PMT's (1+r)^-n = exp(-n*log1p(r)) [x87 fFEXP], NOT binexp-pow. Consistent with RATE's power.
- PMT em != RN(POWER-1) (13/234) -> PMT uses a real expm1, not pow-then-subtract.

## Standing wall (unchanged):
- expm1 |tau|<1: with tau,u=exp(tau),lnu=ln(u) all PROVEN-exact doubles, Kahan (u-1)*t/lnu = 163/234.
  No op-graph over {tau,u,lnu} closes it. Excel uses a different correction op-graph OR intermediate.
- Next: provenance (LibreOffice/Gnumeric expm1 correction), or a non-{u,lnu} intermediate.

## BREAKTHROUGH: PMT em != Excel's standard expm1 (NEW captures: answers-expondist.json)
- EXPON.DIST(x,1,TRUE) = 1-e^-x, so expm1(tau) = -EXPON.DIST(-tau,1,TRUE) — a DIRECT expm1 oracle.
- Excel's EXPON.DIST expm1 == the all-double Kahan model: 232/234. (Confirms stats expm1 = Kahan.)
- BUT PMT em_pinned == EXPON.DIST expm1 only 165/234, == Kahan 163/234.
- At IDENTICAL tau (n=power-of-2 -> tau exact, no ×n rounding), EXPON.DIST gives Kahan but PMT
  gives something ELSE. => PMT does NOT call the standard expm1. Its (1+r)^-n-1 is a
  FINANCIAL-BODY-SPECIFIC routine (legacy x87), distinct from the statistical expm1.
- Ruled out for PMT em (Python, vs em_pinned): ext-exp(64)-1 =102, dbl-exp-1 =14, forward
  -expm1(-tau)/exp(-tau) =128 (=CR), plain u-1 =14. Kahan double =163 still best but NOT it.
- LEAD: native x87 F2XM1 (2^y - 1) path with y=-n*log2(1+r); |tau|<ln2 -> F2XM1 direct; the
  earlier D_f2xm1log2=127 used one reduction — the financial body's exact reduction/delivery
  is the target. Reframes the 'expm1 wall' as 'the legacy financial annuity-factor op-graph'.
- IMPLICATION for the workflow: agents were framing this as an expm1 op-graph; it's actually a
  SEPARATE financial-runtime (1+r)^-n-1 primitive. Provenance target = the financial DLL's
  annuity code, not msvcrt expm1.

## Further racing-side refutations of PMT's em op-graph (all vs em_pinned, 234 |tau|<1 pts):
- Signed dir: em_pinned - Kahan (real value) = {-2:2, -1:12, 0:163, +1:57}. Mild bias +1 (toward 0).
- Chop (RZ toward 0) of Kahan divide: 112 (final divide) / 119 (exact) — WORSE, not chop.
- ext-exp(64)-1: 102; F2XM1 log2 path: 127; forward -expm1(-tau)/exp(-tau): 128 (=CR); binexp: refuted.
- Kahan double stays best at 163. PMT's em is a DISTINCT routine, no standard variant matches.
- CONCLUSION: this needs PROVENANCE (the legacy financial DLL's exact annuity op-graph), not more
  racing over {tau,u,lnu}. Fast Python tester ready: work/.../expm1_optest.py (u,lnu captured exact).

## Related-functions angle (2026-07-23, user-requested): IPMT/PPMT inherit PMT
- Mortgage lane r=0.09/12,n=360,pv=125000: IPMT = round(-balance*r); -IPMT/r matches FV(per-1)
  to ~1e-11 (per=1) growing to ~4e-9 (per=360). So interest=balance*rate confirmed; the balance
  drifts from FV(r,per-1,pmt0,pv,0) because (a) it's a per-period recurrence not the closed FV,
  and (b) pmt0 carries the PMT expm1 residual.
- IPMT+PPMT==pmt0 bit-exact only sometimes (per 1,2,180 yes; 3,60,359,360 no) -> the +-1 ulp
  residual. PPMT=pmt0-IPMT.
- CONCLUSION: IPMT/PPMT/CUMIPMT/CUMPRINC are NOT independently closable; they inherit PMT's expm1
  residual (via pmt0 AND the balance's (1+r)^per). Closing PMT's extended-log1p expm1 closes the
  whole cluster. => the CORE extended-log1p recovery IS the bottleneck for all 5 functions.
- Naive IPMT==RN(FV(per-1)*r) refuted (bit-level); the exact balance recurrence (per-period vs
  closed FV) is the remaining IPMT-specific detail (agent lane).

## log1p candidate sweep (2026-07-23) - no clean winner yet; collision oracle is CONFOUNDED by expm1 wall
race_log1p_id (em oracle collision/genrate + full-PMT heldout):
  candidate   collision  genrate  heldout(full PMT /875)
  CR          83/116     61/90    493
  FYL2XP1     82/116     61/90    493
  std_ln1p    67/116     61/90    523  (+30 - the one real signal, but may be COMPENSATING for expm1 wall / combine)
  kahan(comp) 64/116     53/90    489  (Kahan-companion log1p REFUTED again, even at general rates)
  kahan2      62/116     61/90    518
  lnfl(ctrl)  5/116      61/90    285  (ln(fl(1+r)) negative control, confirms refuted)
KEY: collision em oracle (fv=0,|tau|<1) is CONFOUNDED - the 71-miss expm1 wall residual is present in those
configs, so no faithful log1p beats CR's plurality (83) there. Need the CONFOUND-FREE split (exact-1+r rates ->
only expm1 residual; non-exact-1+r -> both) to isolate log1p cleanly. std_ln1p's +30 heldout is the lever but
unproven as Excel's exact routine. 8-agent workflow w5ny84i4e attacking both components.
