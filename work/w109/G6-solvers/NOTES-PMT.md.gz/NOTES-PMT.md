# PMT transcendental-provider state — 2026-07-12 (session 2)

Racer: `calc_graph_racer/src/bin/fit_pmt_stores.rs` (x87 Ext80, CW=0x133F).
Data: `answers-pmt-r0.json` (48 rows). Champion **36/48** `pform4 comp2 mask 001101100`.

## What changed this session (34 -> 36, small-rate catastrophe ELIMINATED)
The racer previously only formed `w = 1+rate` then took `fyl2x(w)` / binexp
(pforms 0-3). For tiny rate that is catastrophic (rate=1.5e-6 was **-16285 ULP**).
Added the log1p/expm1 provider:
- **pform 4**: `P = 2^(n*log2(1+rate))` with the log via **FYL2XP1(rate)** directly
  (no `w=1+rate` formed) — accurate for small rate.
- **pform 5**: branched — FYL2XP1 for `|rate| <= 1-sqrt(1/2)=0.29289` (its hardware
  domain), else `fyl2x(1+rate)`.
- **KEY**: the annuity factor needs `P-1`, and forming it as `P.sub(1)` re-introduces
  the cancellation even when P is accurate. So `two_pow2` now returns `(P, P-1)` where
  **P-1 is the accurate expm1 via F2XM1** (`2^t-1` directly) when `k=round(t)==0`
  (small |t| = small rate). This is what actually kills the small-rate error.
Result: rate=1.5e-6 rows -16285/-126/+779/+48 -> -1/-2/exact/exact.

## Residual frontier (12 misses, champion pform4 comp2)
```
rate=5.00e-2  n=10  ty=0  +1      rate=1.50e-6 n=360 ty=0  -1
rate=5.00e-2  n=7   ty=1  +1      rate=1.50e-6 n=7   ty=1  -2
rate=9.00e-1  n=7   ty=1  +1      rate=6.25e-2 n=60  ty=1  +1
rate=-1.55e-1 n=10  ty=0  -1      rate=2.50e0  n=360 ty=0  -1
rate=-1.55e-1 n=360 ty=0  -32 *   rate=1.10e-2 n=10  ty=0  -3
rate=-1.55e-1 n=7   ty=1  -6      rate=1.634e-1 n=7  ty=1  -2
```
- The **-32 ULP outlier**: rate=-0.155, n=360 — deeply-underflowing negative-rate
  (P=0.845^360~5e-27, result ~1e-23). The log-domain pow `2^(n*log2(1+rate))` at large
  |exponent| (t~-87) diverges from Excel here; binexp of w=0.845 may match — but binexp
  loses small-rate, so no single pform wins all -> **provider may be regime-branched**
  (small |rate| log1p/expm1, larger |rate| binexp or fyl2x). Next probe: per-row, which
  pform nails the -32 and -6 rows? If binexp, the branch threshold is the unknown.
- The ~8 rows at +-1 ULP are mask-fishing territory: at 36/48 many masks tie, and the
  prior workflow flagged `holds_up=false` (the mask overfits these 48). Do NOT chase +-1
  by mask alone — needs a structural discriminator (a fresh held-out PMT grid to score
  candidates, or the exact comp arrangement Excel uses for the `tf=(1+rate*type)` factor,
  since the +-2..6 rows skew ty=1).

## HELD-OUT VALIDATION (2026-07-12) — 36/48 was OVERFIT; FAMILY CEILING ~57%
Harvested 875 fresh held-out rows (`answers-pmt-heldout.json`, disjoint from r0:
rate ladder straddling the 0.29289 FYL2XP1 boundary, n in {1,2,5,24,120,240,300},
5 pv/fv/ty combos). Racer held-out mode: score EVERY candidate on held-out.
- **GLOBAL CEILING over all 30720 candidates (6 pform x 10 comp x 512 mask): 495/875 =
  56.6%**, at pform4/5 comp2 mask 100110000 — which scores only **32/48 on train**. Train
  and held-out select DIFFERENT masks => the store-mask overfits; true model fidelity ~57%.
- Four extra final-association comp forms (6-9: tf/rate grouped, seq bracketings,
  (num/tf)*(rate/pm1)) did NOT beat comp2 — the exact association is not the (only) gap.
- **404 misses, 93% are +-1..2 ULP** (301 x +-1, 73 x +-2, 13 x +-3, ~11 >=9). Broad,
  shallow: right ALGORITHM/family, exact final-association op-graph NOT pinned.
- Spread across ALL rate regimes (branched FYL2XP1/fyl2x provider works across the
  boundary). ty=1 miss-rate ~50% vs ty=0 ~40% (tf staging contributes, not decisive).
- The only LARGE misses (>=9 ULP, ~11 rows) are ALL negative-rate/large-n (rate=-0.2,
  n=120..300) — the deep-underflow regime; separate pow-provider-precision issue.
- Best mask keeps P and P-1 EXTENDED (b2=b3=0), stores w/q/den/tf (b1,b4,b5,b8).

**Verdict:** PMT is a BROAD +-1 ULP residual (~57% held-out ceiling over the WHOLE model
family), same hard-residual class as GAMMALN/solvers — NOT near closure. The "12 rows" was
a 48-row-train overfit artifact.
Closure needs the exact op-graph association (unobservable intermediates) or a
structurally different comp form; mask-fishing overfits (confirmed). expm1/F2XM1 provider
fix (small-rate) stands as a genuine correctness improvement.

## Recommended next steps (if resumed)
1. Enumerate MORE final-association comp forms beyond 0-5 (Excel's exact op-sequence is not
   the F# reference comp0 nor comp2; both ~50% held-out). Score on the 875 held-out, not r0.
2. Deep-underflow provider for neg-rate/large-n (~11 rows): per-row pform diagnostic
   (binexp vs log-domain) — but binexp loses small-rate, so a regime branch is implied.
3. Do NOT chase +-1 by store-mask alone — validated as overfit.
