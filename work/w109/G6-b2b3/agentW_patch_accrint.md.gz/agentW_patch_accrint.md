# agentW_patch_accrint.md — replacement spec for `accrint_kernel`

Target: `crates/oxfunc_core/src/functions/bond_core_family.rs`. Replace the body of
`accrint_kernel` from the guard `if !(issue < first && issue < settlement)` onward
(currently lines ~827-908), and add one small helper `issue_period_grid`. All referenced
helpers already exist (`change_month_flag`, `is_month_end`, `coup_days_accr`,
`days_between_num`, `days_between_denum`, `diff360_us`, `act`). Identified + held-out
validated to 99.99% bit-exact on 76,830 live-Excel witnesses (b39 25,410 + b40 51,420);
residual = 6 rate-0.0615 ±1-ULP rounding-boundary bistables, banked in agentW_results.md.

Body class: **plain SSE2 `f64`** — no x87 (verified strictly worse on both paths).

## New helper (place next to `find_pcd_ncd_accr`)

```rust
/// The coupon period `[B0, B1]` on `first`'s grid schedule that contains `issue`
/// (`B0 <= issue < B1`). Uses a STRICT lower step so an `issue` landing exactly on a grid
/// boundary yields `B1 == issue` (a zero-length stub — the whole periods are then skipped).
fn issue_period_grid(
    issue: i64,
    first: i64,
    num_months: i64,
    last_day: bool,
) -> Result<(i64, i64), BondCoreEvalError> {
    let mut b1 = first;
    while b1 > issue {
        b1 = change_month_flag(b1, -num_months, last_day).ok_or(derr(WorksheetErrorCode::Num))?;
    }
    while b1 < issue {
        b1 = change_month_flag(b1, num_months, last_day).ok_or(derr(WorksheetErrorCode::Num))?;
    }
    let b0 = change_month_flag(b1, -num_months, last_day).ok_or(derr(WorksheetErrorCode::Num))?;
    Ok((b0, b1))
}
```

## Replacement body (from after the `Num` guard)

Keep the existing prelude unchanged:

```rust
    let fc = f as f64;
    let num_months = 12 / f;
    let end_flag = is_month_end(first);
    let pcd =
        change_month_flag(first, -num_months, end_flag).ok_or(derr(WorksheetErrorCode::Num))?;
    let canonical = coup_days_accr(pcd, first, num_months, end_flag, fc, basis_)?;
```

Then replace everything below with:

```rust
    // calc_method TRUE  (from_issue) => period-aware walk accruing from issue.
    // calc_method FALSE            => FLAT fraction days(issue->settle)/canonical, with a
    //                                 skip of the whole grid periods before issue's own
    //                                 period (see model note below).
    if !from_issue {
        // ---- c0 : FLAT ----
        let a = if issue < pcd {
            // issue lies in a coupon period earlier than the canonical last-before-first
            // period.  The issue stub accrues over its OWN grid period [B0,B1]; the WHOLE
            // grid periods [B1, pcd] contribute NOTHING (the defining calc_method=FALSE
            // fact); the remainder is measured from pcd.  Two divisions, summed.
            let (b0, b1) = issue_period_grid(issue, first, num_months, end_flag)?;
            let l_issue = match basis_ {
                DayCountBasis::ActualActual => act(b0, b1),
                DayCountBasis::Actual365 => 365.0 / fc,
                _ => 360.0 / fc,
            };
            let stub = days_between_num(issue, b1, basis_)? / l_issue;
            let rest = days_between_num(pcd, settlement, basis_)? / canonical;
            stub + rest
        } else {
            days_between_num(issue, settlement, basis_)? / canonical
        };
        return Ok(par * rate_ / fc * a);
    }

    // ---- c1 : period walk from issue ----
    if settlement <= first {
        // pre-first backward walk (datesAggregate1). Unchanged from the prior kernel except
        // that only the walk (TRUE) reaches it now, so whole periods always add 1.0, and the
        // act/act odd-first partial uses the period's own actual length.
        let first_date = issue.max(pcd);
        let days = days_between_num(first_date, settlement, basis_)?;
        let mut a = days / canonical;
        let mut front = pcd;
        while front > issue {
            let ncd_i = front;
            let pcd_i = change_month_flag(front, -num_months, end_flag)
                .ok_or(derr(WorksheetErrorCode::Num))?;
            front = pcd_i;
            if issue <= pcd_i {
                a += 1.0;
            } else {
                let fd = issue.max(pcd_i);
                let (days_i, coup_days_i) = match basis_ {
                    DayCountBasis::Us30_360 => {
                        (diff360_us(fd, ncd_i, false)?, diff360_us(pcd_i, ncd_i, true)?)
                    }
                    DayCountBasis::ActualActual => {
                        (days_between_num(fd, ncd_i, basis_)?, act(pcd_i, ncd_i))
                    }
                    DayCountBasis::Actual365 => (days_between_num(fd, ncd_i, basis_)?, 365.0 / fc),
                    _ => (
                        days_between_num(fd, ncd_i, basis_)?,
                        days_between_denum(pcd_i, ncd_i, basis_)?,
                    ),
                };
                a += days_i / coup_days_i;
            }
        }
        return Ok(par * rate_ / fc * a);
    }

    // settlement past the first interest date: forward-collect the period terms, then sum
    // them BACKWARD (settlement side first — the direction Excel accumulates; forward summing
    // is ~1 ULP off on ~9% of rows). Interior COMPLETE periods contribute exactly 1.0; the
    // act/act issue-side stub uses its own actual length; the FINAL period touching
    // settlement is always days/canonical (it stays fractional even when settlement lands
    // exactly on the period-end coupon date).
    let mut p_start = first;
    while p_start > issue {
        p_start = change_month_flag(p_start, -num_months, end_flag)
            .ok_or(derr(WorksheetErrorCode::Num))?;
    }
    let mut terms: Vec<f64> = Vec::new();
    while p_start < settlement {
        let p_end = change_month_flag(p_start, num_months, end_flag)
            .ok_or(derr(WorksheetErrorCode::Num))?;
        let ov_start = issue.max(p_start);
        let ov_end = settlement.min(p_end);
        if ov_end > ov_start {
            let is_last = ov_end == settlement;
            if ov_start == p_start && ov_end == p_end && !is_last {
                terms.push(1.0);
            } else {
                let denom = if matches!(basis_, DayCountBasis::ActualActual)
                    && ov_start == issue
                    && issue > p_start
                {
                    act(p_start, p_end)
                } else {
                    canonical
                };
                terms.push(days_between_num(ov_start, ov_end, basis_)? / denom);
            }
        }
        p_start = p_end;
    }
    let mut a = 0.0;
    for t in terms.iter().rev() {
        a += *t;
    }
    Ok(par * rate_ / fc * a)
```

`from_issue` is the existing `calc_method.unwrap_or(true)` binding (TRUE = walk, FALSE =
flat) — keep that line. Delete the now-unused older comment block about
"FromIssueToSettlement / one quasi-coupon period before first".

## Regression tests (append to the file's `#[cfg(test)]` module)

Each pins exact live-Excel bits. `h(x)` = `f64::from_bits(x)`. Args order:
`accrint_kernel(issue, first, settlement, rate, Some(par), freq, Some(basis), Some(calc))`.

| # | witness | args (issue,first,settle,rate,par,freq,basis,calc) | expected bits |
|---|---|---|---|
| 1 | historic catalog (BUG-FUNC-030) c1 | 43565,43647,43905,0.05,997.5,2,0,TRUE | `0x404734aaaaaaaaaa` |
| 2 | historic catalog c0 (1 ULP from #1 — pair discriminator) | 43565,43647,43905,0.05,997.5,2,0,FALSE | `0x404734aaaaaaaaab` |
| 3 | issue 3 periods early, quarterly, c0 (skip-rule) | 43881,44197,44013,0.05,997.5,4,2,FALSE | *(from b40 `b40-T3Q-44013-b2-r0.05-c0`)* |
| 4 | on-grid issue c0 (zero stub, skip-rule) | 43922,44197,44013,0.05,…,4,0,FALSE | *(from b40 `b40-IB-*-b0-…-c0`)* |
| 5 | leap-interior LY act/act c1 | 43525,44256,44075,0.05,…,1,1,TRUE | *(from b40 `b40-LY-44075-b1-r0.05-c1`)* |
| 6 | long-walk c1 (on-coupon final) | 43221,43405,…,0.05,…,2,0,TRUE | *(from b40 `b40-LW-*-c1`)* |
| 7 | month-end + leap Feb c1 | 43889,44074,44439,0.05,1000,2,0,TRUE | `0x4052c8e38e38e38e` (E-44074 b0) |
| 8 | Q act/act issue-stub c0 (b39) | 43535,43647,43650,0.05,1000,4,1,FALSE | `0x402f940fc0fc0fc2` |

**Fill rows 3-6 from the captured b40/b42 answer files at apply time** (grab the exact args
+ `expected_bits` for the named ids) so the pins are real Excel witnesses, not my
predictions. Rows 1,2,7,8 are already exact from b39.

### BUG-FUNC-030 pin movement — expected & to justify

The old catalog pinned "issue 43565 / first 43647 / **settle 43905** / 0.05 / par **1000** /
freq 2 / basis 0" as a residual 1-ULP witness. Under the corrected kernel that exact input
(par 1000, calc default TRUE) becomes bit-exact against the live oracle — if an existing
Rust test pinned the *OxFunc-legacy* output there rather than the Excel value, it will move;
**report it and re-pin to the b39/b40 Excel `expected_bits` for those args, quoting the
answer row.** Do not preserve a legacy-behavior pin.
