# W109 G6-03d — PRICE bases 2/3 forward-kernel: staging identified + landed (agent-V)

Live build 20131 (AMD 4800H). Corpus: b37 (7,472 PRICE witnesses, identification)
+ b38 (945 PRICE witnesses, FRESH held-out). Files in
`smart-fuzzer/work/w109/G6-b2b3/`.

## 1. Result summary

PRODUCTION `price_kernel` (post-fix), gated bit-exact vs live Excel:

| corpus | b0 | b1 | b2 (Act/360) | b3 (Act/365) | b4 | total |
|---|---|---|---|---|---|---|
| b37 (ident) | 48/48 | 48/48 | **3656/3664** | **3658/3664** | 48/48 | 7458/7472 |
| b38 (held-out) | 105/105 | 105/105 | **315/315** | **315/315** | 105/105 | **945/945** |

b38 is a clean 945/945 across ALL bases — the held-out gate passes with zero
misses. b37 leaves 14 open ±1..3-ULP residual rows (section 5), all at extreme
yield on one bond; b38's extreme-yield rows (yld up to 0.35) all landed, so the
residual is a rare per-row accumulation boundary, not a systematic gap.

Pre-fix baseline (production before this change): bases 2/3 were materially
wrong (~cents; catalog G6-03d), scoring 0/3664 each in the plain-double
`direct/binexp` model.

## 2. The identified staging (exact spec)

For a bond with coupon period `[prev, next]` bounding `settlement`, `n` periods
to maturity, `coup = 100·rate/freq`:

1. **Coupon period length E** (`dc`): `360/freq` for bases 0,2,4; `365/freq` for
   basis 3; actual `next−prev` for basis 1. (Unchanged; already correct.)
2. **Accrued A** (`dd(prev, settlement)`): US 30/360 for basis 0; European
   30/360 for basis 4; actual days for bases 1,2,3. (Unchanged.)
3. **Discount/settlement fraction DSC = E − A** — the UNIVERSAL derived rule,
   *not* the direct day-count span `settlement→next`. **This is the root-cause
   fix.** For bases 0/1/4 `E−A` equals the direct span except on
   settlement-on-31st 30/360 rows (which `E−A` also corrects); for bases 2/3
   they differ materially. Excel's own COUPDAYSNC still *publishes* the actual
   days at bases 2/3 — PRICE's internal DSC deliberately diverges from the
   published COUP* function.
4. **Discount factor `base^(off+k)`**, `base = 1 + yld/freq`, `off = DSC/E`:
   - integer exponent (on-coupon, `off=1`): C-runtime `pow` integer special case
     = **binary exponentiation** (square-and-multiply, plain f64). (Already there.)
   - fractional exponent (off-coupon): the legacy CRT `pow` chain
     **`exp(RN53(RN64(exp · ln base)))`** via x87 `ln`(RN53-published) /
     `mul`(double-rounded) / `exp`(RN53-published) — i.e.
     `crate::excel_numeric::excel_pow_chain`, NOT the platform `f64::powf`.
5. **Body arithmetic: plain double, single-rounded.** Summation = coupons
   ascending `Σ_{k=0}^{n-1} coup / D_k`, then `+ red / D_{n-1}`, then `− coup·A/E`.
   (`D_{n-1}` is evaluated twice — once as the last coupon term, once for
   redemption — matching the reference source.)

## 3. Cross-lane confirmation (evidence-grade)

The fractional pow realization landed here is byte-identical to
`excel_numeric::excel_pow_chain`, the **distribution-substrate pow identified
independently in the G3 lane-1 work** (BINOM `q^n`, WEIBULL cdf/pdf pow sites).
That the same `exp(RN53(RN64(y·ln x)))` x87 chain surfaces in the bond kernel —
reached from a completely different function family and corpus — is independent
corroboration that this is Excel's single CRT `pow` chain, not a per-site fit.
Verified bit-exact against the real hardware `x87_serve` (ops `ln`/`mul`/`exp`)
on the residual rows: mpmath RN53 emulation and the hardware chain agree exactly.

## 4. Refutation ledger (bit-exact, driven by signed-residual structure)

Scores are b2+b3 exact / 7328 unless noted. Fixed model = `dsc=e−a`,
plain-double body, integer→binexp; only the varied axis changes.

Fractional pow realization:
- `powf` (platform) — 7120  (b2 3474, b3 3446)
- x87 chain, ln kept EXTENDED before mul — 7034 (b2 3519, b3 3515) — worse
- **x87 chain, ln→RN53 then mul→RN53 then exp→RN53 (`excel_pow_chain`) — 7314
  (b2 3656, b3 3658) — WINNER.** Rounding ln to double *before* the multiply is
  decisive → ln is delivered as a double (separate CRT call), not a monolithic
  80-bit pow.

Summation / accumulation structure (all with the winning pow):
- **sep** (current: coupons asc + separate redemption at `D_{n-1}`) — 7314 WINNER
- fold (red into last coupon term) — 5117
- rev (descending k) — 6493 · revfold — 3877 · redfirst — 3822
- prodrun (running product `D*=base`) — 3710 · recipmul (`coup·base^−(off+k)`) — 4817
- foldrecip — 4128

Body arithmetic precision:
- plain double, single-rounded — 7314 WINNER
- x87 per-op double-rounded body (add/sub/mul/div RN53(RN64)) — 7315 (Δ=+1;
  indistinguishable → body is NOT the driver)
- extended-accumulator (pv kept 80-bit, single final store): variants 4665–5500
  — decisively WORSE → the accumulator is spilled to double each step.

Basis-4 day count:
- US 30/360 accrued (shared with basis 0) — b4 45/48 (3 settle-on-31st misses)
- **European 30/360 accrued (d1==31→30, d2==31→30 unconditional) — b4 48/48.**

COUP* kernels: not separately re-raced here (production `coupon_family`
untouched); DSC=E−A is deliberately internal to PRICE and does NOT alter the
published COUP* surface (see §2.3). Left as an explicit non-change.

## 5. OPEN characterized residual — 14 rows (banked, not accepted)

`agentV_residual14.json` holds all 14 with args, Excel bits, mp-exact (250-bit)
true-sum bits, emulator bits, and signed ULP deltas. All are on bond BE
(freq 2, mat 2025-01-01) except one BQ (freq 4), 13 at yld=0.2, one at 0.12,
one at 0.001.

Precise statement (op-graph fact, NOT an explanation to stop at): **Excel's
published value is not the correctly-rounded true sum.** `excel − true` is
`+1` on most rows, `+2` (44152), `+3` (44182), and `−1` on three — i.e. Excel's
own left-to-right plain-double reciprocal-pow accumulation drifts up to 3 ULP
*above* the exact sum at extreme yield, where the ~9 tiny discount terms
compound rounding. The emulator sits on (or ±1 from) the true value; `emu−excel`
is ±1. So the miss is an unidentified detail of Excel's exact FP-register/spill
accumulation schedule in the body, not a missed transcendental (the hardware x87
`ln/mul/exp` reproduce my pow bit-for-bit on these rows).

Status: OPEN in the catalog row; timeboxed, not closed. Next-probe sketch
(b33 boundary-crossing pattern): for each miss, capture PRICE at `yld` and the
two adjacent doubles `yld ± 1 ULP` to bracket where the accumulation low bit
flips, and capture the per-term partial sums by shrinking `n` (truncated ladders)
to localize which coupon term's rounding diverges. Also probe redemption-folded
vs separate at exactly these rows. Fresh battery id: b41 (do NOT re-fit on b38).

## 6. Landing (crates/oxfunc_core/src/functions/bond_core_family.rs)

- `pcomp_disc`: `let dsc = dd(c.settlement, p.next, c.basis)?;` → `let dsc = e - a;`
  (universal rule, all callers).
- `excel_bond_pow` fractional branch: `base.powf(exp)` →
  `crate::excel_numeric::excel_pow_chain(base, exp)`; doc updated.
- Regression test `price_dsc_e_minus_a_and_x87_pow_chain_pins`: catalog witness
  `PRICE(44094,45658,.06,.03,103,2,2)=0x405ca5adc69c74fb`, basis-3 sibling
  `...,3)=0x405ca62e6ffeec41`, settle-on-31st basis-0
  `PRICE(44043,45658,.06,.03,103,2,0)=0x405cbcd7f4f1f43d`, pow-chain discriminator
  `PRICE(44094,45658,.06,.2,103,2,3)=0x404f217d3fb8f25d` (powf 1 ULP off).

## 7. Blast radius

`pcomp_disc` is shared by PRICE (binexp=true), YIELD's solver, DURATION/MDURATION
(binexp=false).

- **Pow-chain change is PRICE-only**: it lives in `excel_bond_pow`, invoked solely
  on the `binexp=true` path. YIELD/DURATION keep `base.powf` (unchanged).
- **`dsc=e−a` affects all callers** on bases 2/3 and settle-on-31st 0/4 rows —
  intended (it is the identified truth; YIELD/DURATION 2/3 rows are still open in
  the catalog). Note: DURATION also computes its *own* `dsc = dd(settlement,next)`
  (line ~655) for its `off`; that separate line is unchanged, so on bases 2/3
  DURATION now mixes an `E−A` dirty with a direct-span `off`. DURATION is a
  separate open lane (G6-03c) and was not in scope; flagged for its own pass.
- **Full `cargo test -p oxfunc_core`: all green, zero pinned-test movement.**
  `yield_unchanged_by_price_fix` (yield-catalog `0x3fb61465bd6a9970`, yield-par
  `0x3fa99999999999a0`) byte-stable — the yield pins are basis 0 at a non-31st
  settlement, where `E−A` equals the direct span. `price_binexp_matches_excel_ladders`
  (25 basis-0 points) unchanged: the x87 chain reproduces all 25 that `powf` did.
  `yieldmat_*` unaffected (separate maturity formula, no pcomp).

## 8. Reproduce

- `python agentV_race.py` — full b37 race (dsc/pow/arith variants; emulator).
- `python agentV_sumrace.py` / `agentV_accrace.py` — summation & accumulator ledgers.
- `python agentV_x87check.py` — hardware x87 chain vs emulator on the 14 residuals.
- `python agentV_gate_b38.py` — emulator gate on b38 (b0 is emulator-limited; the
  production kernel is the authority — see below).
- `calc_graph_racer` bin `agentV_gate_price <answers.json...>` — the DEFINITIVE
  gate: runs the production `price_kernel` (used for the §1 table).

Emulator caveat: the Python `agentV_race.py` day calendar was simpler than
production — b38 first exposed two emulator-only bugs it fixed in-place
(end-of-month coupon stepping in `addm`; the full US 30/360 Feb/month-end rule
in `d360us`). Production's `addm` and `day_count_common::us_30_360` already
implement both, so the production kernel scores 945/945 on b38 where the raw
emulator left basis-0 month-end rows short. The identified STAGING (§2) is
orthogonal to the calendar and unchanged by those fixes.
