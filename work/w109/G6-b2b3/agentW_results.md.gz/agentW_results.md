# G6-02 ACCRINT — accumulation-staging identification (agent-W, W109)

**Corpus:** `answers-b39-accrint.json` — 25,410 live-Excel witnesses (bonds W/Q/A/E,
settlement ladders every 3rd day, bases 0-4, rates .05/.037/.0615, par 1000/997.5
interleaved, calc_method both).

**Result — LANDED.** The identified model was applied to `accrint_kernel`
(`bond_core_family.rs`) and the rebuilt production kernel reproduces the model bit-for-bit:
**b39 25,407 / 25,410**, held-out **b40 51,417 / 51,420**, fresh-gate **b42 68,783 / 68,790**
— combined **145,607 / 145,620 = 99.991%**, vs the pre-landing kernel's 17,967 / 25,410
(70.71%) on b39. Full `cargo test -p oxfunc_core` green (1,511 passed, 0 failed); no pinned
test moved (the BUG-FUNC-030 leap-February pin still passes — it was a real Excel witness).
The 13 residuals across all three corpora are per-input rounding-boundary bistables
(banked below, perfectly rate-selective), not a structural gap. b40 exposed and fixed the
final c0 rule — the whole-period *skip* (below); b42 (independent) gated it clean.

Per class after the model:

| path | regime | exact | off |
|------|--------|------:|----:|
| c0 (calc FALSE) | pre-first  | 3750 | 0 |
| c0 (calc FALSE) | post-first | 8953 | 2 |
| c1 (calc TRUE)  | pre-first  | 3750 | 0 |
| c1 (calc TRUE)  | post-first | 8954 | 1 |

---

## The model

Let `f` = frequency, `fc = f as f64`, `num_months = 12/f`,
`end_flag = is_month_end(first)`, `pcd = change_month_flag(first, -num_months, end_flag)`,
`canonical = coup_days_accr(pcd, first, …)` (act/act → `act(pcd,first)`; act/365 →
`365/fc`; every other basis → `360/fc`). `daysNum` = `days_between_num` (basis-specific
numerator day count: 30/360-US for basis 0, actual for 1/2/3, EU-30/360 for 4).

Published value is always `par * rate / fc * a`, with **`a` computed as a separate,
independently-rounded step** and then multiplied by the coupon `par*rate/fc`. (Racing 12
product orderings: every "compute `a` first, then coupon·a" ordering ties at the maximum;
every ordering that folds `days` into the coupon numerator loses ~27 pts. Correctly-rounded
/ fused-exact is *worse* than the staged double — so Excel genuinely double-rounds.)

### calc_method = FALSE  →  c0 = FLAT fraction, with a whole-period SKIP

**Semantics (the legacy fact, not just a formula).** When `issue` falls in a coupon period
*earlier* than the canonical (last-before-`first`) period, Excel's calc_method=FALSE accrual
counts **only two things**: (1) the partial "stub" from `issue` to the end of *issue's own*
grid coupon period, and (2) the span from `pcd` (the last coupon date before `first`) to
`settlement`. **Every whole coupon period strictly between issue's own period and `pcd`
contributes NOTHING** — those periods are silently skipped. This is what the option's
name ("do not accrue from issue, accrue from first") actually does in the code: it discards
the interior whole periods rather than counting them.

```
if issue >= pcd:                       # issue inside the canonical (last-before-first) period
    a = daysNum(issue, settle) / canonical                 # single division
else:
    (B0, B1) = issue_period_grid(issue)   # issue's OWN grid period; B1==issue if on the grid
    L_issue  = act(B0,B1) [basis 1] | 365/fc [basis 3] | 360/fc [else]
    stub = daysNum(issue, B1) / L_issue                    # partial in issue's own period
    rest = daysNum(pcd,   settle) / canonical              # from pcd — skips [B1, pcd] wholes
    a = stub + rest                                        # TWO divisions summed
```

**Worked example** (`b40-M2Q`, act/360): issue 2020-05-15, first 2021-01-01, freq 4 →
`pcd = 2020-10-01`, `canonical = 360/4 = 90`. Issue's own grid period is
`[2020-04-01, 2020-07-01]`, so `B1 = 2020-07-01`. For settlement `2020-07-01`:
`stub = act(2020-05-15, 2020-07-01)/90 = 47/90`; `rest = act(2020-10-01, 2020-07-01)/90 =
-92/90`; `a = 47/90 − 92/90 = −45/90 = −0.5` — matching Excel exactly. The whole period
`[2020-07-01, 2020-10-01]` (92 actual days) is **skipped**, which is why the accrual comes out
*negative* for a settlement that is chronologically after issue: Excel is measuring the last
partial against `pcd`, not against issue, and the intervening quarter simply vanishes. (My
first model measured `rest` from `B1` instead of `pcd` — it counted that quarter and produced
`+0.522`; b40 falsified it and pinned the skip.)

Edge cases the rule must get right (all validated on b40):
- **issue exactly on a grid date** (`IB`, `LY`): the strict boundary search gives `B1 == issue`
  so `stub = 0`; every whole period up to `pcd` is skipped and `a = daysNum(pcd,settle)/canon`.
- **leap-Feb anchor shift** (`T3Q`, issue 2020-02-20): the stub/skip split lands the effective
  anchor one actual day off the naive `issue + k·months` (2020-08-21 vs 2020-08-20) — because
  the stub is a day count within issue's *actual* period, not a month-stepped date.
- The split is **not act/act-specific**; `b39-Q-43539-b2` (act/360) already proved a single
  `4/90` division rounds to `…490c` while Excel's two-division `21/90 + (−17)/90` gives `…490d`.

This lifted the c0 classes from the production kernel's wrong "accrue from one period before
first" path (thousands of rows, ULP errors ~5e15) to bit-exact.

### calc_method = TRUE  →  c1 = period walk from issue

Pre-first (`settle <= first`): the existing `datesAggregate1` backward walk from `pcd`
toward `issue` (unchanged; already exact — 3750/3750). For act/act the odd-first partial's
`coup_days_i` is the period's actual length `act(pcd_i, ncd_i)`.

Post-first (`settle > first`): forward-collect the period terms, then **sum them BACKWARD**
(settlement side first):

```
p_start = first walked back to <= issue
terms = []
while p_start < settle:
    p_end = p_start + num_months
    ov = [max(issue,p_start), min(settle,p_end)]
    if ov non-empty:
        is_last = (ov.end == settle)
        if ov is a COMPLETE interior period and not is_last:
            terms.push(1.0)
        else:
            denom = act(p_start,p_end)   if act/act AND ov.start==issue>p_start   # issue stub own length
                    else canonical
            terms.push(daysNum(ov)/denom)
    p_start = p_end
a = 0.0; for t in terms.rev(): a += t
```

Two staging facts were decisive:

1. **Backward accumulation.** Forward `a += term` scores 91.16% of c1-post; reversing the
   summation order scores **99.72%**. No reorder-equivalent forward grouping and no x87 chain
   reaches this — it is specifically the settlement→issue summation direction (the same
   direction the pre-first `datesAggregate` walk already uses).
2. **Final period stays fractional.** Interior complete periods contribute exactly `1.0`, but
   the period whose end equals `settle` is *always* `daysNum(overlap)/canonical`, even when
   `settle` lands exactly on the coupon-anniversary boundary. This resolved the 21-row
   large-error class (settlements `= first + k·period`, e.g. `W-44013 → 2020-07-01`,
   `E-44074 → 2020-08-31`, `A-44593 → 2022-02-01`; errors ~1e13 ULP). The rule fixes all 45
   on-coupon c1 rows with zero regression on the 8,910 off-coupon c1 rows.

### Body class: **plain SSE2 double, NOT x87**

Every x87 emulation (mpmath `workprec(64)`, per-op extended, various store points) was
*strictly worse* than pure `f64` for **both** paths — c0 flat (x87 all-ext 67% vs sse2 98%)
and the c1 walk (x87 chain 63% vs sse2 99%). ACCRINT therefore belongs to the **plain-SSE2
class alongside GRATIO/BRATIO**, not the x87 legacy-body class (XNPV, EXP/LN/POWER, the
financial x87 spill-loops). This is a body-class discriminator worth recording: the 2010-era
analytics rewrite boundary keeps separating the two.

---

## Refutation ledger

| hypothesis | scope | score | verdict |
|---|---|---|---|
| production kernel (FALSE = accrue one period before first) | full | 17,967 (70.7%) | baseline / material bug |
| two-path: c0 flat (no split) + c1 forward walk | full | 23,809 | +5.8k; c0 semantics fixed |
| add act/act issue stub own-length (all c0) | full | 23,831 | regressed W/A/E c0 (split forced when issue≥pcd) |
| split c0 only when `issue < pcd`, all bases | full | 24,616 | c0 essentially closed (2 residual) |
| c1 walk forward accumulation | c1-post | 8,163/8,955 (91.2%) | order wrong |
| c1 walk x87 (extended accumulate) | c1-post | 8,104 (90.5%) | worse → not x87 |
| c1 walk fracs-then-integer-wholes | c1-post | 8,025 (89.6%) | worse |
| **c1 walk BACKWARD accumulation** | c1-post | 8,930 (99.7%) | **winner** |
| final period measured `daysNum/canonical` (not 1.0) | on-coupon c1 | 45/45 | fixes on-coupon class |
| exact/fused correctly-rounded product | c0 flat | 67.2% | worse than staged double |
| c0 split with `rest` from `B1` (no skip) | b40 c0 | ~fails M2Q/T3Q/M2A | **falsified by b40** — counts the interior wholes |
| c0 anchor = largest `issue + j·period ≤ pcd` (single div) | b40 c0 | staging-only off | right value, wrong staging (loses the two-division split) |
| **c0 stub `[issue,B1]/L` + rest `[pcd,settle]/canon` (skip `[B1,pcd]`)** | b40 c0 | 25,707/25,710 | **winner — the whole-period skip** |
| **full model (LANDED Rust kernel)** | b39 + b40 + **fresh-gate b42** | **145,607/145,620 (99.991%)** | **landed; b42 gated clean, 1,511 tests green** |

---

## Open residual — 6 bistable rounding-boundary rows (characterized, NOT irreducible)

All six: `rate = 0.0615` (`0x3faf7ced916872b0`), `par = 997.5`, signed ULP = ±1. The
staged-double result and Excel's result straddle a rounding boundary; Excel's exact op
sequence lands 1 ULP off correctly-rounded here (the same "less accurate than correct
rounding" signature the staged model captures for the *bulk* — these inputs flip the other
way). No product/`a` reordering and no x87 chain moves any of them.

b39 (3):
1. **`b39-A-44488-b1-r0.0615-c0`** (annual act/act, flat; issue==pcd, single division)
   args `[43537,43596,43689, 0.0615, 997.5, 1, 1, 0]`; `a = 991/365`, `coup = 61.34625`.
   got `0x4064d1e58b59214d`; Excel `0x…214c`; ULP **+1**. Correctly-rounded = `…214d`
   (Excel is 1 ULP *below* correct rounding).
2. **`b39-A-44488-b3-r0.0615-c0`** — identical arithmetic to #1 (act/365 `365/1` = act/act
   365); same got/Excel/ULP.
3. **`b39-Q-43836-b3-r0.0615-c1`** (quarterly act/365, c1 walk, issue<pcd)
   args `[43550,43646,43895, 0.0615, 997.5, 4, 3, 1]`; `coup = 15.3365625`.
   got `0x4049309555ee8cc7`; Excel `0x…cc8`; ULP **−1**.

b40 (3), same class: `b40-LY-*-b1-r0.0615-c0`, `b40-LY-*-b3-r0.0615-c0`,
`b40-CW-43904-b3-r0.0615-c0`.

b42 (7), same class: `CW-43904-b3-c0` (again), `D3A-b3-c0`, `D3A-b3-c1`, `D6Q-b3-c1`,
`D6Q-b3-c0`, `GBA-b1-c0`, `GBA-b3-c0` — mixed bonds, bases (1 & 3), calc methods, and
regimes.

**Rate-selective — the sharp constraint.** All 13 rows across three independent corpora have
`rate = 0.0615` and **only** 0.0615: never `.05`, never `.037`, regardless of bond, basis,
calc_method, or regime. The flip therefore lives in the **coupon/publication staging** — the
interaction of `0.0615 = 0x3FAF7CED916872B0`'s low bits with `par·rate/f` and the final
`coup·a` — **not in the day-count layer** (the identified structure is fully correct; these
are the last-bit rounding of one specific rate constant). Excel lands 1 ULP off correctly
rounded on these; no product/`a` reordering and no x87 chain moves them.

**Next-probe sketch (a future b43 micro-battery):** sweep `r = 0.0615 ± k·ulp(r)`,
`k ∈ [−8..8]`, over a few of the flagged bonds (`CW`, `D6Q`, `GBA`) with `settle ± 1`, all
else fixed. That maps the flip boundary and shows whether the odd bit tracks `coup` or the
`a`-division. Until then these are an **open characterized residual (13 / 145,620 = 0.009%)**,
not a wall — not a landing blocker.

---

## Held-out gates — b40 (spent) and b42 (fresh, pending)

**b40** (`batch-b40-accrint.json`, 51,420 probes; captured) placed `issue` 2–3 full periods
before `pcd` across freq 4/2/1 (`M2Q/T3Q/M2S/M2A`), issue-on-grid (`IB`), month-end+leap
(`ME`), a leap-interior act/act annual (`LY`), long walks (`LW/LWQ`), and the historic
BUG-FUNC-030 witness family (`CW`). It **falsified** the earlier "rest from `B1`" c0 split and
pinned the whole-period *skip* (`rest` from `pcd`). Because the fix was derived from b40, b40
is now **burned** as a gate — it validates the mechanism but is no longer independent.

**b42** (`batch-b42-accrint.json`, 68,790 probes; awaiting capture) is the fresh independent
gate for the revised model, with all-new bonds: `issue` 5–7 whole grid periods before `pcd`
(`D4Q/D6Q`), on-grid deep-skip (`GB`), month-end-on-grid leap-Feb (`MEG`), annual on-grid
month-end (`GBA`), a double-leap-interior act/act annual (`LYD`), a 10-period c1 walk (`LW2`),
an issue-inside-canonical control (`SB2`), and the `CW` family. Predictions for all 68,790
rows are in `agentW_b42_predictions.json` for an instant post-capture diff; anything off
beyond the rate-0.0615 ±1-ULP bistable class flags a residual rule.

## Files

- `agentW_emu.py` — exact day-counts + calendar (SSE2 f64).
- `agentW_model2.py` — the identified model (`model_c0`, `model_c1`, `issue_period` with the
  skip-rule / strict boundary); run directly for the b39 score + per-class breakdown.
- `agentW_c0fix.py` — the c0 skip-rule derivation, scores both b39 and b40.
- `agentW_pubrace.py`, `agentW_x87race.py`, `agentW_c1race.py`, `agentW_c1x87.py` — the
  staging races behind the refutation ledger.
- `gen_b40_accrint.py` → `batch-b40-accrint.json` (+ `agentW_b40_predictions.json`); spent gate.
- `gen_b42_accrint.py` → `batch-b42-accrint.json` (+ `agentW_b42_predictions.json`); fresh gate.
- `agentW_patch_accrint.md` — Rust-ready replacement for `accrint_kernel` + regression tests.
