# agent-X — G6-03c DURATION / MDURATION

## Status: LANDED + PROMOTED (commits 371e012, + c4fe46c for the check_mduration bin)

Two identification iterations, both gated on FRESH pre-registered corpora:
1. b44 (6,360 rows): the core kernel — `off=(E-A)/E`, `excel_bond_pow` discount,
   `(diff*cash)/disc` Macaulay body op-graph. 2247 -> 6217 exact. b45 gate CAUGHT
   a month-end break the b44 ident corpus could not (see below).
2. b45/b46: the month-end accrued-span (CoupDaysBS adjustment-order) fix.
   b46 promotion gate: DURATION 641/720 exact, all misses ±2, ZERO material;
   MDURATION 644/720 mirroring. Coordinator re-verified independently (all three
   corpora re-scored, full suite 1,609 green) and committed.

Result: two catalog witnesses closed, two material classes eliminated (bases 2/3
0/1272 -> exact; the month-end 2.5e13-ULP explosions -> gone). Remaining ±1-2
off-coupon class is the SHARED fractional x87 pow-chain wall (cross-referenced
with PRICE's 14 open b37 rows), recorded as landed-with-open-residual.

## Outcome (iteration 1)

`duration_kernel` (crates/oxfunc_core/src/functions/bond_core_family.rs) rewritten.
b44 (6,360 live-Excel rows, build 20131): **2247 -> 6217 exact (97.75%)**.

| basis | before | after |
|-------|--------|-------|
| b0 (30/360)      | 752  | 1248 |
| b1 (act/act)     | 730  | 1240 |
| b2 (act/360)     | 0    | 1239 |
| b3 (act/365)     | 0    | 1242 |
| b4 (eur 30/360)  | 765  | 1248 |
| **TOTAL**        | 2247 | 6217 |

All MATERIAL b2/b3 failures (was 0/1272) closed. On-coupon rows 100% exact,
including both catalog witnesses. `cargo test -p oxfunc_core`: 1512 passed, 0
failed. No pre-existing pin moved. New pin test `duration_matches_live_excel_pinned_witnesses`.

## The identified kernel

```
off  = (E - A) / E                         # E,A from dc()/dd() like pcomp
if n==1: return max(off/f, 0)
base = 1 + yld/f
num=den=0
for k in 0..n:
    diff = off + k
    disc = excel_bond_pow(base, diff)      # binexp int / excel_pow_chain frac
    num += diff*coup / disc                # LEFT-ASSOC (diff*coup)/disc
    den += coup / disc
    if last: num += diff*100 / disc; den += 100 / disc   # SEPARATE redemption term
return num/den/f
```

Three forks resolved:

1. **off = (E-A)/E** (prior 1, CONFIRMED). The docs-era kernel used the direct
   `dd(settlement, next)` span for the weighting exponent while its `dirty`
   denominator (from `pcomp`) used the landed `E-A` complement — a mixed state.
   For bases 0/1/4 the two coincide (except settlement-on-31st); for bases 2/3
   they diverge materially -> the 0/1272 failure. Unifying to `(E-A)/E` in one
   internally-consistent kernel (numerator and denominator discount the SAME
   cashflows with the SAME off) closed it.

2. **Discount = excel_bond_pow** (prior 2, CONFIRMED). Integer exponents
   (on-coupon, off=1) -> binary exponentiation; fractional -> the legacy x87
   `exp(RN53(RN64(exp*ln)))` chain (`excel_pow_chain`). Same PRICE substrate.
   Full-corpus pow race: powf/binexp 5943, x87binexp(RN64 mul) 6033,
   x87binexp53(RN53 mul) 6217. RN53 is the match.

3. **Body op-graph** (prior 3 "body class open", RESOLVED — NEW fact). Isolated
   on the 24 basis-independent on-coupon signatures (off=1 exactly makes the
   value a pure function of coupon/yld/freq/n, so all 5 bases collapse — the
   discount pow is exact-integer binexp, removing the pow confound). Brute-forced
   the accumulation/grouping/division association: **24/24 exact ONLY for**
   `num += (diff*cash)/disc` grouped left-assoc (NOT `diff*(cash/disc)`), with
   the redemption as a SEPARATE term (`den += 100/disc` separately), forward
   order. The `/f` association (in-loop vs final `num/den/f`) is a free choice
   (both bit-identical). Body arithmetic is plain-f64 SSE2: x87 per-op double
   rounding is neutral (+3 rows on the full corpus, 0 on the on-coupon subset).

## Refutation ledger

- `diff*(cash/disc)` grouping (the docs-era `t*cash/disc` with `t=(off+k)/f`):
  18/24 on-coupon (loses 6), 3120 full-corpus. REFUTED. The winning grouping is
  `(diff*cash)/disc`.
- Redemption FOLDED into last coupon cash (`coup+100`): 14/24 on-coupon. REFUTED.
  Redemption is a SEPARATE accrued term (pcomp-style).
- `off = dd(settlement,next)/e` (direct span): bases 2/3 catastrophic
  (5e13 ULP), b0 615. REFUTED.
- Fractional pow = platform `powf` (SSE2 pow): on-coupon 44/24-int (worse),
  full 5943. REFUTED — integer path must be binexp, fractional the x87 chain.
- x87 exp*ln chain for INTEGER exponents (not binexp): on-coupon 36/132.
  REFUTED. On-coupon discounts are binexp.
- x87 double-rounded body arithmetic: neutral (+3 full, 0 on-coupon). REFUTED as
  necessary; body is plain SSE2 double.
- x87 base (`1+yld/f` double-rounded), x87-multiply binexp: neutral. REFUTED.

## Open residual (banked)

143 rows still ±1-2 ULP: distribution `{-2:14, -1:59, +1:56, +2:14}` — clean,
symmetric, no larger errors. ALL are OFF-COUPON (fractional off) rows; every
on-coupon signature is exact. Spread across bases (b0 24, b1 32, b2 33, b3 30,
b4 24) and yields (heaviest at the extremes y0.2 35, y0.001 21). This is the
shared fractional x87 pow-chain wall — the same one PRICE left open on b37 bases
2/3 (~14 rows). It is NOT DURATION-structural; closing it means improving
`excel_pow_chain` itself (cross-lane, affects PRICE/YIELD too), out of scope for
G6-03c. Per-row list: agentX_b44_residual143.json.

## MDURATION

`mduration_kernel` unchanged = `duration_kernel / (1 + yld/f)`. Inherits the
DURATION fix. Division staging not yet gated on live MDURATION captures — the
b45 gate includes a parallel MDURATION batch (batch-b45-mduration.json, 540
rows) to validate it. Predictions pre-registered: agentX_b45m_predictions.json.

## b45 held-out gate (PRE-REGISTERED, awaiting coordinator capture)

Fresh bonds FA..FE (distinct from b44), freq 1/2/4, on-coupon + 31st/month-end +
leap-Feb settlements, bases 0-4, extreme yields 0.0001..0.35.
- batch-b45-duration.json (540) -> predictions agentX_b45_predictions.json
- batch-b45-mduration.json (540) -> predictions agentX_b45m_predictions.json
Both produced by the REAL production kernels (check_duration.exe /
check_mduration.exe), 0 ERR. Promotion (commit) pending the gate result.

## The b45 catch: an adjustment-order tell in the 30/360 accrued span (iteration 2)

The b44 identification looked complete at 6217/6360. Then the pre-registered b45
held-out gate came back with 12 MATERIAL misses AND EVERY ONE A MONTH-END/31st
settlement — FC-45747 (2025-03-31, basis 0) off by ~2.5e13 ULP across all six
yields at once. A yield-independent explosion of that size is never arithmetic;
it is a wrong integer QUANTITY upstream of the discounting. The residual told us
WHERE (month-end) and HOW MUCH (integer-scale), so we followed it straight in.
The b44 corpus was too thin on Feb-end-previous + 31st settlements to have ever
surfaced it: the pre-registered gate found what the ident corpus structurally
could not.

b45 verdict: 456/540 exact, 72 ±1-2, 12 MATERIAL — every material row a
month-end/31st settlement. Root cause: the accrued span A was computed with
`dd` = `us_30_360`, but Excel's `CoupDaysBS` (F# `IDayCount.DaysBetween`,
numerator position) for US 30/360 is `dateDiff360US ... ModifyStartDate` =
`diff360_us(prev, settle, false)`. The two diverge on 31st/month-end settlements
because of ADJUSTMENT ORDER:

- `us_30_360`: adjusts Feb-end start (sd->30) FIRST, then collapses end 31->30
  (since sd>=30). For (2025-02-28 -> 2025-03-31): a = 30.
- `diff360_us(_,_,false)`: checks `end==31 && sd>=30` with sd STILL 28 (start not
  yet adjusted) -> end stays 31 -> then Feb-end start -> 30. a = 31 (= Excel).

`off = (E - A)/E` unchanged; only A's convention was wrong. Verified against the
exact solve: on every material row the corrected integer A yields the
correctly-rounded true duration within ±2 ULP of Excel (a 1-ULP error in A would
instead move duration ~1e13 ULP — the observed FC-45747-b0 ~2.5e13 explosion).

Fix (one line): `a = days_between_num(p.prev, c.settlement, c.basis)` instead of
`dd(...)`. Changes ONLY basis 0 (bases 1/2/3 use actual days = settle-prev, basis
4 uses d360eu; all unchanged). Post-fix, real-kernel scores:
- b44: 6217/6360, MATERIAL 0 (no regression — b44 had few month-end b0 rows).
- b45: 456 exact, 77 ±1-2, 7 ±3 — the 2.5e13 explosions ELIMINATED; all
  non-exact now <=3 ULP. MDURATION mirrors (division staging confirmed fine).

Remaining month-end residual is NOT structural: with the correct A, the residual
is the arithmetic/pow-chain micro-rounding wall (uniform across yields,
concentrated on month-end because those `off` values round unluckily). Op-graph
re-confirmed optimal on the 240 month-end rows: `dc_d`/`sep` = 167/240 with the
x87 pow (vs 153 exact-pow); a ±3 tail of 7 rows is the excel_pow_chain precision
limit (shared with PRICE — closing it needs real-hardware x87 pow, cross-lane).

En route, ruled out for the post-fix residual: full-64-bit-register accumulation
(breaks b44 to 45%), per-op x87 spill body (neutral, = plain double), running-
product discounts (breaks b44 to 73%). The body is plain SSE2 double; the wall is
the fractional pow, cross-lane with PRICE.

Added 2 month-end regression pins (Feb-end 2025-02-28 basis 0; 31st 2023-12-31
basis 0) as guards against the explosion class.

## b46 promotion gate — PASSED (commit 371e012)

Month-end/31st settlements + EOM maturities the MAJORITY (570/720 = 79%; leap
2024/2028 + non-leap 2023/2025/2026/2027 Februaries, Dec/Apr/Aug EOM), plus
regular-date controls. Fresh bonds GA..GG. Yields weighted MODERATE (0.02-0.10)
to stress the day-count over the pow-wall, plus 0.005/0.28 extremes. Predictions
pre-registered before capture.
- batch-b46-duration.json (720) -> agentX_b46_predictions.json
- batch-b46-mduration.json (720) -> agentX_b46m_predictions.json

Result: DURATION 641/720 exact, all misses ±2, **ZERO material**; MDURATION
644/720 mirroring. Coordinator re-verified independently (all three corpora
re-scored through check_duration, full suite 1,609 green) and committed 371e012
(+ c4fe46c for the check_mduration bin). Catalog G6-03c row updated to
landed-with-open-residual; the ±1-2 off-coupon class recorded as the SHARED
pow-chain wall, cross-referenced with PRICE's 14 open b37 rows.

## Tools (agentX_ prefix)

- agentX_durrace.py — full-corpus variant racer (off/pow/tstage/arith).
- agentX_bodyrace.py — int-off (on-coupon) body-staging isolation.
- agentX_opgraph.py — brute-force op-graph enumerator on on-coupon signatures (found the grouping).
- agentX_full.py — full kernel with identified op-graph, pow race.
- gen_b45_duration.py — held-out battery generator (DURATION + MDURATION).
- check_mduration.rs — new production-MDURATION scorer bin.
