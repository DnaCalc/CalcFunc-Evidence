# W109 — Open-set structured sweep (residual-first, no match-count). 2026-07-14

Two-cycle campaign over all open catalog rows except CONVERT (G4-05).
Protocol per function: measure signed δ = ULP(Excel) − ULP(candidate); READ its structure
(smooth/high-freq, where |δ| concentrates, sign, magnitude law); map structure→axis; kill
cheap axes first (SSE/x87, powf/binexp, extended-prec); YIELD test = max|δ|<0.5 OR held-out
100%, never a match count. Unresolved → emit a follow-up recipe for Phase 4.

## Phase 0 — dedup (DONE)
- **Excluded (derived, inherit primary):** CHISQ.TEST/CHITEST≡CHIDIST; F.TEST/FTEST≡2·FDIST
  (both proven in the 2026-07-12 sweep); **MDURATION≡DURATION/(1+y/f)** confirmed 3/3 here.
- **ACOTH NOT excluded:** ACOTH(x)==ATANH(1/x) only for |x|≤2.5; DIFFERS 1–2 ULP (up to ~26 at
  x=100) for |x|≥3. DIAGNOSIS: OxFunc's large-|x| ACOTH branch = ATANH(1/x) is the WRONG form;
  Excel's large-|x| ACOTH is a distinct routine. Residual is localized to |x|≥3. (`p0_acoth_out.json`)
- **Inversion families:** YIELD←PRICE(landed), ODDFYIELD←ODDFPRICE, RATE←annuity, IRR←NPV,
  {CHI,F,T,GAMMA,BETA}INV←their forward CDFs. Sweep forwards; ONE solver-VM covers inversions.

## Primary discovery set + probe (archetype / lens / bounded probe / yield test)
- **ATANH (G4-02)** — threshold. 6-row switch band. Dense adjacent-double capture across the
  region boundary; pin the exact switch double + the band form. Yield: band → 0.
- **ACOTH (G4-03)** — large-|x| form. Dense |x|∈[2.5,100] capture; race direct-ratio
  0.5·ln((x+1)/(x-1)) vs alternate ln1p pairs (x87) for |x|≥3. Yield: |x|≥3 → 0, 0 regress small.
- **GAUSS (G3-07)** — erf/CDF substrate. Sweep z; is δ a constant bias or shape? cheap decode;
  else defer to erf substrate.
- **DURATION (G6-03c)** — staging residual OUTSIDE discount powers. Capture DUR sweep; race
  Σt·cash/disc accumulation order, t=(off+k)/freq staging, w/dirty division; binexp discount on.
- **ACCRINT (G6-02)** — accumulation order. Capture settlement>first battery; mirror exact
  odd-coupon branch; race settlement-first vs backward.
- **CUMPRINC (G6-07)** — half-schedule accumulation. Capture range sums; PPMT-row reuse order.
- **MINVERSE 9-cell (G5-01)** — near-cancellation. Exact-arith probe at the cancellation point;
  already have 3 residual matrices; enumerate solve orderings in exact arith.
- **PMT/PPMT/IPMT (G6-01)** — em final-rounding. n=1 isolation lane; decode the em=expm1 round.
- **TREND/LINEST/LOGEST (G3-03)** + **GROWTH (G3-04)** — accumulator. Metamorphic battery
  (2^k scale, translate, reverse) fingerprints normal-equations order; back-out effective (a,b).
- **GAMMALN core (G3-02)** — custom-MS rational op-graph in (0,11). Decoder + exact-arith probe;
  pin the 3 residual x≥11 rows + the (10.25,11] boundary. Core = known wall (bounded confirm).
- **COMBIN/COMBINA/FACTDOUBLE/ERF.PRECISE (G4-04)** — own integer/product path vs lgamma.
  Capture; test integer-arith form; ERF.PRECISE needs erf substrate.
- **Distributions forward CDFs (G3-01)** — incomplete-β/γ CF substrate (downstream of G3-02).
  Bounded: confirm substrate dependency; the *INV are solver-derived.
- **Solver forwards:** ODDFPRICE (apply binexp), NPV, annuity — then ONE solver-VM (expanded
  axes: analytic deriv, x87 iteration, price/duration seed) for YIELD/ODDFYIELD/RATE/IRR.
- **PRICE (G6-03b)** — landed; broaden live PRICE sweep for sign-off + row removal.

## Phases
1 serial capture → 2 parallel analysis → 3 synthesis + recipes → 4 serial recapture (recipes)
→ 5 parallel analysis → 6 synthesis (terminal; residuals exit with a recipe).

## Phase 1 captures (DONE, ~174 pts): batchA transcendentals(89), batchB combin+dist(45),
## batchC financial(27), batchD regression(13). All in scratchpad p1_batch*_out.json.

## Phase 2 — residual map (δ = ULP(Excel) − ULP(OxFunc), total-order)
| fn | n | exact | \|δ\|max | structure → Phase-3 verdict |
|---|---|---|---|---|
| ATANH | 26 | **26** | 0 | clean on sweep; band NOT hit → recipe: adversarial recapture |
| FACTDOUBLE | 7 | **7** | 0 | clean on sweep → recipe: larger n |
| PMT | 2 | **2** | 0 | clean on sweep; full corpus ~57% wall → recipe: adversarial |
| ODDFPRICE | 5 | 3 | 2 | ±1/2 → **apply binexp (pure double), likely YIELDS** |
| ACCRINT | 4 | 3 | 1 | −1 edge → accumulation order (pure double, race) |
| DURATION | 10 | 6 | 2 | ±1/2 outside discount → Σ/w-div staging (pure double, race) |
| CUMPRINC | 3 | 0 | 4 | ±2/4 → PPMT accumulation order (pure double) |
| ERF.PRECISE | 8 | 7 | 1 | +1 one pt → recipe: denser |
| ACOTH | 23 | 16 | 2 | \|x\|≥4 x87-ln1p staging + switch too low → recipe |
| GAUSS | 15 | 6 | 4 | ±1/4 erf/CDF staging → recipe: capture ERF(z/√2) path |
| COMBIN/COMBINA | 14 | 8 | 5 | ±1/5 → recipe: exact-integer product vs lgamma |
| GAMMALN | 17 | 5 | 32 | ±1/32 custom rational; boundary 10.25–11 all −1/−3 | core wall; boundary maybe |
| GAMMADIST/BETADIST/NEGBINOM/HYPGEOM | 10 | 5 | 3 | ±1/3 dist substrate |
| CHIDIST | 6 | 0 | **6224** | incomplete-γ CF substrate WALL |
| FDIST | 4 | 0 | 56 | incomplete-β substrate WALL |
| TDIST | 4 | 0 | 50 | incomplete-β substrate WALL |
| LINEST/TREND (regr) | — | — | — | reverse-rows shifts intercept 128 ULP → summation-order (pure double) |

**Phase-2 yield candidates (pure double, raceable now):** ODDFPRICE(binexp), DURATION, ACCRINT,
CUMPRINC, MINVERSE-9cell, LINEST/TREND. **Staging recipes (Phase 4):** ACOTH, GAUSS, ATANH-band,
ERF.PRECISE, COMBIN. **Substrate walls (bounded-confirm):** CHIDIST/FDIST/TDIST, GAMMALN-core, dist family.

## Phase 3 — synthesis (cycle 1)
**YIELDED & landed:** ODDFPRICE (binexp, 5/5 bit-exact, commit 5353865).
**Staging races that did NOT yield in bounded effort (→ op-graph-outside-family, like GAMMALN):**
- DURATION: 96-variant staging race {disc-pow × dirty-source × t-form × term-order × final-div}
  over the real kernel maxes 7/10. Residual is OUTSIDE those axes. Recipe (Phase 4): probe the
  dsc/off computation + cash-flow structure; capture Excel's intermediate per-term PV to localize.
- LINEST/TREND regression: raw-computational / centered / det-intercept candidates miss slope by
  2-3 ULP. Excel uses the least-squares (normal-equations/QR) pipeline, NOT the simple centered
  kernel (which SLOPE/FORECAST use bit-exactly). Recipe: enumerate the full LINEST stats-order
  (SSE/df computed alongside), QR/Householder, higher-precision accumulation. (Background workflow
  wu09okivf is running an exhaustive regression + COMBIN + distribution race.)
**Confirmed structure:** ODDFYIELD ~3e5 ULP = PURE schedule (forward fixed). ACOTH = switch-threshold
too low + large-|x| ln1p staging (direct-ratio 0.5·LN((x+1)/(x-1)) exact ≤3.5, cancels ≥4).

## Net: the small residuals (DURATION/regression/ACOTH/GAUSS/ACCRINT/CUMPRINC) are the SAME class
## as GAMMALN/PMT — op-graph outside the obvious parametrized family — just smaller magnitude.
## Bounded staging enumeration characterizes but does not close them; each needs its own deeper
## op-graph ID or a discriminating intermediate capture (Phase 4 recipes emitted per function).

## Phase 3 — background workflow (wu09okivf) verdicts
- **Regression (G3-03):** TREND/GROWTH PREDICTIONS bit-exact (0 ULP) given coeffs. LINEST slope =
  deterministic 2-ULP-LOW bias (Excel less accurate than double; extended → +3, wrong way);
  120×120 orderings all collapse to +2. Corpus NON-DISCRIMINATING (Scxx=exact 10). Recipe:
  design-for-divergence capture (non-integer Scxx, minimal 2/3-pt, LINEST SS/SE ancillary outputs).
- **COMBIN/COMBINA (G4-04):** COMBIN = float product, bit-exact <2^53 (drift ±2 only past 2^53,
  unrepresentable) → effectively closed. COMBINA = exp(gammaln), NOT product (C(26,7) lands 1 ULP
  below the exact integer) → reduces to GAMMALN wall. Recipe: capture GAMMALN triples + EXP to link.
- **Distributions (G3-01):** shared incomplete-γ/β CF kernel, x87-EXTENDED. OxFunc plain-double CF
  → 6224-ULP boundary catastrophe (1−P complement). Fix: x87-extended CF collapses to sub-20-ULP.
  Wall for bit-exact (needs x87 gser/gcf/betacf op-graph). Recipe: branch sweep + CF-depth test.

## CYCLE-1 SUMMARY: 1 yield landed (ODDFPRICE). COMBIN effectively closed (<2^53). TREND/GROWTH
## predictions bit-exact. Everything else = characterized op-graph/substrate residual with a
## Phase-4 recipe. Two clean dependency reductions: COMBINA→GAMMALN, {CHI/F/T}DIST→one x87 CF kernel.
## Biggest actionable correctness fix surfaced: distributions plain-double CF → x87-extended (6224→<20 ULP).

## CYCLE 2 (2026-07-14): design-for-divergence + self-review
- COMBIN: cycle-1 "bit-exact <2^53" DISPROVEN (16 discriminating pts: Excel matches OxFunc
  multiply-first 6/16, ratio-first 2/16, neither 8/16; 1-3 ULP below product on large n,k;
  double+x87-prec64 all 6/16). Op-graph residual, PERMUT x87-product family. Catalog corrected.
- COMBINA→GAMMALN CONFIRMED (C(26,7) = 657799.9999999999, 1 ULP below exact integer).
- No new closes; self-review caught + fixed the committed over-claim. Commit b72ef6d.

## CYCLE 3 (2026-07-14): PRICE sign-off sweep → found a MATERIAL latent bug
- 90 live-Excel PRICE pts (5 bases × 6 bonds × 3 yields). Bases 0/4 bit-exact, basis 1 near-exact
  (one +1 ULP), **bases 2 (Actual/360) and 3 (Actual/365) MATERIALLY wrong** (~0.035 / ~0.013 low,
  dollars not ULP). Pre-existing (fractional exps, untouched by binexp), never caught. Root cause:
  pcomp's `e=360/freq`/`365/freq` for the actual-day bases vs actual-day `dsc` → wrong exponent.
  → new catalog row G6-03d (shared by YIELD/DURATION). PRICE sign-off BLOCKED. Fix = act/360-365
  coupon-period convention (mirror the ODDFPRICE act/act per-quasi-period day-count sum).
- Self-review corrected an over-claim (basis 1 is near-exact, not bit-exact). Counts 21→22, G6→10.

## CYCLE 4 (2026-07-14): PRICE act/360-365 reverse-engineering (refined, not closed)
Ruled out the simple fixes for G6-03d: E=actual → act/act price (114.6012≠114.5887); money-market
days/(360|365/freq) → 114.37/114.58; hybrid off=DSC/Eact + accr A/(yb/freq) → 114.57/114.59. None
match Excel act/360 (114.5887) / act/365 (114.5966). OxFunc dc (E=360/freq) mirrors EFF coupDays →
either EFF PRICE is off here or N/DSC differ. Needs systematic reverse-eng of N,DSC,E,A per basis.
