# ERFC campaign monitor

Host: dna-firehorse. Out dir on the host:
`/data/projects/DnaCalc/OxFunc/smart-fuzzer/work/w109/erfc-campaign/`

From the Windows box:

```
scp dna-firehorse:/data/projects/DnaCalc/OxFunc/smart-fuzzer/work/w109/erfc-campaign/STATUS.md .
scp dna-firehorse:/data/projects/DnaCalc/OxFunc/smart-fuzzer/work/w109/erfc-campaign/REGION_MAP.md .
ssh dna-firehorse -- tmux capture-pane -t oxfunc-erfc-campaign -p | tail
```

Stop after the current chunk: drop an empty file named `STOP` in the out dir.
Resume: same `run-erfc-campaign.sh` (completed progress keys are skipped).

This campaign does not land an ERFC body. HIT_ALL_MID, if present, is a
discovery alert — not a production identity.
