# ERFC campaign STATUS

- region: `exit`
- chunk: `-`
- configs_done: 101474
- best_exact: 6005  `nswc_x87cont_zzdr_store_mid15`
- best_mid: 3332 / bar 3332  max_ulp=7  `nswc_x87cont_zzdr_store_mid15`
- best_pins: 1
- runtime_hours: 0.03 / 0.03
- threads: 8
- stop_requested: false
- progress_keys: 5

Stop: `touch STOP` in this directory. Resume: same command.
Alert files: `HIT_ALL_MID` (all mid rows exact), `HIT_PIN` (a pin went exact).

campaign process exiting (time, STOP, or interrupt). resume = same command.

# ERFC campaign REGION_MAP

16-bit cubes enumerate Horner-stage store sites (bit i = spill after stage i).
Native / every-op-spill / all-stage-spill are single configs (mask-insensitive).

| id | space | next | note |
|---|---|---|---|
| R0 | named F + implied-F | done | baselines |
| R0c | NSWC P/Q/R ±1 ULP | done | last-bit decimals |
| R1base | mask-insensitive arith | done | Native/Every/Pc53/Stage |
| R1/z0/r0 | 0..0x10000 | done | NSWC P/Q store-mask, X87Cont, PQR on [0.5,4), zz_dr=false uvC |
| R1/z0/r1 | 0..0x10000 | 0x8c00/0x10000 | NSWC P/Q store-mask, X87Cont, PQR on [0.5,4), zz_dr=false uvS |
| R1/z0/r2 | 0..0x10000 | 0x0000/0x10000 | NSWC P/Q store-mask, X87Cont, PQR on [0.5,4), zz_dr=false uvR |
| R1/z1/r0 | 0..0x10000 | 0x0000/0x10000 | NSWC P/Q store-mask, X87Cont, PQR on [0.5,4), zz_dr=true uvC |
| R1/z1/r1 | 0..0x10000 | 0x0000/0x10000 | NSWC P/Q store-mask, X87Cont, PQR on [0.5,4), zz_dr=true uvS |
| R1/z1/r2 | 0..0x10000 | 0x0000/0x10000 | NSWC P/Q store-mask, X87Cont, PQR on [0.5,4), zz_dr=true uvR |
| R1m/z0/r0 | 0..0x10000 | 0x0000/0x10000 | NSWC P/Q store-mask, mid_cut=1.5 AA/BB above, zz_dr=false uvC |
| R1m/z0/r1 | 0..0x10000 | 0x0000/0x10000 | NSWC P/Q store-mask, mid_cut=1.5 AA/BB above, zz_dr=false uvS |
| R1m/z0/r2 | 0..0x10000 | 0x0000/0x10000 | NSWC P/Q store-mask, mid_cut=1.5 AA/BB above, zz_dr=false uvR |
| R1m/z1/r0 | 0..0x10000 | 0x0000/0x10000 | NSWC P/Q store-mask, mid_cut=1.5 AA/BB above, zz_dr=true uvC |
| R1m/z1/r1 | 0..0x10000 | 0x0000/0x10000 | NSWC P/Q store-mask, mid_cut=1.5 AA/BB above, zz_dr=true uvS |
| R1m/z1/r2 | 0..0x10000 | 0x0000/0x10000 | NSWC P/Q store-mask, mid_cut=1.5 AA/BB above, zz_dr=true uvR |
| R1r/z0 | 0..0x0200 | 0x0000/0x0200 | NSWC R-stage 9-bit mask, uv store, zz_dr=false |
| R1r/z1 | 0..0x0200 | 0x0000/0x0200 | NSWC R-stage 9-bit mask, uv store, zz_dr=true |
| R4/z0/r0 | 0..0x10000 | 0x0000/0x10000 | NSWC AA/BB store-mask, mid_cut=1.5, zz_dr=false uvC |
| R4/z0/r1 | 0..0x10000 | 0x0000/0x10000 | NSWC AA/BB store-mask, mid_cut=1.5, zz_dr=false uvS |
| R4/z0/r2 | 0..0x10000 | 0x0000/0x10000 | NSWC AA/BB store-mask, mid_cut=1.5, zz_dr=false uvR |
| R4/z1/r0 | 0..0x10000 | 0x0000/0x10000 | NSWC AA/BB store-mask, mid_cut=1.5, zz_dr=true uvC |
| R4/z1/r1 | 0..0x10000 | 0x0000/0x10000 | NSWC AA/BB store-mask, mid_cut=1.5, zz_dr=true uvS |
| R4/z1/r2 | 0..0x10000 | 0x0000/0x10000 | NSWC AA/BB store-mask, mid_cut=1.5, zz_dr=true uvR |
| R2/z0/r0 | 0..0x10000 | 0x0000/0x10000 | Cody C/D store-mask, zz_dr=false uvC |
| R2/z0/r1 | 0..0x10000 | 0x0000/0x10000 | Cody C/D store-mask, zz_dr=false uvS |
| R2/z0/r2 | 0..0x10000 | 0x0000/0x10000 | Cody C/D store-mask, zz_dr=false uvR |
| R2/z1/r0 | 0..0x10000 | 0x0000/0x10000 | Cody C/D store-mask, zz_dr=true uvC |
| R2/z1/r1 | 0..0x10000 | 0x0000/0x10000 | Cody C/D store-mask, zz_dr=true uvS |
| R2/z1/r2 | 0..0x10000 | 0x0000/0x10000 | Cody C/D store-mask, zz_dr=true uvR |
| R1p/z1/r1 | 0..0x10000 | 0x0000/0x10000 | NSWC P/Q store-mask, X87Pc53, zz_dr, uv store |

best_mid: 3332 / bar 3332  `nswc_x87cont_zzdr_store_mid15`  max_ulp=7  pins=1
best_all: 6005  `nswc_x87cont_zzdr_store_mid15`

