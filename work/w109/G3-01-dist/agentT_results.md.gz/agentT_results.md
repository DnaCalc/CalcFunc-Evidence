# Lane 8 — BINOM.DIST dbinom_raw argument: b34 exact-interval solve (agent-T)

W109 / G3-01 distribution campaign. Offline solve of the integer-ULP
term-correction system for Excel's `BINOM.DIST(k,n,p,FALSE)` internal exp
argument, using the banked **b34** window corpus (6 anchors × 10 windows ×
400 consecutive p-ULPs = 24,000 rows) and **b29** (1,062 general-k rows).
No Excel captures run; all answers banked. STRICT BLACK-BOX; real hardware
chain via `cexpext2` (x87 F2XM1); exact interval arithmetic at mp.prec=200.

Pinned model (task spec): `arg = ext64(lc − 0.5·lf)` delivered extended into
the fFEXP chain; `lc`,`lf` per-op RN53 double locals; bd0 series/direct with
threshold 0.1; stirlerr table (≤15) / R S0..S4 (>15).

## Headline

The b34 corpus was converted into **24,000 exact per-row argument-offset
intervals** (the chain preimage of each published double), a fully-offline
exact oracle for the argument. Two results:

1. **`lp` is identified: `lp = log1p(−k/n)`, R's documented source form** —
   NOT the pinned `ln((n−k)/n)`. Correctly-rounded log1p moves b34
   **27.69 % → 32.29 %** (+1103/24000 rows). This is a genuine family
   member recovered, and it nearly closes the B2 clean windows
   (363/400 with M at +1 ulp). `bd0`-direct does NOT use log1p (worse) —
   direct keeps plain `log(x/np)`.
2. **The last bit is the exact log1p rounding, not the family.** CR-log1p is
   only an approximation of Excel's hardware log1p (x87 FYL2XP1); it does not
   transfer to b29 (34.18 → 34.46 %) nor close the bd0-heavy B4/B6 clean
   windows. The residual is an **operand-continuous sub-op rounding
   difference** (localized to lp's log1p realization + bd0 direct), not a
   discrete integer-ULP class nudge. Pinned plateau reproduced exactly:
   27.69 % (b34) / **34.18 % (b29)** = lane 6's 34.2 %.

## 1. Instrument — exact arg-offset intervals (the durable deliverable)

For each row, Excel's published bits pin the true internal chain argument to
a contiguous cell `[argL, argU)` with `chain(a)==bits`. Both boundaries were
located by **batched bisection through the real hardware chain** (cexpext2),
to ~ulp64 resolution (26 rounds, ±128·ulp53(arg) bracket, 0 clamps on 48,000
boundaries; 31 s total). Output = `[argL−model, argU−model]` per row
(`agentT_intervals.json`).

Fidelity check: the offline interval test (`δ∈[dlo,dhi]`) and the end-to-end
chain both give **6646/24000** for the pinned model — the instrument is
exact. Consequence: **candidate identification now needs zero chain calls**
(pure mpf arithmetic against the banked intervals), the oracle lane 6 wanted.

Files: `agentT_intervals.py`, `agentT_intervals.json` (24k rows,
arg+dlo+dhi+ulp53+ulp64 as exact strings).

## 2. Per-window delta_w (exact constant-offset intervals)

`agentT_overlap.py` → `agentT_deltaw.json`: per window, the max-overlap δ
interval (interval-stabbing of the 400 row-intervals) and its depth (# rows
sharing a constant offset).

- **~17 windows are clean constant-offset** (depth ≥ 390 / 400): all the
  extreme-p windows w05–w09 of B2/B3/B4/B5/B6 and B1-w06. Their δ_w is one
  exact number (width down to 0/2⁻⁶⁴ — a single ulp64 point).
- **Steep-staircase mid windows** (w03–w05) have depth 40–175: the required
  offset **drifts smoothly with p** (per-row centers wander ±5…±24·2⁻⁵³, e.g.
  B3-w04), i.e. a genuine p-dependent sub-double residual, not scatter.
- **Near-mode windows** (w00,w01) have wide intervals (>1 ulp53) — weak
  constraints.

## 3. Mixed-class structure — NONE within windows

`agentT_classes.py` → `agentT_classes.json`: every 400-p window is
**class-homogeneous** — no bd0 branch flips, no bd0-value binade crossings,
no np binade crossings inside any window. So the low-depth windows are **not**
caused by the branch/binade transitions the task anticipated; there are no
within-window split points in b34. Low depth = smooth p-drift of the
sub-double residual within a single fixed class.

## 4. Delivery — EXTENDED, confirmed

`agentT_delivery.py` → `agentT_delivery.json`: does a representable double
lie in each row's exact arg-interval?
- Extreme-p windows of B1–B5: **0/400 rows admit any double** (interval width
  0.02–0.19 ulp53 ≪ 1 ulp53). A 53-bit (spilled) arg is impossible → delivery
  carries sub-double content = **extended**. Double/RN53 final delivery
  REFUTED.
- Caveat: "admits a double" is necessary-not-sufficient. B6 extreme-p windows
  show 355–400/400 admitting a double, but their δ_w is a **constant**
  extended offset (§5); a double delivery would give a p-varying spill error,
  which is not observed. So delivery is extended for B6 too — the coincidental
  double-straddling does not refute it.

## 5. The linear system & realization match

The clean-window offsets are exact constants that **vary window-to-window
within one anchor** (e.g. B2-w06/w08/w09 = −2.14 / −2.18 / −2.68 ·2⁻⁵³),
tracking the bd0 operand (np binade), so the correction is genuinely
per-(anchor, bd0 class), as designed.

**FOUND — `lp = log1p(−k/n)` (`agentT_cand3.py`).** R's dbinom_raw source is
`lf = M_LN_2PI + log(x) + log1p(−x/n)`; the pinned model used the algebraic
equivalent `ln((n−k)/n)`, which rounds differently. Switching lp to
correctly-rounded log1p:
- b34 interval score **6646 → 7749 / 24000 (27.69 → 32.29 %)**;
- B2 clean windows (k=1,n=12) go 0 → 155/400, and **0 → 363/400 with
  M_LN_2PI at +1 ulp** — a near bit-exact close of that class;
- `bd0`-direct log1p makes it **worse** (25.4 %) — direct branch keeps plain
  `log(x/np)` (its argument is never near 1). Confirmed.

The remaining residual is the **exact log1p rounding** (CR-log1p is an
approximation of Excel's hardware log1p; see §7) plus the bd0-direct op-graph.
Two facts still break a discrete integer-ULP-class solution for the residue:

**(a) No further family realization reproduces the residual clean offsets.**
Tested offline against all 24k intervals and end-to-end
(`agentT_cand.py`, `agentT_cand2.py`, `agentT_verify.py`), all ≤ pinned and
none landing the bd0-heavy (B4/B6) clean windows:

| realization | result |
|---|---|
| bd0 assoc A `((xL+np)−x)` | 23.3 % (worse) |
| bd0 product double-rounded RN64→RN53 | ≡ pinned (never differs on these operands) |
| bd0 extended-L (lnext) — single-prod / full-ext / prod-only-spilled | 23.4–25.0 % (worse) |
| M_LN_2PI ±1 ulp53 | 19.6 % / 27.2 % (worse) |
| lf extended composition | ≡ pinned |
| lf sum-order M(lk lp) / (lk lp)M | 26.6 % (worse) |
| lf per-op DR | ≡ pinned |
| lc per-op DR | ≡ pinned (27.7 %) |
| lc extended (unspilled) | **20.0 %** → confirms lc IS a spilled double |
| final delivery double (RN53) | 27.2 % (worse overall; refuted §4) |

**(b) The residual is operand-continuous, not integer-ULP**
(`agentT_decomp.py`, `agentT_system.py`). Clean δ_w in units of ulp53(b1):
B1-w06 = +0.989, B4-w06 = −0.921 (≈ ±1 ulp53(b1)), but B6-w05…09 =
−0.03…−0.13, B2-w08 = −0.27 — **arbitrary fractions**, not integers or
half-integers. A discrete class nudge would land on integers. Attribution:
- stirlerr is **inert** (small-n table ulp ≈ 2⁻⁵⁸ ⇒ ≤ 0.03·2⁻⁵³ in arg;
  below resolution) — confirms lane 7.
- For k=1 anchors (B1,B2, lk=ln1=0) the lf side can contribute only
  ≤ 1·2⁻⁵³ (M rounding) + ≈2⁻⁵⁵ (lp), yet offsets reach +1.98·2⁻⁵³ ⇒ the
  residual lives on the **lc side, in bd0 DIRECT** (`x·log(x/np)+np−x`, value
  O(1), ulp53 = 2·2⁻⁵³ — exactly the observed scale).

**Conclusion:** after recovering lp = log1p, the remaining wall is the exact
**log1p rounding** (hardware, not CR) and the **bd0 direct** op-graph,
differing from the parametrized realizations by a smooth sub-ulp53 rounding
quantity — the campaign's op-graph-wall signature (memory: "outside any
parametrized family; not closable by more fitting"), now pinned to two
primitives with exact per-window residual intervals.

## 6. Verification (end-to-end through cexpext2)

`agentT_verify.py` / `agentT_cand3.py`:
- **b34**: PINNED 6646/24000 = 27.69 %; **lp=log1p 7749 = 32.29 %**;
  both-log1p 28.83 % (worse — bd0 must stay plain log); lc_dr/bd0_Bdr ≡ pinned;
  bd0_A 23.3 %.
- **b29**: PINNED **363/1062 = 34.18 %** (= lane 6 plateau); lp=log1p 34.46 %
  (CR-log1p barely transfers — the windowed b34 gain is coherent, the random
  b29 corpus needs the exact hardware log1p rounding). Misses concentrate on
  direct/direct rows; series/series rows land.

## 7. Residual & designed next battery

Residual intervals banked exactly (`agentT_deltaw.json`, `agentT_system.json`).
Priority order (all offline against the banked 24k intervals once the ops
exist — no captures, no chain budget):

1. **`log1p` via x87 FYL2XP1 (top priority — CR-log1p already gives +4.6 %).**
   Excel's log1p is the CRT/x87 realization, not correctly-rounded; its exact
   rounding is what the b29 non-transfer and the un-closed clean windows need.
   Add `log1p x` (FYL2XP1, valid for −0.5<x<1; else fall back to fyl2x) to
   `x87_serve`; re-score lp and re-check whether the B2 M_up coupling is real
   or a CR-log1p artifact.
2. **Fused-register bd0 direct** — compute `x·log(x/np)+np−x` entirely on the
   x87 stack with the division x/np extended too (only the *double* quotient
   was tested), spilled once at the C return. Add `bd0dir x np`. Most likely
   closer for the B4/B6 clean windows (§5b localizes the residue to bd0
   direct).
3. **Excel-lgamma stirlerr** — couples to the lane-2 internal-lgamma wall;
   expected below resolution (2⁻⁵⁸) but sweep once with the real Excel lgamma.

## ROUND 2 (same session) — hardware log1p + bd0dir mask race + exact system solve

Coordinator rebuilt `x87_serve` with `lp1` (FYL2XP1 RN53), `lp1ext`
(extended hi+lo), and `bd0dir x np mask` (16 op-graph masks: quotient
ext/spilled × L ext/spilled × compound one-RN53/per-op × assoc A/B).
Everything below is offline against `agentT_intervals.json` except the final
end-to-end counts. NOTE: `bd0dir` mask must be passed as a RAW INTEGER hex
field (a double-encoded mask reads as 0).

### Probe 1 — hardware log1p: identification CONFIRMED, transfer question ANSWERED

- **hw FYL2XP1 lp1 ≡ CR-log1p at RN53 on ALL arguments in play** — all 6 b34
  anchors and all 59 b29 (k,n) pairs give bit-identical RN53 results
  (`agentT_round2.py`, `agentT_round2_verify.py`). The extended lo parts are
  ±(3.7–6.6)e-18 — FYL2XP1's rounding differs from CR only below RN53
  resolution here.
- Therefore the CR-log1p result IS the hardware result at this site:
  **lp = log1p(−k/n) stands as identified**, and the b29 non-transfer is NOT
  a hardware-vs-CR log1p rounding artifact — the remaining b29 misses have a
  different cause (lc/bd0-side, see probe 2).
- End-to-end (real chain): b34 `lp1` **7749/24000 = 32.29 %** (best single
  realization); b29 `lp1` **366/1062 = 34.46 %** vs pinned 363. `lp1ext`
  (extended lp into extended lf): b34 27.62 %, b29 34.09 % — worse; the
  extended-lf-consumption variant is REFUTED as a global realization
  (it does lift specific windows: B5-w06/07/08 → 388/353/379 of 400,
  B2 near-mode windows → ~280 — per-window, not global).
- `lp1+Mup` (M_LN_2PI+1ulp): global b34 19.72 %, b29 25.71 % — the round-1
  B2 coupling is anchor-local, NOT a global M identification. Per-window:
  `m00_lp1_Mup` lands B2-w05..w09 at 326/363/—/354/218 of 400 (best-in-class
  for the k=1,n=12 anchor) but hurts every k≥2 anchor. Exact reading: the
  needed per-anchor lf-side constant for B2 is ≈ −2·2⁻⁵³ (which lp1+Mup
  produces since ulp53(lf_B2)=2·2⁻⁵³), for B6 ≈ −2·2⁻⁵³ = lf+1ulp — but see
  the solve below: no constant closes any anchor exactly.

### Probe 2 — bd0dir 16-mask race: the ENTIRE op-graph family is REFUTED on the direct-class clean windows

Raced all 16 masks (applied to both b1/b2) × {ln, lp1, lp1ext} × {M, Mup} =
96 candidates over all 24,000 intervals (`agentT_round2.py`,
`agentT_round2_scores.json`):

- Global top: `m00_lp1_M0` (pinned bd0 + hw log1p) 32.04 %; every mask ≠ 0
  is equal or worse in every combination. Masks 10–15 are output-identical
  to mask 0 on these operands; masks 1/2/4 (quotient-ext, L-ext,
  compound-ext) lose 2–4 points.
- **B4-w05..w09 and B6-w05..w09 (direct/direct clean windows): ALL 96
  candidates score 0/400.** The operand-continuous offsets measured in round
  1 are NOT produced by any combination of: quotient extended/spilled, L
  extended/spilled, compound extended with single final RN53, association
  A/B, lp variant, M±1ulp. The bd0-direct op-graph family as parametrized is
  exhausted at these sites.
- Server-op caveat (flagged): `bd0dir` mask 0 differs from the in-process
  pinned `x·L+(np−x)` (with L from the `ln` op) on 750/27,962 operand pairs
  by ±1–2 ulp, concentrated at x=1.0 operands — the server composes the
  degenerate `1.0·L` product path differently. All conclusions above were
  cross-checked with the in-process pinned bd0 (the interval instrument);
  the 0/400 refutations are mask-independent and unaffected.

### The exact system solve — INFEASIBLE in the (c_anchor, m1, m2) family

Solved `delta_w = c_anchor + m1·ulp53(b1) + m2·ulp53(b2)` (m integer ∈
[−4,4], c per anchor) against the exact per-window delta_w intervals
(`agentT_solve.py`, `agentT_solution.json`):

- **No anchor admits a solution**: best coverage 2–5 windows of 10, and the
  covered sets are dominated by spurious series-window assignments (series
  b-values have tiny ulps, so ±4-ulp shifts can fake coverage). The
  direct/direct clean windows are mutually INCOMPATIBLE under any constant:
  e.g. B6-w06/w07/w08 pin δ_w to the exact points −1.8591 / −2.0466 /
  −2.0312 ·2⁻⁵³ — same anchor, same branch class, same code path, spreads
  of ~0.2·2⁻⁵³ ≪ ulp53(b1) (16–128·2⁻⁵³ there). A double-valued b1/b2/lf
  correction CANNOT produce sub-ulp per-window constants that differ across
  windows. B4 clean windows: +1.50 / −29.46 / +2.61..2.64 / +2.66 / +1.94
  (−29.46 ≡ +2.5 mod ulp53(b2)=16 — suggestive but not consistent across
  the anchor).
- **Positive structural fact banked**: each extreme-p window pins its needed
  offset to an EXACT sub-ulp64-wide constant; those constants drift smoothly
  window-to-window at ~0.1–0.2·2⁻⁵³ scale. The generating mechanism sits on
  a grid FINER than ulp53 of every double local in the model — i.e. in the
  extended domain — yet is constant across each window's 400 rows (so it is
  a smooth function of the window's operand point, not a per-row rounding
  sawtooth). No realization in the current family has this shape; the
  natural remaining suspects are (i) a different lc/arg composition where a
  smooth extended quantity survives to the chain entry, or (ii) a
  chain-entry realization detail beyond cexpext2 that varies with the arg
  binade/value. This is the wall's sharpest formulation to date.

### Round-2 verdict

| item | status |
|---|---|
| lp = log1p(−k/n), FYL2XP1 ≡ CR at RN53 | **IDENTIFIED, confirmed** (b34 +4.6 %; best global model 32.29 % / 34.46 %) |
| lf extended-consumption (lp1ext) | refuted globally; per-window lift only |
| M_LN_2PI+1ulp | refuted globally; B2-local surrogate for the −2·2⁻⁵³ constant |
| bd0dir 16-mask op-graph family | **refuted** (0/400 on all direct/direct clean windows) |
| (c_anchor + m1·u1 + m2·u2) integer system | **infeasible** — exact proof from window intervals |
| unresolved | sub-ulp53, per-window-constant, smoothly-drifting offsets; exact values banked in `agentT_deltaw.json` / `agentT_solution.json` |

### Designed round-3 battery (bounded)

Exact exclusion first: stirlerr realizations (extended, alternative tiers,
different coefficients) are bounded by ~ulp53(spart) ≈ 0.03·2⁻⁵³ per anchor
— they CANNOT produce the ±2·2⁻⁵³ offset bodies nor the 0.1–0.2·2⁻⁵³
inter-window drift. Excluded for this wall (consistent with lane 7's
inertness finding). The surviving shape — per-window-constant,
sub-ulp53-grid, ±2·2⁻⁵³ body, non-monotone drift across windows of one
anchor — points at the CHAIN-ENTRY side, re-opening lane 6c's caveat with a
far sharper instrument:

1. **δ_w-vs-chain-state map (zero cost, offline now)**: the 60 banked exact
   δ_w constants vs each window's F2XM1 reduction state (t = arg·log2e:
   its fraction f, its binade, the 2^i scaling). Lane 6c's c(f) map was
   diluted by per-row scatter; the per-window CONSTANTS are clean reads. If
   δ_w correlates with reduction state, the wall is a deterministic
   chain-entry deviation map and the b34 corpus already contains its values.
2. **Chain-entry realization race**: `cexpext2` vs an entry that spills the
   argument through memory (FSTP/FLD tbyte) vs register-resident, and vs an
   entry with the CW precision field toggled around the reduction — needs
   one server op each; the b34 intervals discriminate for free.
3. If both fail: capture design — 2 anchors at matched (k/n, p) but
   different n-tier (n≤15 vs n>35) to isolate any remaining body-side
   n-dependence from the chain-entry map.

## ROUND 3 (same session) — PC53 chain REFUTED; reduction-state map banked; the wall's two-layer decomposition

Server rebuilt with `cexpext2p53` (all chain arithmetic at CW PC=53, F2XM1
full precision, extended entry). Smoke: exp(10) differs from the PC64 chain
by +2 output-ULPs — a genuinely distinct realization.

### The PC53 hypothesis is REFUTED end-to-end (`agentT_round3.py`)

| corpus | chain | pinned arg | lp1 arg |
|---|---|---|---|
| b34 | cexpext2 (PC64) | 6646 = 27.69 % | **7749 = 32.29 %** |
| b34 | cexpext2p53 | 4180 = 17.42 % | 4472 = 18.63 % |
| b29 | cexpext2 (PC64) | 363 = 34.18 % | **366 = 34.46 %** |
| b29 | cexpext2p53 | 112 = 10.55 % | 107 = 10.08 % |

The specific discriminator windows stay dead under PC53: B4-w06 0/400,
B6-w09 0/400, B6-w05/06/07/08 = 26/12/8/3 of 400, B4-w05..w09 ≤ 16/400.
The B6-w06/07/08 incompatible-constant trio is NOT explained by the PC53
reduction. The inlined-under-app-CW hypothesis is out: whatever the chain
is, it is much closer to the full-PC64 CRT chain than to a PC53 variant
(PC53 loses 10–24 points everywhere).

### Probe 1 (free) — delta_w vs F2XM1 reduction state: NO deterministic law (banked)

`agentT_redmap.json`: all 60 windows with (arg, t = arg·log2e, i = rint(t),
f = t − i, parity(i)) against the exact δ_w constants.
- No f-dependence: the B6 clean trio's residues after removing the −2·2⁻⁵³
  body are +0.141 / −0.047 / −0.031·2⁻⁵³ at f = −0.418 / −0.192 / +0.209 —
  no consistent linear or sign law. No parity dependence either
  (B6 w05..w09 parity 1,1,0,0,1 with δ all ≈ −2).
- The map is banked for any future chain-hypothesis to be tested against at
  zero cost.

### NEW exact decomposition — the wall is TWO layers (the round-3 positive result)

Comparing the outlier windows' δ_w against their anchor-family bodies and
ulp53(arg) (`agentT_redmap.json` + deltaw):

    delta_w = body_w + m_w · ulp53(arg),   m_w ∈ {−1, 0, +1}

- B1-w08: −7.4785 = +0.50 body − 1·(8·2⁻⁵³), residual +0.02.
- B3-w09: +64.4219 = +0.42 body + 1·(64·2⁻⁵³), residual +0.02.
- B4-w06: −29.4608 = +2.60 body − 1·(32·2⁻⁵³), residual −0.06.
- The 50/50-bimodal windows (B1-w08, B3-w09, B3-w07/08 second clusters)
  flip between m=0 and m=±1 row by row — this is lane 6/7's known
  "±1-term" class, now identified EXACTLY as ±1 ulp of the FINAL lc
  subtraction (lc and arg share a binade; ±1 ulp53(lc) ≡ ±1 ulp53(arg) =
  2048 ulp64 — the "no-window" rows of the lane-6 j-scan).
- Layer 1 (m_w): a bit-level lc-side rounding discrepancy on specific rows —
  discrete, ±1 ulp53(lc), row-dependent in mixed windows.
- Layer 2 (body_w): the smooth ±2·2⁻⁵³-scale per-window constant with
  0.1–0.2·2⁻⁵³ drift — sub-ulp53 of every double local, unexplained by any
  raced realization (rounds 1–3) and by PC53.

### Ops requested for round 4 (part 3 of the coordinator's plan)

1. `cexpext2p53r hi lo` — PC53 for the REDUCTION ops only (t = arg·log2e,
   frndint, f = t − i), PC64 for everything after F2XM1.
2. `cexpext2p53s hi lo` — PC64 reduction, PC53 only for the post-F2XM1
   finals (+1, scale).
3. `cexpext2mem hi lo` — full-PC64 chain, argument round-tripped through a
   tbyte memory spill before entry (memory-resident vs register-resident).
4. `cexpext2rz hi lo` — PC64 chain with the reduction subtract f = t − i
   executed under RC=chop (the campaign has prior site-dependent-chop
   precedent in the F2XM1 publication family).
All raceable offline-first against the banked instrument by re-bracketing
preimages per chain (31 s per chain for the full corpus).

## ROUND 4 (same session) — all four chain variants REFUTED; the body's magnitude theorem; capture design

Ops raced: `cexpext2mem` (tbyte park control), `cexpext2p53r` (PC53
reduction), `cexpext2p53s` (PC53 finals), `cexpext2rz` (chop on the
reduction subtract). `agentT_round4.py`, `agentT_round4_body.json`.

### End-to-end (b34 / b29, pinned + lp1 argument models)

| chain | b34 pin | b34 lp1 | b29 pin | b29 lp1 | accept windows (lp1) |
|---|---|---|---|---|---|
| cexpext2 (ref) | 27.69 % | 32.29 % | 34.18 % | 34.46 % | all 0/400 |
| cexpext2mem | ≡ ref bit-exact | ≡ | ≡ | ≡ | ≡ |
| cexpext2p53r | 17.55 % | 18.72 % | 10.17 % | 9.60 % | ≤ 21/400 |
| cexpext2p53s | 26.95 % | 30.40 % | 31.92 % | 32.20 % | ≤ 17/400 |
| cexpext2rz | ≡ ref bit-exact | ≡ | ≡ | ≡ | ≡ |

- **mem: transparency control PASSES** (bit-identical on all 2×24,000 +
  2×1,062 evaluations) — the harness entry is clean.
- **rz ≡ baseline bit-exactly everywhere**: the reduction subtract
  `f = t − rndint(t)` is ALWAYS exact at 64 bits on these arguments
  (Sterbenz-class cancellation) — the RC of that site is unobservable.
  Banked as site knowledge: chop-vs-RN hypotheses about the reduction
  subtract are vacuous for this argument population.
- **p53r**: ≈ full-PC53 (the PC damage lives in the reduction), refuted;
  additionally its sparse re-bracketing shows **depth collapse** (10–31
  of 40 vs 40/40 for the baseline) — a PC53 reduction introduces per-row
  jitter, and the observed depth-400 within-window constancy EXCLUDES any
  jittery reduction structurally. The true chain's reduction is exact.
- **p53s**: refuted (worse everywhere); its measurable bodies are
  bit-identical to baseline.

### Layer-2 body residual table (`agentT_round4_body.json`)

Sparse re-bracketed bodies (units 2⁻⁵³, after removing m·ulp53(arg)):
baseline / rz / p53s agree EXACTLY where measurable; p53r has no measurable
bodies (jitter). Anchor pattern (full-corpus values): B1 ≈ +2.0;
B2 ∈ {−2.42, −2.14, −1.08, −2.18, −2.69}; B3 ∈ {+0.72, +0.27};
B4 ∈ {+1.50, +2.54, +2.62, +2.66, +1.94}; B5 ∈ {−0.46, −0.63, −0.62, +0.16};
B6 ∈ {−2.00, −1.86, −2.05, −2.03, −2.00}.

### Bonus refutations (offline, same session)

- **lf = ln(2π·k·(n−k)/n) as a single ln of a staged product** (5 staging
  variants): predicts per-anchor bodies (0, +1, 0, +2, 0, 0)·2⁻⁵³ —
  measured are (+2, −2.2, +0.5, +2.5, −0.55, −2). Refuted.
- **fdlibm-class polynomial exp executed at PC64** on the extended argument
  (`agentT_polyexp.py`, exact mpmath per-op-RN64 emulation): b29 34.09/34.46 %
  — TIES the F2XM1 chain. Two structurally different extended algorithms
  leave the identical plateau.
- **fdlibm at pure double (PC53) on the RN53-spilled argument**: 14.4/14.0 %
  — extended-content consumption reconfirmed INDEPENDENTLY of the chain
  family (the earlier proof was cexpext2-relative; this closes that gap).

### The magnitude theorem (the round's sharpest constraint)

The body is ±(0.2–2.7)·2⁻⁵³ ABSOLUTE in argument space = ±0.2–2.7 OUTPUT
ULPs53 ≈ 400–5500 ulp64 relative. **No extended-precision op detail
(rounding of any single RN64 operation, F2XM1 last-bit behavior, constant
precision) can produce a deviation of that size** — extended-op effects are
~1 ulp64, three orders too small. The body can only come from:
(a) an ALGORITHM-level approximation error smooth in the reduced argument
(a polynomial/rational exp core — the PC64-fdlibm race above shows the one
public candidate ties rather than closes), or (b) a DOUBLE-rounding event
somewhere between the exp core and publication that our composed chains
don't have, or (c) an argument-side staging difference we have not yet
parametrized (operand-dependent at sub-ulp53 of the double locals —
excluded for all raced compositions, but the space of unraced orderings is
not empty). With (a) tied, (b) enumerated-and-refuted at entry/exit, and
(c) infeasible in the (c, m1, m2) family, the wall now requires new DATA,
not new candidates.

### DESIGNED CAPTURE (b35) — matched-argument cross-anchor discrimination

The single question that splits the remaining hypothesis space: **is the
body a function of the ARGUMENT alone (chain-side map) or of the operands
(k, n, p) beyond the argument (argument-side staging)?**

Design: for each of the 6 anchors, choose p so the MODEL argument lands in
a narrow common target range; capture 400-p-ULP windows at 3 matched
targets:
- targets: arg ≈ −20.0, −50.0, −100.0 (binades 2⁴/2⁵/2⁶; all direct/direct
  branch; staircase 20–200 output-ulps/step — within the proven
  delta_w-extraction regime);
- p per (k,n) solved offline from the pinned model (invert
  lc(p) = target + 0.5·lf; one Newton pass on the model, then snap to the
  ULP grid) — I can emit the exact 7,200-probe batch file on request;
- 6 anchors × 3 targets × 400 rows = 7,200 probes, one capture session.

Decision rule (exact, via the banked instrument replicated on b35):
- bodies EQUAL across anchors at each matched target (within the <1 ulp64
  window resolution) ⇒ chain-side deterministic map ⇒ then a dense p-sweep
  of ONE anchor maps the deviation curve δ(arg) completely and the chain
  realization is read off its shape (period/steps vs reduction state);
- bodies DIFFER across anchors at matched arg ⇒ argument-side ⇒ the
  differences at fixed arg directly read WHICH term's staging is wrong
  (k=1 anchors isolate lf; k≥2 add lk; b2 operands differ per anchor).

Either branch converts the wall into a determined read. Awaiting go-ahead
for the b35 capture.

## ROUND 5 (b35 capture round) — FORK DECIDED: argument-side; **lf 2-ln REALIZATION IDENTIFIED**; plateau broken on all three corpora

`answers-b35-binom.json` (7,200 rows) solved with the banked instrument
replicated (`agentT_b35_solve.py` → `agentT_b35_body.json`; 0 clamps,
most windows point-width).

### 1. The fork verdict: ARGUMENT-SIDE

Body (2⁻⁵³, lp1 frame, layer-1 m subtracted) by anchor × matched target:

| anchor | t0 (arg −20) | t1 (arg −50) | t2 (arg −100) |
|---|---|---|---|
| B1 (1,6) | −0.6953 | +0.3596 | −0.4680 |
| B2 (1,12) | −0.3437 | +0.3285 | −0.1560 |
| B3 (2,24) | −0.8514 | +0.1095 | +0.4688 |
| B4 (3,48) | **+1.8047** | **+2.3282** | **+1.8442** |
| B5 (4,32) | +0.1172 | −0.1091 | −0.5310 |
| B6 (5,64) | **−1.4687** | **−2.3280** | **−1.7812** |

At every matched argument the bodies differ across anchors by up to
4·2⁻⁵³ ⇒ the deviation is a function of the OPERANDS, not the argument —
**the chain (cexpext2) is exonerated with positive cross-anchor evidence.**

### 2. The term solve — per-anchor constants read as an lf-ULP vector

B4/B6 carry a large arg-independent component (≈ +2 / −2·2⁻⁵³, present in
b34's series AND direct windows of those anchors too), the rest are small
and arg-varying. 0.5·ulp53(lf) = 2·2⁻⁵³ exactly for lf ∈ [2,4) ⇒ the
constants demand δlf = (B1:0, B2:0, B3:0, **B4:−1**, B5:0, **B6:+1**) ulps
(lp1 frame). Racing lf staging candidates offline, exactly ONE realization
produces that vector:

    lf = (M_LN_2PI + ln k) + (ln(n−k) − ln n)        ["2lnA"]

i.e. **log1p(−k/n) realized as a DIFFERENCE OF TWO SEPARATE HARDWARE
LNs** — historically sensible: the legacy CRT has no log1p, so the port
substituted logs; bd0's `log(x/np)` needed no substitution and stays the
quotient-ln (bd0-2ln raced: WORSE everywhere — refuted). Stirlerr-tier
candidates (4-term/2-term/1-term/extended at n>35) all refuted numerically
(≤0.01 or wrong sign). The other 2-ln groupings (((M+lk)+ln(n−k))−ln n,
(M+(lk+ln(n−k)))−ln n) score identically on B4/B6 but lose on other
anchors — 2lnA's left-to-right grouping is the winner.

### 3. Verification (end-to-end, real chain)

| corpus | pinned | lp1 (round-2 best) | **2lnA** |
|---|---|---|---|
| b34 (24,000) | 27.69 % | 32.29 % | **48.06 %** |
| b35 (7,200) | — | 45.43 % | **68.58 %** |
| b29 (1,062) | 34.18 % | 34.46 % | **45.10 %** |

The dead windows land: B6-w05..09 = **400/355/382/386/400** (from 0/400
under every previous candidate); B4-w05..09 = 245/0/127/185/388; b35
B4 = 361/129/356, B6 = 282/281/329. The 34 % b29 plateau
(lanes 5/6/7 wall) is broken by +11 points.

### 4. Residual map under 2lnA (the remaining wall, exact)

Clean b34 windows, banked-interval offline re-read (units 2⁻⁵³):
B6: +0.00/+0.14/−0.05/−0.03/+0.00 (essentially closed);
B4-w09 −0.06; B4-w06 = +0.54 with **m=−1** (layer-1 lc class, separate
hunt); B5: −0.46/−0.63/−0.62/+0.16; B3: +0.72/+0.27;
B2: −1.14/−1.18/−1.70; B1-w06: +1.98.
Structure: the big-n anchors are DONE; the residual now concentrates on
SMALL-n anchors (B1/B2) and mid (B3/B5), arg-varying, ±(0.2–2)·2⁻⁵³ —
a smooth bd0-direct-side component at small operand values, plus the known
layer-1 ±1·ulp53(lc) class. Next battery: bd0-direct staging race for
small np (the quotient/product staging at values near 1), series-branch
staging (near-mode windows), and the layer-1 lc-rounding hunt.

### Files (round 5)

`agentT_b35_gen.py`, `batch-b35-binom.json`, `agentT_b35_design.json`,
`agentT_b35_solve.py` → `agentT_b35_body.json`; 2lnA race inline (this
section); prior-round files unchanged.

## ROUND 6 — three follow-ups run; **lc GROUPING IDENTIFIED (O3)**; bd0-staging + series families exhausted

Instrument extension: `agentT_b35_intervals.py` → `agentT_intervals_abs.json`
(all 31,200 b34+b35 preimage intervals in absolute argument form —
candidate racing is now fully offline, zero chain calls).

### 1. bd0-direct staging at small operands — family EXHAUSTED (again)

Raced offline (`agentT_round6.py`, sparse 3,120 rows, 2lnA baseline
C0 = 53.53 %): split L = lnx−lnnp 32.4 %; distribute (x·lnx−x·lnnp) 28.7 %;
distribute-LTR 27.3 %; recip-mul quotient 47.2 %; DR quotient 53.59 %
(statistical tie, +2 rows); one-spill compound 45.3 %; deep split
ln np = ln n + ln p|q 28.1 %; split assoc-A 30.3 %. **The log-splitting
lesson does NOT extend to bd0** — bd0's quotient-ln stands. Also refuted:
the 32-bit-codegen extended-return models (bd0 returning ST(0) extended
unspilled into an extended lc chain): 42.0 %; ext-lc-chain with double
b-terms: 50.9 %. The small-operand residual (B1 +2.0, B2 −1.1..−1.7,
B5 −0.5, B3 +0.3..0.7) survives every staging in this family.

### 2. Series-branch staging — INERT

`agentT_round6b.py` part 2 (2,080 series-involved rows): R-loop RN53
49.52 %, per-op DR 49.52 %, extended-with-one-spill 49.42 %, one-spill-v
49.57 % — all within 3 rows. The series realization is not distinguishable
on this corpus and is not the residual carrier.

### 3. Layer-1 flips — **lc grouping IDENTIFIED**

Measured per-row m (flips) from the absolute intervals, restricted to
|arg| ≥ 8 where layer-1 separates cleanly from the body: 475 flips in
3,280 rows (14.5 %). Ordering sweep (12 candidates):

    lc = ((s1 − s2) − (s3 + b1)) − b2          ["O3"]

predicts **403/475 flips (84.8 %) with ZERO false positives**
(3,208/3,280 all-row agreement). Every alternative grouping tried (LTR
pinned, s2+s3 groupings, b1+b2 groupings, full-sum-then-subtract, DR chain,
extended chain) either predicts no flips or breaks 100–1,600 zeros. O3 is
unique in the family.

**End-to-end (real chain), cumulative model = pinned + 2lnA lf + O3 lc:**

| corpus | 2lnA (round 5) | **+ O3 lc** |
|---|---|---|
| b34 | 48.06 % | **52.17 %** |
| b35 | 68.58 % | **75.51 %** |
| b29 | 45.10 % | **49.81 %** |

(The other O3-adjacent groupings O3b/O3c lose 6–21 points — the exact
grouping matters and is confirmed three-corpus-consistently.)

### Round-6 residual (exact, open)

1. 72/475 flips unpredicted by O3 (15 %) — a second, rarer flip source
   (candidate: bd0-internal product/quotient double-rounding rows — the DR
   quotient tie in part 1 suggests where to look).
2. The small-operand smooth bodies (B1/B2/B3/B5, ±0.2–2·2⁻⁵³, arg-varying)
   — outside every raced bd0/series/codegen staging.
Both are sharpened, banked (agentT_intervals_abs.json + this table), and
await the next battery.

### Files (round 6)

`agentT_b35_intervals.py` → `agentT_intervals_abs.json`;
`agentT_round6.py` → `agentT_round6_scores.json`; `agentT_round6b.py`;
O3 races inline.

## Files (all `agentT_` prefixed, none pre-existing modified)

- `agentT_model.py` — pinned model + realization variants + split64.
- `agentT_baseline.py` — loader + pinned baseline (27.69 %).
- `agentT_explore.py` / `agentT_classes.py` — corpus + class structure.
- `agentT_intervals.py` → `agentT_intervals.json` — the 24k exact intervals.
- `agentT_overlap.py` → `agentT_deltaw.json` — per-window δ_w + depth.
- `agentT_delivery.py` → `agentT_delivery.json` — extended-delivery proof.
- `agentT_cand.py` / `agentT_cand2.py` / `agentT_cand3.py` → `*_scores.json`
  — realization battery (cand3 = the log1p identification).
- `agentT_decomp.py` / `agentT_system.py` → `agentT_system.json` — residual
  attribution (bd0-direct, operand-continuous).
- `agentT_verify.py` — end-to-end b34 + b29 verification.
- `agentT_drift.py` — per-row drift inspector.
- Round 2: `agentT_round2.py` → `agentT_round2_scores.json` (96-candidate
  lp1/bd0dir race); `agentT_solve.py` → `agentT_solution.json` (the exact
  (c, m1, m2) system solve — infeasibility record); `agentT_round2_verify.py`
  (hw-lp1 end-to-end b34/b29).
- Round 3: `agentT_round3.py` → `agentT_redmap.json` (PC53 chain race +
  the delta_w-vs-reduction-state map + the two-layer decomposition).
- Round 4: `agentT_round4.py` → `agentT_round4_body.json` (mem/p53r/p53s/rz
  race + per-chain body table); `agentT_polyexp.py` (fdlibm-at-PC64 and
  pure-double emulation races).
