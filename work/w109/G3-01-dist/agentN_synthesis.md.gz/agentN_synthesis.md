# b24 primitive-window decode — SYNTHESIS (agentN)

Gate: self-test PASS (ln channel 400/400 exact, lgamma channel 499/499 exact from
injected known models). All results below are offline mpmath (prec 120-200) decodes
of the nine b24 captures joined on witness id/args-hex.

## Per-primitive measurement table

| primitive (site) | mode / route | error profile (measured) | map size / resolution | op-graph constraint |
|---|---|---|---|---|
| **exp — pdf site** (exponpdf) | round-NEAREST | 99.56% == CR; 0.40% CR-1; 0.048% CR+1 | 23000 rows; exact bits, u in [-692,-1e-8] | pdf site is bit-identical to the POISSON k=0 wrapper (10000/10000) => SAME routine+publication; it is the nearest site, NOT the gser chop site. Power-of-2 lam staging (0.5,2) transparent. |
| **expm1 — cdf/wrapper** (exponpdf T1, weibull) | -expm1(-x), NEAREST | 80.3% == CR expm1; 99.87% within +/-1 ULP | 10000 EXPON-cdf rows | EXPON cdf publishes -expm1(-x), NOT RN(1-pdf) (naive 1-minus only 30%). WEIBULL cdf reuses the same expm1 outer. Localizes the a==1 expm1 wrapper to cdf sites. |
| **ln** (lognorm / normref) | internal ln = CR ln | 2151 RN-exact reads: 100% delta 0; 849 intervals all delta-0-feasible; 0 no-match | 2151 exact + 849 interval; ln x in [-36,-1]; RN-EXACT | Internal ln is correctly-rounded, bit-for-bit, no routing surprises. LOGNORMDIST == LOGNORM.DIST 3300/3300 (rewrite collapse). Confirmed independently by binom (residue slope+intercept 0.0000 ULP, n<=720) and weibull (residue mean 0 +/-0.003 ULP). |
| **pow** (binom / weibull) | exp(y * ln x) "powf" | binom 98.2% exact (100% incl exp+/-1 tail); weibull small-t 797/800 powf vs 411 binexp/CRpow | full binom+weibull corpus | Route = transcendental exp-log, with CR ln and the nearest exp site. NOT integer binexp, NOT repeated multiply, NOT CR pow, NO exponent==1 shortcut. DISTINCT from the bond-lane PRICE/YIELD binexp kernel. |
| **lgamma** (gamma, G3-02) | E_g(lgamma), E_g=NEAREST | internal_lgamma - CR_lgamma: mean +0.05/+0.007/+0.13 ULP (bands A_log/A_lin/B); spread 0.07-0.33 ULP | 9999 amplified reads; ~0.001-0.1 ULP for large Lg | Internal lgamma == CR lgamma to sub-ULP => strictly more accurate than published GAMMALN (~1 ULP). Band-A double-grid inversion fails 78% => internal lgamma is EXTENDED precision. E_g nearest. GAMMA(n) exactness explained by exp(lgamma) alone (no integer fast path). |
| **poisson pmf staging** (poissonpdf) | DIRECT product e^-lam lam^k/k! | pub != CR-pmf; within-1 of direct: k1 62% / k2 32% / k3 24% (grows with k) | 3x3999 rows; route determined, staging NOT pinned | Route is direct product (log-route excluded: dies at large lam, 2% at lam>100; CR excluded). Residual grows with k = per-op double-rounding staging. Exact multiply order + pmf exp-site under-determined (implied exp spread +/-3, 21% unexplained) -> the pmf exp is a broader-error site (gser candidate); FOLLOW-UP. |

## Cross-battery order-of-operations outcomes
1. exponpdf census fixed the pdf-site exp = nearest, bit-identical to the POISSON k=0
   wrapper; cdf = expm1 route. Three "sites" reduce to two publication classes:
   {nearest: pdf/wrapper/pow-exp/gamma-exp} and {chop: gser series} (prior), plus the
   {expm1: cdf} wrapper. The b24 "third site" (pdf) is NOT a new mode.
2. lognorm gave internal ln = CR ln RN-exactly, independent of any exp identity.
3. weibull + binom: pow = exp(y ln x); consumed the nearest exp site (window 1) and
   re-confirmed the CR-ln read (window 2) via the n- and a-amplified residues.
4. gamma: internal lgamma = CR lgamma to sub-ULP, extended precision, nearest E_g.
5. poissonpdf: direct-product route; staging residual open.

## Highest-value op-graph facts banked
- The stats-rewrite exp has exactly ONE round-nearest publication class shared across
  pdf / POISSON-wrapper / pow-internal / GAMMA-internal, with a fixed ~0.4%/0.05%
  CR-1/CR+1 boundary tail; the gser series site's chop is the only other class.
- Distribution pow = exp(y ln x), NOT the CRT integer binexp used by bond PRICE/YIELD:
  a clean split of the two pow kernels in the codebase.
- Internal ln and internal lgamma are both correctly-rounded-or-better (ln exactly CR;
  lgamma sub-ULP / extended precision), the latter measurably tighter than published
  GAMMALN — the G3-02 signal, now pointwise-mapped (agentN_lgamma_map.jsonl).
