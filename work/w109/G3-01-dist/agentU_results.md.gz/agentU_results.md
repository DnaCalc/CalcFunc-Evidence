# Lane 8 — BINOM.DIST pmf PRODUCTION LANDING + b36 fresh gate (agent-U)

W109 / G3-01. Port of agent-T's identified `BINOM.DIST(k,n,p,FALSE)` model
(R `dbinom_raw` op-graph: O3 lc grouping + 2lnA lf + EXTENDED chain-entry exp)
to production Rust, verified against every banked corpus and the FRESH,
never-fit `b36` gate. STRICT black-box; every constant generated with mpmath
and pasted as exact bits. NEGBINOM checked offline only. Nothing committed.

## Files changed / added (all under scope)

- `crates/oxfunc_core/src/excel_numeric/mod.rs` — new `pub(crate)`
  `excel_binom_pmf_exp(lc, lf)`: the EXTENDED chain-entry exp
  `exp(lc − 0.5·lf)` (0.5·lf exact in double, subtraction at PC=64 unspilled,
  fFEXP chain register-resident, RN53 publish). x86_64 x87 path + portable
  fallback, house `gammaln.rs` pattern.
- `crates/oxfunc_core/src/functions/discrete_dist_family.rs` — replaced the
  log-composed `ln_choose`-based binom pmf with `binom_pmf` (R dbinom_raw:
  `binom_stirlerr` 4-tier, `binom_bd0` series/direct, O3 lc, 2lnA lf, k=0/k=n
  closed forms). Generated constant table (STIRLERR[1..15], S0..S4, M_LN_2PI).
  `ln_choose` retained (still used by HYPGEOM + NEGBINOM). cdf summation and
  domain validation unchanged.
- `smart-fuzzer/tools/calc_graph_racer/src/bin/check_binom_prod.rs` — racer bin
  ("k n p cum" hex → kernel bits / ERR).
- Work dir: `agentU_gen_consts.py` (constant generator), `agentU_consts.py`,
  `agentU_score.py`, `agentU_ref.py` (port-is-spec check via the x87 server),
  `agentU_negbinom.py`.

## 1. Constants — generated, bit-verified

`agentU_gen_consts.py` emits every constant from mpmath prec-200 and
cross-checks bit-for-bit against `agentT_model.py`'s SFE / S / M_LN_2PI:
`// cross-check vs agentT_model.py: ALL BITS MATCH`. No hand-conversion.

## 2. Production kernel vs banked corpora (EXACT counts)

Scored through the production Rust kernel (`check_binom_prod`). Every fit-corpus
number reproduces agent-T's end-to-end (cexpext2) score to the row:

| corpus | agent-T target | production Rust | note |
|---|---|---|---|
| b29-binom (1062) | ~529 / 49.8% | **529/1062 = 49.81%** | general-k |
| b34-binom (24000) | ~52.2% | **12520/24000 = 52.17%** | window |
| b35-binom (7200) | ~75.5% | **5437/7200 = 75.51%** | matched-arg |
| b29b-binomk0 (400) | ~383+/400 | **383/400 = 95.75%** | k=0 |

## 3. FRESH GATE — b36 (never seen by any fit)

`answers-b36-binom.json`, 3894 rows, all pmf (cum=0):

| split | count | % |
|---|---|---|
| **overall** | 1931/3894 | **49.59%** |
| b36G general-k | 1137/3000 | **37.90%** |
| b36K0 k=0 | 372/456 | 81.58% |
| b36KN k=n | 422/438 | 96.35% |

miss delta hist (output ulp): {−1: 477, +1: 455, ±2..4: 453, ±5..64: 359, >64: 219}

### The general-k gate is materially below b29 — a real generalization gap

b36 general-k (37.90%) lands ~12 points under b29's 49.81%. This is NOT pure
large-n dilution. Apples-to-apples, general-k only, bucketed by n:

| n bucket | b29 | b36G |
|---|---|---|
| n ≤ 15 | 213/432 = 49% | 528/1109 = **48%** |
| 16–35 | 186/378 = 49% | 158/447 = **35%** |
| 36–64 | 130/252 = 52% | 67/221 = **30%** |
| 81–500 | — | 267/741 = 36% |
| > 500 | — | 117/482 = **24%** (158 of the 219 >64-ulp misses) |

Reading: at **n ≤ 15 the model generalizes perfectly** (48% ≈ b29's 49%), but
across n = 16–64 the FRESH b36 rows underperform their b29 counterparts by
14–22 points, and the large-n regimes (never in any training corpus — b29/b34/
b35 all have n ≤ 64) fall to 24–36%. The identified O3/2lnA op-graph closes the
small-n and the specific b34/b35 anchor windows, but agent-T's two banked open
residuals (the 72/475 second flip source + the small-operand bd0-direct bodies)
carry an **n-dependence the model does not capture**. b29's ~50% was a partial
identification, not closure; b36's broader (k,n,p) sampling exposes that the
~50% is not uniform in n. **This is an overfit/generalization signal per the
task guard → NEGBINOM landing is held.**

The k=0 / k=n closed forms generalize well (82% / 96%) — those are the simple
`exp(bd0…)` / `pow_chain` branches, not the many-term dbinom_raw body.

## 4. Port-is-the-spec — Rust ≡ independent x87-server reference

`agentU_ref.py` recomputes the full model (O3 + 2lnA + k0/kn + n==0) through the
REAL x87 hardware server (ln / cexpext2 / mul / exp ops) — an INDEPENDENT
implementation — and diffs against the Rust kernel:

- 2,000 rows sampled across all corpora: **2000/2000 bit-identical**.
- 12,000 rows (incl. **187 rows with n > 500**): **12000/12000 bit-identical**.

⇒ The b36 large-n misses are genuine MODEL residual, NOT a port defect. The
Rust is a faithful transcription of the identified spec.

## 5. Test suite

`cargo test -p oxfunc_core --release` — see final report (route change touches
only the binom pmf; the loose-tolerance binom tests and the combinatoric-lane
bit tests are unaffected — `binom_dist_range` uses the direct combinatoric lane,
not the pmf).

## 6. NEGBINOM — does NOT inherit (offline, NOT landed)

`agentU_negbinom.py`: dnbinom(f,s,p) = (s/(s+f))·dbinom_raw(s, f+s, p, q), with
dbinom_raw = the production binom pmf (k=s, n=f+s), prefactor applied plain and
x87 double-rounded, vs `answers-b29-negbinom.json` (1800 rows):

- prefactor PLAIN : **187/1800 = 10.39%**
- prefactor x87 DR: **187/1800 = 10.39%**

10.4% is nowhere near BINOM's ~50% ⇒ NEGBINOM does **not** cleanly inherit the
identity as specified. Verdict: **leave `negbinom_dist_kernel` untouched**
(zero changes made). Doubly justified — both the b36 overfit guard and this
direct measurement say do not land. The staging of dnbinom's prefactor / the
dbinom_raw mapping is a separate identification, not a free inheritance.

## 7. Residual classes remaining (match agent-T's)

1. **Layer-1 second flip source** — 72/475 flips unpredicted by O3 (round 6);
   grows with n (drives the n=16–64 b36 underperformance).
2. **Small/large-operand bd0-direct + accumulation** bodies — sub-ULP,
   arg-varying, outside every raced bd0/series/codegen staging; the n-dependent
   part is newly exposed by b36 (n>64 → 24–36%).
3. k=0/k=n closed forms are essentially done (82–96% on fresh b36).

These are op-graph-wall residuals (memory: "outside any parametrized family; not
closable by more fitting"), now with a quantified n-scaling from the b36 gate.
