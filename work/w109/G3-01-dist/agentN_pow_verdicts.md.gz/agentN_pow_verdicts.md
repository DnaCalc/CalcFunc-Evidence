# agentN pow-route verdicts (b24 binom + weibull)

Method: end-to-end bit race. For each row the candidate pow realization t_R is
computed in double precision, fed through the identified outer publication, and
compared bit-for-bit to `expected_bits`. Discrimination is read on the rows where
the candidate routes produce *different* bits (n-ladder for binom, small-t blocks
for weibull). Internal exp/expm1 site rounding (Task 1: nearest with a ~0.4% CR-1,
~0.05% CR+1 boundary tail) absorbed by a +/-1..2 ULP tail on the outer only.

## BINOM.DIST(0, n, p, FALSE) = q^n,  q = 1-p exact

Route = **E(RN(n * L(q)))  i.e. exp(n * ln q)**.  NOT integer binary exponentiation.

| route | exact bit-match / 11045 |
|-------|------|
| exp(n*ln q)          | 10850 (98.23%)  -> **100.0%** once the exp nearest +/-1 tail is allowed |
| binexp (square&mult) | 603 (5.46%) |
| left-to-right mul    | 619 (5.60%) |
| CR pow               | 636 (5.76%) |

n-ladder discriminator (exact matches per route, fixed p, n = 2..720): the
multiplicative routes decay monotonically with n (binexp 161 -> 0, ltr 161 -> 0 as
n grows) because their rounding error compounds; the exp-ln route stays ~99%
(585-599 / 600) at every n. Definitive.

- ln residue (highest-gain channel, n up to 720): `delta_n = CRln(pub) - n*CRln(q)`
  regressed vs n per p gives **slope = 0.0000 ULP and intercept = 0.0000 ULP** for
  every p. => internal ln q = CR ln q (no n-linear residue), and the zero intercept
  rules out the lgamma-pmf hypothesis (which the spec flagged would show a constant
  delta_n offset). Resolution ~1/720 ULP.
- `b24Bnn` control (p^n at base p, no 1-p staging): exp-ln 99.75%, same route.
- `b24BT` (CDF(0) vs pmf(0), TRUE vs FALSE twin): **1000/1000 bit-identical**.
  => BINOM cdf at k=0 shares the pmf fast path; it does NOT route through bratio
  bpser at k=0. (Answers the integer-shape fast-path catalog question for k=0.)

## WEIBULL.DIST(x, alpha, beta, TRUE) = outer(pow(x/beta, alpha))

Outer = **-expm1(-t)** (expm1 route, like the EXPON cdf site).
Pow = **powf = exp(alpha * ln x)** for BOTH integer and fractional alpha. NOT binexp,
NOT repeated multiply, NOT correctly-rounded pow, and NO exponent==1 identity shortcut.

Evidence (small-t blocks t<=0.65, where the expm1 outer preserves relative precision
and the routes separate cleanly; tol=1 ULP):

| block (alpha) | powf hit | binexp hit | CR pow hit | disagree rows: powf-win / binexp-win |
|---|---|---|---|---|
| s1  (a=1)   | 796/800 | 411/800 | 411/800 | 386 / 1 |
| s2  (a=2)   | 797/800 | 415/800 | 415/800 | 383 / 1 |
| s0p5 (a=0.5)| 797/800 |   n/a   | 412/800 | (powf vs CR: powf 797 vs CR 412) |

- For a=1, `pow(x,1) = exp(1*ln x) != x` in 605/800 rows (no fast path for exp==1);
  feeding t=x (or binexp/CR, all = x for a=1) matches only 411, feeding
  t=exp(ln x) matches 796 -> powf. Same story at a=2 (binexp/CR = the exact square,
  matches 415; powf matches 797).
- CR pow ruled out separately: s0p5 CR-pow hits only 412/800 vs powf 797/800.
- Large-t rows (t in [0.71,30]): the expm1 outer saturates toward 1 so all routes
  collapse to the same published bits (non-discriminating); the few surviving
  discrimination rows (f13: 11 rows, f8: 1 row) all break powf-win / binexp-win = all/0.
- Fractional alpha (0.25,0.75,1.5,2.5,1/3): powf reproduces 1300/1300 each; CR pow
  differs from powf only within +/-1 ULP at large t (both absorbed by tol) — the
  small-t s0p5 block is what rules CR pow out.
- ln residue (amplified read on recovered small-t t_int): `ln(t_int)/alpha - CRln(x)`
  mean = -0.003 / -0.001 / +0.000 ULP(ln x) for s1/s2/s0p5 (sd ~0.24 ULP = the
  exp+expm1 rounding floor). => internal ln = CR ln, no systematic residue. Consistent
  with binom and with the Task-2 lognorm RN-exact result.
- beta staging: `b24W-b2` (beta=2, x/2 exact) reproduces the beta=1 law at the
  matched t (x/2 computed exact, then powf) — no extra beta-staging error.

## Cross-primitive conclusion
Both distribution-function pow sites (BINOM, WEIBULL) use the **exp(y * ln x)** kernel
with internal ln = CR ln and the nearest-site internal exp. This is a DIFFERENT pow
route from the bond-lane PRICE/YIELD kernel (C-runtime integer binary exponentiation):
the 2010 stats rewrite's pow-for-distributions is the transcendental exp-log path, not
the CRT integer special case. WEIBULL additionally confirms the expm1 wrapper (Task 1)
is reused at its cdf site.
