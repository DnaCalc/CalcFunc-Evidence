# Hand-off note: internal-lgamma (G3-02) lane

From the b24 gamma window decode (agentN). Files: `agentN_lgamma_map.jsonl`,
`agentN_gamma2.py`, `agentN_gamma2_stats.json`.

## What is now measured
GAMMA(x) = E_g(internal_lgamma(x)). The exp is steep, so the pub bits AMPLIFY the
internal lgamma. The clean read is the direct real inversion `u_impl = CR(ln(pub))`,
which recovers the internal lgamma as a REAL value to ~2^-53 absolute (because if
E_g is round-nearest, pub = exp(Lg)*(1+e), |e|<=2^-53, so ln(pub) = Lg + e). In
ULP(lgamma) terms the resolution is ~2^-53/ULP(Lg) ~ 0.001 ULP for large Lg.

Signal delta = internal_lgamma - CR_lgamma, in ULP(lgamma):

| band | x range | Lg range | n | mean | median | stdev |
|---|---|---|---|---|---|---|
| A_log | 3.5..171.6 (log) | 1.2..711 | 4000 | +0.049 | +0.017 | 0.214 |
| A_lin | 3.5..171.6 (lin) | ~2.6..711 | 2000 | +0.007 | +0.002 | 0.073 |
| B     | 1e-4..0.38       | 0.95..9.2 | 3999 | +0.125 | +0.080 | 0.330 |

=> **internal lgamma is correctly-rounded lgamma to sub-ULP**, with a small POSITIVE
bias (+0.05 ULP band A, +0.13 ULP band B) and ~0.07-0.33 ULP spread. This is far
tighter than the published GAMMALN error envelope (GAMMALN == GAMMALN.PRECISE, a
near-CR but ~1-ULP surface), quantitatively confirming "internal lgamma is higher
precision than published GAMMALN". The internal lgamma is essentially CR.

## E_g rounding mode
The delta is centered near 0 (median +0.002..+0.08 ULP). Chop would force a
systematic ~-0.3..-0.5 ULP offset, ceil a +0.3..+0.5 offset; neither is seen. So
**E_g is round-nearest** (the same publication class as the Task-1 pdf/wrapper exp
site, NOT the gser chop site). The residual +0.05..+0.13 ULP positive bias is the
open question below.

## Integer dispatch (resolved: NO separate fast path evidenced)
GAMMA(n) == exact (n-1)! for every n=2..20. BUT RN(exp(CR_lgamma(n))) ALSO == (n-1)!
for every one of them, so the exact-factorial behaviour is fully explained by the
plain exp(lgamma) route — it does NOT require or evidence an integer fast path.
(Contrast COMBINA's 657799.9999999999, where the lgamma route visibly fails to land
on the integer.) n +/- 2^-20 rows follow the smooth exp(lgamma) law (deltas ~0.1-0.5
ULP for n>=5; n=2 is meaningless because lgamma(2)=0 makes ULP(Lg) vanish).

## Open questions / next probes for the lgamma lane
1. The small +0.05..+0.13 ULP positive bias: is it (a) a genuine internal_lgamma >
   CR_lgamma bias, or (b) a slight upward skew in E_g's nearest rounding, or (c) the
   internal lgamma carried in >53-bit (x87/double-double) precision so that
   exp(extended_Lg) sits systematically above exp(RN(Lg))? The band-A "no-invert
   under a double-grid lgamma" census (agentN_gamma.py: 78% of band A_log has NO
   double Lg reproducing pub) is direct evidence for (c): a plain-double lgamma
   cannot reproduce the large-Lg pub bits; an extended-precision lgamma can. STRONG
   prior that the internal lgamma is extended precision, matching the G3-02 thesis.
2. To get the pointwise internal-MINUS-published delta (not just internal-minus-CR),
   capture published GAMMALN at the exact b24GA/b24GAl/b24GB x-grid (args-hex in
   `agentN_lgamma_map.jsonl`), then compare CR(ln(pub_GAMMA)) - GAMMALN(x).
3. The map's `implied_lgamma_lo/hi_bits` bracket the internal lgamma under the
   nearest-E_g assumption (lo=ln(pub-0.5ulp), hi=ln(pub+0.5ulp)); `delta_vs_CR_ulp`
   is the amplified signal. Feed these as targets to the Stirling/Lanczos op-graph
   racer for the internal lgamma kernel.
4. Negative x (GNa/GNb): 96% within +/-2 ULP of naive reflection pi/(sin(pi x)Gamma(1-x));
   the 4% tail carries the sin + division staging — exploratory only, do not fit.
