# b24 decode spec — algebraic windows onto the stats-rewrite internal primitives

Companion to `agentK_gen_b24.py` (batteries `batch-b24-*.json`). Answers arrive as
`{"function": NAME, "witnesses": [{"id", "args", "expected_bits"}]}` — join on `id`
(args echo back for verification). All decoding below is offline; mpmath prec >= 120
is the truth oracle for CR values. ULP/nudge conventions as in `agentA_*`/`analyze.py`.

Notation: `E(u)` = the internal rewrite exp at the call site under study (rounding
mode per site — b23 proved chop is CALL-SITE-LOCAL); `L(x)` = internal ln;
`RN` = round-nearest double; `CR(f)` = correctly rounded f from mpmath.
"pub" = the published double from `expected_bits`.

---

## 1. batch-b24-exponpdf — EXPON.DIST(x, lam, FALSE) = lam * exp(-lam*x)

Direct exp read at a NEW call site (the pdf branch), on grids bit-matched to
b23E (cdf, same x doubles: ids `b24XA-*`) and b23P (POISSON k=0, same doubles
as lam: ids `b24XB-*`).

Decode (lam = 1 rows, `b24XA`/`b24XB`):
- pub = publication of `E_pdf(-x)` (multiply by lam=1.0 is exact/absent).
- Per-row classification against CR: `delta = pub_as_int - bits(CR(exp(-x)))`
  in {-1, 0, +1, other}; build the signed one-sided profile exactly as the b23
  implied-exp census (floor/nearest/ceil scoring). Deterministic per row.
- CROSS-SITE BIT TEST 1 (needs answers-b23-expon): for each `b24XA-i` vs
  `b23E-i` (same x): test `pub_cdf == RN(1 - pub_pdf)`. Holding everywhere
  => cdf publishes 1 - (the same exp call); failures localize the expm1 route
  (a==1 wrapper published -expm1(-x) — this maps WHERE the wrapper is used).
- CROSS-SITE BIT TEST 2 (needs answers-b23-poisson): `b24XB-i` (x=lam) vs
  `b23P-*` at the same lam double: `pub_pdf(EXPON) == pub(POISSON k=0)`
  bit-for-bit => one shared exp call site/rounding; any mismatch is a per-site
  rounding-mode differential (the b23 lesson says expect these).
- lam in {0.5, 2} rows (`b24XC5/b24XC2`): lam*x exact (power of two), final
  multiply by lam exact (scaling) unless pub subnormal => identical read of
  E(-lam*x) with the staging RN(lam*x) proven transparent; any deviation vs the
  lam=1 law at matched u = -lam*x indicates a non-trivial argument staging.

Resolution: exact bits of the pdf-site exp over u in (-700, -1e-8]. No confounds
besides subnormal publication flush at pub < 2^-1022 (exclude those rows).

## 2. batch-b24-weibull (+ batch-b24-exponcdf) — WEIBULL.DIST(x, a, b, TRUE)

Model: p = pub_of(1 - exp(-t)) with t = internal pow(x/b, a). b=1 except the
`b24W-b2` block (b=2, x/2 exact).

Step 1 — route discriminator (exp vs expm1), deterministic:
- Large-t rows (t >= 0.71, ids without `s`): q := 1 - pub (EXACT: pub >= 0.5).
  * exp route: q = E(-t) directly -> q carries full relative precision.
  * expm1 route: pub = RN(-expm1(-t)) -> q = 1 - pub sits on the absolute
    2^-53 grid: test `q * 2^53 == floor(q * 2^53)` exactly (integer check).
    For t >= ~3, an exp-route q (~e^-t < 0.05) lands on that grid with
    probability ~2^-(excess bits) — census over 1300 rows/alpha separates the
    routes with certainty.
- Small-t rows (`b24W-s*`, t <= 0.65): pub < 0.5.
  * exp route: e = E(-t) in (0.5, 1), pub = 1 - e EXACT (Sterbenz) -> pub has
    coarse absolute 2^-54 quantization; at t ~ 1e-6 that is ~19 lost bits —
    unmistakable.
  * expm1 route: pub IS the expm1 output (full relative precision).

Step 2 — recover t (the pow read), given the site-exp identity from window 1:
- exp route: for candidates t_c in {CR(pow(x, a)) nudged -3..+3 ULP}: accept
  t_c iff E(-t_c) == q (large-t rows). Injective for t in [0.71, 30]
  (relative spacing ULP(t) >= 2^-53 * t > q-grid resolution). Emits t_int =
  the internal pow(x, a) bits, ~1-row-per-read.
- expm1 route: same candidate loop through the expm1 model; resolution drops
  to |dp/dt| = e^-t vs ULP(p) = 2^-53 -> unique t only for t <= ~36 ln2/…
  (still fine on this grid, but flag rows t > 20 as possibly ambiguous).

Step 3 — race t_int against pow realizations:
- integer alpha (`b24W-f2..f13` — note tags f2,f3,f4,f5,f8,f13 are the INT
  block): binexp (C-runtime pow integer special case, the bond-price kernel
  `excel_bond_pow` ordering) vs powf-style E2(RN(a * L(x))) vs CR pow.
- fractional alpha: t_int = E2(RN(a * L(x))) hypothesis; implied-argument
  decode u_impl = CR(ln(t_int)) rounds to RN(a*L) +- eps; the x a
  amplification of L's rounding residue (b23A algebra) reads the internal-ln
  identity: delta(x) := u_impl/a - CR(ln x) in units of ULP(ln x).
- alpha=1 rows vs batch-b24-exponcdf (SAME t doubles, ids `b24W-a1-i` vs
  `b24EC-i`, `b24W-s1-i` vs `b24ECs-i`): bit-equality <=> WEIBULL(alpha=1)
  collapses to the EXPON cdf call site (dispatch discovery); inequality
  <=> distinct call sites (compare their rounding censuses separately).
- `b24W-b2` block: (x/2) exact -> must reproduce the b=1 law at the same t;
  deviation = beta staging (x/b rounding) visible.

Resolution: pow bits exact per row on [0.71, 30]; ln residue to ~(1/a) ULP.
Confounds: the exp identity must come first (window 1/b23); expm1-route rows
lose resolution at large t; if Excel computes t as exp(a ln x) with a DIFFERENT
internal exp than the outer one, step 3's implied decode absorbs it (that is
itself the finding).

## 3. batch-b24-binom — BINOM.DIST(0, n, p, FALSE) = q^n, q = 1-p exact

Verified at generation: every `b24B-` row has (1-p)+p == 1 exactly (p in
(0.5,1) => Sterbenz), so q = 1-p is a KNOWN exact double. pub = internal
pow_int(q, n) or E(RN(n * L(q))) — n is small-integer exact.

- Route race per row: candidates
  (a) binexp square-and-multiply (excel_bond_pow ordering),
  (b) left-to-right repeated multiply,
  (c) CR pow,
  (d) E(RN(n * L_c(q))) over ln candidates L_c = CR(ln q) nudged -2..+2 and
      site-exp E from window 1.
  Score by exact bit-match census across the n-ladder at fixed p (ids embed n;
  p from args). The n-ladder at FIXED q is the discriminator: multiplicative
  routes have correlated errors across n (error compounds), the exp-ln route
  has the n-linear implied-argument law.
- If route (d): implied read u_impl = CR(ln(pub)); delta_n := u_impl - n*CR(ln q)
  = n*(L - CR(ln q)) + eps_exp. Regress delta_n vs n per p: slope = internal-ln
  residue at q to ~(1/n_max) ULP = 1/720 ULP — the highest-gain ln read we have.
- `b24Bnn-` control rows ((n,n) -> p^n): same decode at base p (no subtraction
  staging at all); cross-check the identified route.
- `b24BT-` rows (same args, TRUE): CDF(0) == pmf(0) mathematically; bit-compare
  vs the FALSE twin: equality => shared code/fast path; inequality => the CDF
  routes through bratio even at k=0 (the open "integer-shape fast-path" catalog
  question) — then pub_TRUE reads the bratio bpser surface at a=..., directly.

Resolution: route identification deterministic; ln residue sub-ULP (1/n).
Confounds: possible lgamma-based pmf (exp(lgamma(n+1) - lgamma(1) - lgamma(n+1)
+ 0*ln p + n*ln q) — collapses to E(RN(n*L(q))) if the lgamma terms cancel
exactly, else shows a constant-offset signature: detectable as delta_n intercept
!= 0); underflow guarded (n*|ln q| <= 690).

## 4. batch-b24-lognorm / -normref / -lognormleg — internal ln, RN-exact

Model: LOGNORM.DIST(x, 0, 1, TRUE) = Phi(z), z = (L(x) - 0)/1 = L(x) staged
transparently. The published NORM.S.DIST surface (whatever its kernel) is a
strictly monotone map; in the lower tail its per-ULP-of-z increments exceed
ULP(p) (injectivity ratio |t| * ULP(t) * 2^53 >= 2 for t <= -1), so matching
pub_LOGNORM(x) against pub_NORM.S.DIST(t_c) over candidates t_c identifies
L(x) EXACTLY — with NO knowledge of the erf substrate and NO exp identity.

- Join: for each `b24L-j` row (x), candidates are the 5 nudges of
  c = CR(ln x_stored) in batch-b24-normref (dedup'd; recompute the candidate
  set with mpmath at decode time — same formula — and look each up in the
  normref answers by args-hex).
- Accept t_c iff pub_NS(t_c) == pub_LN(x) bit-for-bit. Outcomes per row:
  * exactly one match -> L(x) = t_c (an RN-exact internal-ln read);
  * zero matches -> the composition model is wrong at that x (different
    internal Phi call, or z-staging not transparent) — census these; a
    structured no-match region is itself a routing map;
  * two matches (adjacent t collide in p) -> ambiguous, count and drop
    (designed rate ~0 for t <= -1; `b24LNC-` control rows EXPECT this).
- Product: L(x) bits on ~3000 x spanning ln x in [-36, -1]. Race vs CR ln,
  fdlibm/UCRT-class log, AMD/Open64 transcriptions — per-binade signed-residue
  phase profile (the b18 alias-free fingerprint) finally read DIRECTLY.
- `b24Lg-` legacy rows: LOGNORMDIST(x,0,1) vs LOGNORM.DIST bit-compare —
  expected identical (rewrite collapse, as proven for the 12-surface family);
  any split = a legacy/modern routing fact.

Resolution: RN-exact (the strongest read in the set). Confounds: none inside
the tail by construction; mu/sigma staging eliminated by (0,1); candidate span
+-2 ULP assumes the internal ln is within 2 ULP of CR (safe: near-CR family) —
widen and re-derive on no-match if needed.

## 5. batch-b24-gamma — GAMMA(x) = pub(E_g(Lg(x))), Lg = internal lgamma

The G3-02 measurement channel. Given the site-exp E_g (race chop/nearest as in
window 1 — do NOT assume the gser chop transfers), invert:

- Candidates Lg_c = CR(lgamma(x)) nudged -4..+4 ULP; accept iff a candidate
  publication model (E_g nearest / floor / x87-window variants) maps Lg_c to
  pub. Bands: `b24GA*` (x in [3.5, 171.6], Lg in [1.2, 711]) and `b24GB`
  (x in [1e-4, 0.38], Lg >= ~0.95) are injective (ULP(Lg) >= 2^-53 * |Lg| >
  relative pub grid); a unique (E_g mode, Lg) pair per row emerges when the
  mode census is pooled per band.
- `b24GNC-` rows (x in [0.5, 3.4], |Lg| < ~0.9): NON-injective by design —
  use only for residual statistics after the identity is fixed, never for fits.
- `b24GI/GIp/GIm` rows: dispatch-by-contradiction at integer x (n, n+-2^-20).
  If GAMMA(n) is the exact factorial (n-1)! for n <= 18 while n+-2^-20 rows
  follow the exp(lgamma) law -> an integer fast path exists (COMBINA's
  657799.9999999999 evidence says the lgamma route shows through at least in
  COMBINA — test whether GAMMA itself shares it).
- `b24GNa/GNb` rows (negative x): EXPLORATORY. Reflection form
  pi/(sin(pi x) * Gamma(1-x)) adds sin + division stagings — do not fit; use
  only to test whether the positive-side identity + naive reflection predicts
  bits (census, not identification).
- Product: internal-lgamma bits to ~1 ULP across two decades of x — race vs
  the published GAMMALN surface (b24 fact: GAMMALN == GAMMALN.PRECISE
  bit-for-bit, 24/24) composed with each E_g mode; vs Cephes-Stirling+log
  (the identified published-GAMMALN x>=11 kernel); a match of
  pub == E_g(published_GAMMALN(x)) under the CORRECT rewrite exp would
  overturn the "internal lgamma != published" claim (that ruling used x87 EXP);
  a mismatch measures the internal-minus-published lgamma delta pointwise.

Resolution: ~1 ULP of Lg per row on the injective bands (amplified: relative
pub error 2^-53 /|Lg| in Lg units). Confounds: E_g identity entangled (break
via the mode census + the direct-exp windows); possible small-x direct rational
(shows as inversion failure across ALL modes in band B — that outcome is a
routing discovery); overflow region x > 171.61 excluded.

## 6. batch-b24-poissonpdf — POISSON.DIST(k, lam, FALSE), k in {1,2,3}

pmf = e^-lam lam^k / k!. Route race (per k, per row; all candidates fully
deterministic given E and L identities + staging orders):
- (i) direct: RN(lam * E(-lam)) [k=1]; RN(RN(lam*lam) * E(-lam)) / 2 and
  permutations [k=2]; /6 rounding [k=3];
- (ii) log-route: E(RN(k*L(lam) - lam) - lgam(k+1)) with lgam(2)=0 (exact,
  collapses to E(RN(L - lam)) at k=1 — cleanly separable from (i) because
  (i) has TWO roundings (exp then multiply) vs (ii) ONE exp of a staged sum);
- (iii) recurrence from the k=0 read (b23P answers at nearby lam are NOT the
  same lam doubles — recompute E(-lam) from the identified exp instead).
- k=1 is the primary discriminator (no k! rounding, no power staging).
  k=2 adds the lam^2 staging read; k=3 adds the first ROUNDED normalizer (1/6).
- After the route is fixed: k=1 residue reads either the product-staging
  (route i) or an amplified L(lam) - lam sum staging (route ii; note the
  catastrophic cancellation near lam ~ L(lam) never occurs since lam > 0 >= L
  only for lam<1 — for lam in (0,1), k*L - lam is a same-sign sum, benign).

Resolution: route = deterministic census; staging bits ~1 ULP. Confounds: the
k! and lam^k stagings multiply the candidate space at k=3 (that is why k=1
leads); underflow guarded (lam < 650).

---

## Cross-battery order of operations

1. exponpdf census (+ b23 answers) -> fix per-site exp modes (chop map).
2. lognorm candidate matching -> internal ln bits (independent of 1).
3. weibull + binom -> pow route + amplified ln residue (consumes 1, checks 2).
4. gamma -> internal lgamma (consumes 1; the G3-02 payload).
5. poissonpdf -> pmf staging (consumes 1, 2).
6. Fold every identified identity back into the gratio/bratio racers
   (agentA/agentF harnesses) — the primitives are shared, so each read
   multiplies across all G3-01 residual lanes.
