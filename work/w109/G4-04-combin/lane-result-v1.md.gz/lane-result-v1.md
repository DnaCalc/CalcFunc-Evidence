# W109 G4-04 COMBIN Exact-Graph Lane Result v1

Scope is COMBIN only. This result does not claim the mixed G4-04 row,
COMBINA, FACTDOUBLE, ERF.PRECISE, or ERFC.PRECISE.

## Identified output graph

After `k = min(k, n-k)`:

```text
if k == 0: return 1
acc = 1
for i = 2 .. k, ascending:
    factor = RN53(RN64((n-k+i-1) / i))
    acc    = RN53(RN64(acc * factor))
return RN53(RN64(acc * n))
```

Thus the numerator factors ascend from `n-k+1` through `n-1`, denominators
ascend from `2` through `k`, and `n` is multiplied last. Every quotient,
accumulator product, and final product publishes from x87 PC64 to binary64.

The key small fingerprint is `k=3`:

```text
((n-2)/2) * ((n-1)/3) * n
```

This reproduces all 251 dense current-build k=3 rows, including every
non-integer publication.

## Evidence

| Corpus | Role | Exact score |
|---|---|---:|
| July build-20131 corpus | discovery/banked | 505/505 |
| build-20228 dense/current corpus | discovery/banked | 20,713/20,713 |
| build-20228 frozen publication gate | answer-blind heldout | 1,024/1,024 |
| Combined | — | 22,242/22,242 |

The current corpus contains 16,641 dense reduced-triangle rows, 3,652 raw
mirror rows, and 420 legacy-replay additions. All 503 legacy/current overlap
pairs are bit-identical across build 20131 and build 20228.

Frozen heldout provenance:

- Excel 16.0 build 20228, 64-bit, Compatibility Version 2
- `cell_value2_bulk`, `no_cache`
- 1,024/1,024 numeric
- Excel process count retry-pre 0, bounded post 0
- batch SHA256: `5351a70f5a44e6f53bf7b4d994bb60c8573f43ee31ed08efb9f0dbc7dc2c52b8`
- predictions SHA256: `3ddaa2252da504d0ff3a7e4e5af381463570cc7481695ca606621c00e98ebca9`
- answers SHA256: `ab3ea44dde976e4ea163fc369c5f63c21721b13eb56eace7965a1a757eaac0e6`

Heldout controls:

| Declared control | Exact | Within 1 ULP | MAE (ULP) | Worst (ULP) |
|---|---:|---:|---:|---:|
| selected stored-x87 cyclic graph | 1,024/1,024 | 1,024/1,024 | 0 | 0 |
| native RN53 cyclic graph | 606/1,024 | 814/1,024 | 0.8203125 | 9 |
| continuous-x87 cyclic graph | 165/1,024 | 438/1,024 | 2.852539062 | 20 |
| forward factor ordering | 179/1,024 | 442/1,024 | 2.405273438 | 15 |
| correctly rounded integer | 165/1,024 | 439/1,024 | 2.8515625 | 20 |

## Production and formal alignment

- `crates/oxfunc_core/src/functions/combin.rs` uses the identified graph and
  adds current-discovery plus frozen-heldout bit pins.
- `formal/lean/OxFunc/Functions/Combin.lean` records the complement reduction,
  cyclic factor order, store sites, and final-`n` placement without duplicating
  the Rust x87 engine.
- COMBINA remains on its prior shared helper and is untouched.

Verification:

- focused Rust: 13 passed, 0 failed
- full `oxfunc_core`: 1,527 passed, 0 failed, 4 ignored
- focused Lean: 6/6 jobs built
- full Lean: 492/492 jobs built
- production-kernel offline replay: 22,242/22,242 exact
- `rustfmt --check` on the exact Rust file: pass
- `git diff --check` on the two tracked files: pass

## Residual identification note

A term formed by direct x87 division and a term formed by an unspilled x87
reciprocal multiply are output-identical on all 22,242 answered rows and on a
separate 231,073-pair answer-blind finite search pool. Production uses direct
division as the canonical, simplest realization. This is an instruction-level
ambiguity only; no output-semantic divergence has been observed.

## Status discipline

The COMBIN exact-graph target is exercised and integrated, but the enclosing
workset/mixed G4-04 row remains in progress because shared contract/catalog,
worklist, and bead updates are coordinator-owned and the other G4-04 functions
are explicitly outside this lane.
