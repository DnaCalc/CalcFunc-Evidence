use crate::coercion::CoercionError;
use crate::function::{
    Arity, CoercionLiftProfile, DeterminismClass, FecDependencyProfile, FunctionMeta,
    HostInteractionClass, KernelSignatureClass, ThreadSafetyClass, VolatilityClass,
};
use crate::functions::adapters::{
    coerce_prepared_to_number, run_values_only_prepared, run_values_only_prepared_lifted,
};
use crate::resolver::ReferenceSystemProvider;
use crate::value::{CalcValue, CoreValue, WorksheetErrorCode};

const OPTIONAL_ARITY_5: Arity = Arity { min: 4, max: 5 };
const OPTIONAL_ARITY_7: Arity = Arity { min: 5, max: 7 };
const EPSILON: f64 = 1.0e-12;

const DEPRECIATION_BASE_META: FunctionMeta = function_spec! {
    function_id: "FUNC.DEPRECIATION_BASE",
    arity: Arity::exact(1),
    determinism: DeterminismClass::Deterministic,
    volatility: VolatilityClass::NonVolatile,
    host_interaction: HostInteractionClass::None,
    thread_safety: ThreadSafetyClass::SafePure,
    coercion_lift_profile: CoercionLiftProfile::Custom,
    kernel_signature_class: KernelSignatureClass::Custom,
    fec_dependency_profile: FecDependencyProfile::None,
    surface_fec_dependency_profile: FecDependencyProfile::RefOnly,
};

pub const SLN_META: FunctionMeta = FunctionMeta {
    function_id: "FUNC.SLN",
    arity: Arity::exact(3),
    ..DEPRECIATION_BASE_META
};
pub const SYD_META: FunctionMeta = FunctionMeta {
    function_id: "FUNC.SYD",
    arity: Arity::exact(4),
    ..DEPRECIATION_BASE_META
};
pub const DB_META: FunctionMeta = FunctionMeta {
    function_id: "FUNC.DB",
    arity: OPTIONAL_ARITY_5,
    ..DEPRECIATION_BASE_META
};
pub const DDB_META: FunctionMeta = FunctionMeta {
    function_id: "FUNC.DDB",
    arity: OPTIONAL_ARITY_5,
    ..DEPRECIATION_BASE_META
};
pub const VDB_META: FunctionMeta = FunctionMeta {
    function_id: "FUNC.VDB",
    arity: OPTIONAL_ARITY_7,
    ..DEPRECIATION_BASE_META
};

#[derive(Debug, Clone, PartialEq)]
pub enum DepreciationEvalError {
    ArityMismatch {
        expected_min: usize,
        expected_max: usize,
        actual: usize,
    },
    Coercion(CoercionError),
}

fn arity_error(meta: &FunctionMeta, actual: usize) -> DepreciationEvalError {
    DepreciationEvalError::ArityMismatch {
        expected_min: meta.arity.min,
        expected_max: meta.arity.max,
        actual,
    }
}

fn required_number(arg: &CalcValue) -> Result<f64, DepreciationEvalError> {
    coerce_prepared_to_number(arg).map_err(DepreciationEvalError::Coercion)
}

fn optional_number(
    args: &[CalcValue],
    idx: usize,
    default: f64,
) -> Result<f64, DepreciationEvalError> {
    match args.get(idx) {
        None => Ok(default),
        Some(arg) => depreciation_number(arg),
    }
}

fn validate_finite(values: &[f64]) -> Result<(), WorksheetErrorCode> {
    if values.iter().all(|value| value.is_finite()) {
        Ok(())
    } else {
        Err(WorksheetErrorCode::Num)
    }
}

fn round_half_away_from_zero(value: f64, digits: i32) -> f64 {
    let factor = 10_f64.powi(digits);
    let scaled = value * factor;
    let rounded = (scaled.abs() + 0.5).floor().copysign(scaled);
    rounded / factor
}

pub fn sln_kernel(cost: f64, salvage: f64, life: f64) -> Result<f64, WorksheetErrorCode> {
    validate_finite(&[cost, salvage, life])?;
    if life == 0.0 {
        return Err(WorksheetErrorCode::Div0);
    }
    // SLN admits either sign and every nonzero life. The observed quotient is
    // rounded through the existing extended-precision division substrate.
    // Preserve subnormal differences until division: only the published result
    // is flushed to positive zero (Excel 16.0 build 20430, CV2, W111 probes).
    let result = crate::excel_numeric::excel_x87_div(cost - salvage, life);
    if !result.is_finite() {
        Err(WorksheetErrorCode::Num)
    } else if result.abs() < f64::MIN_POSITIVE {
        Ok(0.0)
    } else {
        Ok(result)
    }
}

pub fn syd_kernel(cost: f64, salvage: f64, life: f64, per: f64) -> Result<f64, WorksheetErrorCode> {
    validate_finite(&[cost, salvage, life, per])?;
    if cost < 0.0 || salvage < 0.0 || life <= 0.0 || per <= 0.0 || per > life {
        return Err(WorksheetErrorCode::Num);
    }
    let denominator = life * (life + 1.0);
    if denominator.abs() <= EPSILON {
        return Err(WorksheetErrorCode::Div0);
    }
    Ok((cost - salvage) * (life - per + 1.0) * 2.0 / denominator)
}

fn publish_depreciation(value: f64) -> Result<f64, WorksheetErrorCode> {
    if !value.is_finite() {
        Err(WorksheetErrorCode::Num)
    } else if value.abs() < f64::MIN_POSITIVE {
        Ok(0.0)
    } else {
        Ok(value)
    }
}

fn db_rate(cost: f64, salvage: f64, life: f64) -> Result<f64, WorksheetErrorCode> {
    let ratio = crate::excel_numeric::excel_x87_div(salvage, cost);
    let exponent = crate::excel_numeric::excel_x87_div(1.0, life);
    let power = crate::functions::power_fn::power_kernel(ratio, exponent)?;
    Ok(round_half_away_from_zero(1.0 - power, 3))
}

pub fn db_kernel(
    cost: f64,
    salvage: f64,
    life: f64,
    period: f64,
    month: f64,
) -> Result<f64, WorksheetErrorCode> {
    validate_finite(&[cost, salvage, life, period, month])?;
    // The period and month are truncated, but life remains fractional. Original
    // positive periods below one still request the initial depreciation.
    let month = month.trunc();
    let whole_period = period.trunc();
    if cost < 0.0 || salvage < 0.0 || life <= 0.0 || period <= 0.0
        || month < 1.0 || month > 12.0
        || whole_period > life + if month < 12.0 { 1.0 } else { 0.0 }
    {
        return Err(WorksheetErrorCode::Num);
    }
    if cost == 0.0 {
        return Ok(0.0);
    }
    let rate = db_rate(cost, salvage, life)?;
    if rate == 0.0 {
        return Ok(0.0);
    }
    // These store boundaries are observed by W111 DB probes. Replacing the
    // book recurrence with cost minus a running total changes final bits.
    let mut dep = (cost * rate) * (month / 12.0);
    let mut book = cost - dep;
    let regular_periods = whole_period.min(life.floor()) as usize;
    for p in 2..=regular_periods {
        dep = book * rate;
        book -= dep;
        if book == 0.0 {
            if p < regular_periods { dep = 0.0; }
            break;
        }
        if !book.is_finite() { return Err(WorksheetErrorCode::Num); }
    }
    if month < 12.0 && whole_period == life.floor() + 1.0 {
        dep = ((book / 12.0) * rate) * (12.0 - month);
    }
    publish_depreciation(dep)
}

fn declining_interval_depreciation(
    cost: f64,
    salvage: f64,
    life: f64,
    start_period: f64,
    end_period: f64,
    factor: f64,
    no_switch: bool,
) -> Result<f64, WorksheetErrorCode> {
    validate_finite(&[cost, salvage, life, start_period, end_period, factor])?;
    if cost < 0.0 || salvage < 0.0 || life <= 0.0 || factor < 0.0 {
        return Err(WorksheetErrorCode::Num);
    }
    if start_period < 0.0 || end_period < start_period || end_period > life {
        return Err(WorksheetErrorCode::Num);
    }
    if (end_period - start_period).abs() <= EPSILON {
        return Ok(0.0);
    }

    let mut elapsed = 0.0;
    let mut book = cost;
    let mut total = 0.0;
    let declining_rate = factor / life;
    while elapsed < end_period - EPSILON && elapsed < life - EPSILON {
        let full_start = elapsed;
        let full_end = (elapsed + 1.0).min(life);
        let segment_len = full_end - full_start;
        let remaining_basis = (book - salvage).max(0.0);
        if remaining_basis <= EPSILON {
            break;
        }

        let declining = (book * declining_rate).min(remaining_basis);
        let straight = remaining_basis / (life - elapsed);
        let full_period_dep = if no_switch || declining >= straight {
            declining
        } else {
            straight
        }
        .min(remaining_basis);

        let overlap = (end_period.min(full_end) - start_period.max(full_start)).max(0.0);
        if overlap > EPSILON {
            total += full_period_dep * overlap / segment_len;
        }

        book -= full_period_dep;
        elapsed = full_end;
    }

    Ok(total)
}

pub fn ddb_kernel(
    cost: f64,
    salvage: f64,
    life: f64,
    period: f64,
    factor: f64,
) -> Result<f64, WorksheetErrorCode> {
    validate_finite(&[cost, salvage, life, period, factor])?;
    if cost < 0.0 || salvage < 0.0 || life <= 0.0 || period <= 0.0
        || period > life || factor <= 0.0
    {
        return Err(WorksheetErrorCode::Num);
    }
    let rate = crate::excel_numeric::excel_x87_div(factor, life);
    // Excel uses the POWER wrapper here, including its integer exponent path.
    // A repeated period recurrence or a raw CRT power differs by several ULPs.
    let power = if period <= 1.0 { 1.0 } else {
        crate::functions::power_fn::power_kernel((1.0 - rate).max(0.0), period - 1.0)?
    };
    let book = crate::excel_numeric::excel_x87_mul(cost, power);
    let declining = book * rate;
    // Overflow is observable before salvage clipping, including cost<salvage.
    if !declining.is_finite() { return Err(WorksheetErrorCode::Num); }
    publish_depreciation(declining.min(book - salvage).max(0.0))
}

pub fn vdb_kernel(
    cost: f64,
    salvage: f64,
    life: f64,
    start_period: f64,
    end_period: f64,
    factor: f64,
    no_switch: bool,
) -> Result<f64, WorksheetErrorCode> {
    declining_interval_depreciation(
        cost,
        salvage,
        life,
        start_period,
        end_period,
        factor,
        no_switch,
    )
}

fn eval_sln_prepared(args: &[CalcValue]) -> Result<CalcValue, DepreciationEvalError> {
    if !SLN_META.arity.accepts(args.len()) {
        return Err(arity_error(&SLN_META, args.len()));
    }
    let sln_number = |arg: &CalcValue| {
        if matches!(arg.core(), CoreValue::Missing) {
            Ok(0.0)
        } else {
            required_number(arg)
        }
    };
    let cost = sln_number(&args[0])?;
    let salvage = sln_number(&args[1])?;
    let life = sln_number(&args[2])?;
    Ok(match sln_kernel(cost, salvage, life) {
        Ok(value) => CalcValue::number(value),
        Err(code) => CalcValue::error(code),
    })
}

fn eval_syd_prepared(args: &[CalcValue]) -> Result<CalcValue, DepreciationEvalError> {
    if !SYD_META.arity.accepts(args.len()) {
        return Err(arity_error(&SYD_META, args.len()));
    }
    let cost = required_number(&args[0])?;
    let salvage = required_number(&args[1])?;
    let life = required_number(&args[2])?;
    let per = required_number(&args[3])?;
    Ok(match syd_kernel(cost, salvage, life, per) {
        Ok(value) => CalcValue::number(value),
        Err(code) => CalcValue::error(code),
    })
}

// Explicit missing required parameters are numeric zero on these Excel surfaces.
fn depreciation_number(arg: &CalcValue) -> Result<f64, DepreciationEvalError> {
    if matches!(arg.core(), CoreValue::Missing) { Ok(0.0) } else { required_number(arg) }
}

fn eval_db_prepared(args: &[CalcValue]) -> Result<CalcValue, DepreciationEvalError> {
    if !DB_META.arity.accepts(args.len()) {
        return Err(arity_error(&DB_META, args.len()));
    }
    let cost = depreciation_number(&args[0])?;
    let salvage = depreciation_number(&args[1])?;
    let life = depreciation_number(&args[2])?;
    let period = depreciation_number(&args[3])?;
    let month = optional_number(args, 4, 12.0)?;
    Ok(match db_kernel(cost, salvage, life, period, month) {
        Ok(value) => CalcValue::number(value),
        Err(code) => CalcValue::error(code),
    })
}

fn eval_ddb_prepared(args: &[CalcValue]) -> Result<CalcValue, DepreciationEvalError> {
    if !DDB_META.arity.accepts(args.len()) {
        return Err(arity_error(&DDB_META, args.len()));
    }
    let cost = depreciation_number(&args[0])?;
    let salvage = depreciation_number(&args[1])?;
    let life = depreciation_number(&args[2])?;
    let period = depreciation_number(&args[3])?;
    let factor = optional_number(args, 4, 2.0)?;
    Ok(match ddb_kernel(cost, salvage, life, period, factor) {
        Ok(value) => CalcValue::number(value),
        Err(code) => CalcValue::error(code),
    })
}

fn eval_vdb_prepared(args: &[CalcValue]) -> Result<CalcValue, DepreciationEvalError> {
    if !VDB_META.arity.accepts(args.len()) {
        return Err(arity_error(&VDB_META, args.len()));
    }
    let cost = depreciation_number(&args[0])?;
    let salvage = depreciation_number(&args[1])?;
    let life = depreciation_number(&args[2])?;
    let start_period = depreciation_number(&args[3])?;
    let end_period = depreciation_number(&args[4])?;
    let factor = optional_number(args, 5, 2.0)?;
    let no_switch = match args.get(6).map(CalcValue::core) {
        None | Some(CoreValue::Missing | CoreValue::Empty) => false,
        Some(CoreValue::Logical(value)) => *value,
        Some(CoreValue::Text(text)) => crate::coercion::parse_excel_logical_text(&text.to_string_lossy())
            .ok_or_else(|| DepreciationEvalError::Coercion(CoercionError::NonNumericText(text.to_string_lossy())))?,
        _ => depreciation_number(&args[6])? != 0.0,
    };
    Ok(
        match vdb_kernel(
            cost,
            salvage,
            life,
            start_period,
            end_period,
            factor,
            no_switch,
        ) {
            Ok(value) => CalcValue::number(value),
            Err(code) => CalcValue::error(code),
        },
    )
}

pub fn eval_sln_surface(
    args: &[CalcValue],
    resolver: &(impl ReferenceSystemProvider + ?Sized),
) -> Result<CalcValue, DepreciationEvalError> {
    run_values_only_prepared_lifted(
        args,
        resolver,
        eval_sln_prepared,
        map_depreciation_error_to_ws,
        DepreciationEvalError::Coercion,
    )
}

pub fn eval_syd_surface(
    args: &[CalcValue],
    resolver: &(impl ReferenceSystemProvider + ?Sized),
) -> Result<CalcValue, DepreciationEvalError> {
    run_values_only_prepared(
        args,
        resolver,
        eval_syd_prepared,
        DepreciationEvalError::Coercion,
    )
}

pub fn eval_db_surface(
    args: &[CalcValue],
    resolver: &(impl ReferenceSystemProvider + ?Sized),
) -> Result<CalcValue, DepreciationEvalError> {
    run_values_only_prepared_lifted(
        args,
        resolver,
        eval_db_prepared,
        map_depreciation_error_to_ws,
        DepreciationEvalError::Coercion,
    )
}

pub fn eval_ddb_surface(
    args: &[CalcValue],
    resolver: &(impl ReferenceSystemProvider + ?Sized),
) -> Result<CalcValue, DepreciationEvalError> {
    run_values_only_prepared_lifted(
        args,
        resolver,
        eval_ddb_prepared,
        map_depreciation_error_to_ws,
        DepreciationEvalError::Coercion,
    )
}

pub fn eval_vdb_surface(
    args: &[CalcValue],
    resolver: &(impl ReferenceSystemProvider + ?Sized),
) -> Result<CalcValue, DepreciationEvalError> {
    run_values_only_prepared_lifted(
        args,
        resolver,
        eval_vdb_prepared,
        map_depreciation_error_to_ws,
        DepreciationEvalError::Coercion,
    )
}

pub fn map_depreciation_error_to_ws(error: &DepreciationEvalError) -> WorksheetErrorCode {
    match error {
        DepreciationEvalError::ArityMismatch { .. } => WorksheetErrorCode::Value,
        DepreciationEvalError::Coercion(CoercionError::WorksheetError(code)) => *code,
        DepreciationEvalError::Coercion(_) => WorksheetErrorCode::Value,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::resolver::ReferenceSystemCapabilities;
    use crate::value::{ExcelText, ReferenceKind, ReferenceLike};

    struct NoRefResolver;

    impl ReferenceSystemProvider for NoRefResolver {
        fn capabilities(&self) -> ReferenceSystemCapabilities {
            ReferenceSystemCapabilities::permissive_local()
        }

        fn dereference(
            &self,
            request: &crate::resolver::ReferenceDereferenceRequest,
        ) -> Result<CalcValue, crate::resolver::ReferenceResolutionError> {
            let reference = &request.reference;
            Err(
                crate::resolver::ReferenceResolutionError::UnresolvedReference {
                    target: reference.target().to_string(),
                },
            )
        }
    }

    fn num(n: f64) -> CalcValue {
        CalcValue::number(n)
    }

    fn text(s: &str) -> CalcValue {
        CalcValue::text(ExcelText::from_utf16_code_units(s.encode_utf16().collect()))
    }

    #[test]
    fn depreciation_metadata_matches_expected_shape() {
        assert_eq!(SLN_META.arity, Arity::exact(3));
        assert_eq!(DB_META.arity.max, 5);
        assert_eq!(
            DDB_META.arg_preparation_profile,
            FunctionMeta::DEFAULT_ARG_PREPARATION_PROFILE
        );
        assert_eq!(VDB_META.function_id, "FUNC.VDB");
    }

    #[test]
    fn sln_and_syd_match_support_examples() {
        assert_eq!(sln_kernel(30000.0, 7500.0, 10.0), Ok(2250.0));
        match syd_kernel(30000.0, 7500.0, 10.0, 1.0).unwrap() {
            n => assert!((n - 4090.909090909091).abs() < 1.0e-9),
        }
        match syd_kernel(30000.0, 7500.0, 10.0, 10.0).unwrap() {
            n => assert!((n - 409.09090909090907).abs() < 1.0e-9),
        }
    }

    #[test]
    fn db_matches_support_examples() {
        assert!(
            (db_kernel(1_000_000.0, 100_000.0, 6.0, 1.0, 7.0).unwrap() - 186083.33333333334).abs()
                < 1.0e-9
        );
        assert!(
            (db_kernel(1_000_000.0, 100_000.0, 6.0, 2.0, 7.0).unwrap() - 259639.41666666666).abs()
                < 1.0e-9
        );
        assert!(
            (db_kernel(1_000_000.0, 100_000.0, 6.0, 7.0, 7.0).unwrap() - 15845.098473848071).abs()
                < 1.0e-9
        );
    }

    #[test]
    fn ddb_and_vdb_match_seeded_examples() {
        assert_eq!(ddb_kernel(2400.0, 300.0, 10.0, 1.0, 2.0), Ok(480.0));
        assert_eq!(ddb_kernel(2400.0, 300.0, 10.0, 2.0, 2.0), Ok(384.0));
        assert!(
            (vdb_kernel(2400.0, 300.0, 3650.0, 0.0, 1.0, 2.0, false).unwrap() - 1.3150684931506849)
                .abs()
                < 1.0e-12
        );
        assert!(
            (vdb_kernel(2400.0, 300.0, 120.0, 0.0, 1.0, 2.0, false).unwrap() - 40.0).abs()
                < 1.0e-12
        );
        assert!(
            vdb_kernel(2400.0, 300.0, 120.0, 6.0, 18.0, 2.0, false)
                .unwrap()
                .to_bits()
                == 0x4078_c4e5_981b_af06
        );
        assert!(
            (vdb_kernel(2400.0, 300.0, 120.0, 6.0, 18.0, 1.5, false).unwrap() - 311.8089366582341)
                .abs()
                < 1.0e-9
        );
        assert!(
            (vdb_kernel(2400.0, 300.0, 10.0, 0.0, 0.875, 1.5, false).unwrap() - 315.0).abs()
                < 1.0e-12
        );
    }

    #[test]
    fn surface_evaluators_apply_defaults_and_numeric_coercion() {
        let resolver = NoRefResolver;
        assert_eq!(
            eval_sln_surface(&[num(30000.0), num(7500.0), num(10.0)], &resolver),
            Ok(CalcValue::number(2250.0))
        );
        assert_eq!(
            eval_ddb_surface(&[num(2400.0), num(300.0), num(10.0), num(1.0)], &resolver),
            Ok(CalcValue::number(480.0))
        );
        let got = eval_vdb_surface(
            &[
                num(2400.0),
                num(300.0),
                num(10.0),
                num(0.0),
                num(0.875),
                num(1.5),
            ],
            &resolver,
        )
        .unwrap();
        match got.core() {
            CoreValue::Number(n) => assert!((*n - 315.0).abs() < 1.0e-12),
            other => panic!("expected number, got {other:?}"),
        }
        assert_eq!(
            eval_db_surface(
                &[
                    num(1_000_000.0),
                    num(100_000.0),
                    num(6.0),
                    num(1.0),
                    text("7")
                ],
                &resolver,
            ),
            Ok(CalcValue::number(186083.33333333334))
        );
    }

    #[test]
    fn domain_and_mapping_lanes_are_pinned() {
        let resolver = NoRefResolver;
        assert_eq!(
            sln_kernel(30000.0, 7500.0, 0.0),
            Err(WorksheetErrorCode::Div0)
        );
        assert_eq!(
            syd_kernel(30000.0, 7500.0, 10.0, 11.0),
            Err(WorksheetErrorCode::Num)
        );
        assert_eq!(
            db_kernel(1000.0, 100.0, 6.0, 1.0, 13.0),
            Err(WorksheetErrorCode::Num)
        );
        assert_eq!(
            vdb_kernel(2400.0, 300.0, 10.0, 2.0, 1.0, 2.0, false),
            Err(WorksheetErrorCode::Num)
        );
        assert_eq!(
            map_depreciation_error_to_ws(&DepreciationEvalError::ArityMismatch {
                expected_min: 3,
                expected_max: 3,
                actual: 2,
            }),
            WorksheetErrorCode::Value
        );
        assert_eq!(
            eval_sln_surface(&[num(30000.0), num(7500.0)], &resolver),
            Err(DepreciationEvalError::ArityMismatch {
                expected_min: 3,
                expected_max: 3,
                actual: 2,
            })
        );
    }

    #[test]
    fn no_switch_flag_seed_lane_is_currently_equal() {
        let switched = vdb_kernel(2400.0, 300.0, 10.0, 6.0, 8.0, 2.0, false).unwrap();
        let pure_declining = vdb_kernel(2400.0, 300.0, 10.0, 6.0, 8.0, 2.0, true).unwrap();
        assert!((switched - pure_declining).abs() < 1.0e-12);
    }

    #[test]
    fn no_ref_resolver_reference_lane_stays_unresolved() {
        let resolver = NoRefResolver;
        let got = eval_sln_surface(
            &[
                CalcValue::reference(ReferenceLike::new(ReferenceKind::A1, "A1".to_string())),
                num(0.0),
                num(10.0),
            ],
            &resolver,
        );
        assert_eq!(
            got,
            Err(DepreciationEvalError::Coercion(
                CoercionError::RefResolution(
                    crate::resolver::ReferenceResolutionError::UnresolvedReference {
                        target: "A1".to_string(),
                    }
                )
            ))
        );
    }
}
