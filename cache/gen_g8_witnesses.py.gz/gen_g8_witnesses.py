import json

def num(v): return {"kind": "number", "value": v}
def lgl(v): return {"kind": "logical", "value": v}
def row(*vals):  # 1-row array {a,b,c}
    return {"kind": "array", "rows": [[num(v) for v in vals]]}

# (case_id, FUNC id, formula_text, [args])
W = [
    # --- regression / forecast (arrays) ---
    ("forecast",        "FUNC.FORECAST",        '=FORECAST(4,{1,3,2,5},{1,2,3,4})',           [num(4), row(1,3,2,5), row(1,2,3,4)]),
    ("forecast_linear", "FUNC.FORECAST.LINEAR", '=FORECAST.LINEAR(4,{1,3,2,5},{1,2,3,4})',    [num(4), row(1,3,2,5), row(1,2,3,4)]),
    ("trend",           "FUNC.TREND",           '=TREND({1,3,2,5},{1,2,3,4},{5})',            [row(1,3,2,5), row(1,2,3,4), row(5)]),
    ("growth",          "FUNC.GROWTH",          '=GROWTH({1,3,2,5},{1,2,3,4},{5})',           [row(1,3,2,5), row(1,2,3,4), row(5)]),
    ("linest",          "FUNC.LINEST",          '=LINEST({1,3,2,5},{1,2,3,4})',               [row(1,3,2,5), row(1,2,3,4)]),
    ("logest",          "FUNC.LOGEST",          '=LOGEST({1,3,2,5},{1,2,3,4})',               [row(1,3,2,5), row(1,2,3,4)]),
    # --- percentile / quartile ---
    ("percentile_exc",  "FUNC.PERCENTILE.EXC",  '=PERCENTILE.EXC({1,2,3,4},0.25)',            [row(1,2,3,4), num(0.25)]),
    ("percentile_inc",  "FUNC.PERCENTILE.INC",  '=PERCENTILE.INC({1,2,3,4},0.25)',            [row(1,2,3,4), num(0.25)]),
    ("quartile_exc",    "FUNC.QUARTILE.EXC",    '=QUARTILE.EXC({1,2,3,4},1)',                 [row(1,2,3,4), num(1)]),
    ("quartile_inc",    "FUNC.QUARTILE.INC",    '=QUARTILE.INC({1,2,3,4},1)',                 [row(1,2,3,4), num(1)]),
    # --- paired-sample tests ---
    ("chisq_test",      "FUNC.CHISQ.TEST",      '=CHISQ.TEST({10,20,30},{12,18,30})',         [row(10,20,30), row(12,18,30)]),
    ("chitest",         "FUNC.CHITEST",         '=CHITEST({10,20,30},{12,18,30})',            [row(10,20,30), row(12,18,30)]),
    ("f_test",          "FUNC.F.TEST",          '=F.TEST({1,2,3,4},{2,4,6,8})',               [row(1,2,3,4), row(2,4,6,8)]),
    ("ftest",           "FUNC.FTEST",           '=FTEST({1,2,3,4},{2,4,6,8})',                [row(1,2,3,4), row(2,4,6,8)]),
    # --- finance (re-sweep) ---
    ("npv",             "FUNC.NPV",             '=NPV(0.1,100,200,300)',                      [num(0.1), num(100), num(200), num(300)]),
    ("nper",            "FUNC.NPER",            '=NPER(0.05,-100,1000)',                      [num(0.05), num(-100), num(1000)]),
    ("cumprinc",        "FUNC.CUMPRINC",        '=CUMPRINC(0.1,12,1000,1,12,0)',              [num(0.1), num(12), num(1000), num(1), num(12), num(0)]),
    ("xnpv",            "FUNC.XNPV",            '=XNPV(0.1,{100,200,300},{43831,44196,44561})', [num(0.1), row(100,200,300), row(43831,44196,44561)]),
    ("yielddisc",       "FUNC.YIELDDISC",       '=YIELDDISC(44013,44562,95,100,0)',           [num(44013), num(44562), num(95), num(100), num(0)]),
    ("yieldmat",        "FUNC.YIELDMAT",        '=YIELDMAT(44013,44562,43831,0.05,95,0)',     [num(44013), num(44562), num(43831), num(0.05), num(95), num(0)]),
    # --- misc scalar ---
    ("acot",            "FUNC.ACOT",            '=ACOT(1)',                                   [num(1)]),
    ("convert",         "FUNC.CONVERT",         '=CONVERT(1,"m","ft")',                       [num(1), {"kind":"text","value":"m"}, {"kind":"text","value":"ft"}]),
    ("gauss",           "FUNC.GAUSS",           '=GAUSS(1)',                                  [num(1)]),
    ("phi",             "FUNC.PHI",             '=PHI(1)',                                    [num(1)]),
]

with open("smart-fuzzer/cache/g8-witnesses.jsonl", "w") as f:
    for cid, fid, ftext, args in W:
        f.write(json.dumps({"case_id": cid, "function_id": fid, "formula_text": ftext, "args": args, "cell_fixture": []}) + "\n")
print("wrote", len(W), "G8 witnesses")
