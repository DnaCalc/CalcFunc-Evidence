﻿# W090 Array Support Sweep Generated Highlights

Generated: 2026-04-29T21:51:02Z
Git revision: 82f88dd013ed85f2f01a460c784b9f57a9b8f954

## Candidate Inventory
- surfaces: 534
- medium-or-higher candidates: 379
- seeded/prior reconciled surfaces: 15
- first-tranche surfaces: 14

## First Tranche
- tranche id: w090-tranche-a-math-scalar-numeric-array-lift
- status: planned_not_run
- selected surfaces: ROUND, ROUNDDOWN, ROUNDUP, TRUNC, CEILING, CEILING.MATH, CEILING.PRECISE, FLOOR, FLOOR.MATH, FLOOR.PRECISE, ISO.CEILING, ATAN2, BASE, MROUND

## Artifact Economy
- passing rows remain coverage telemetry only
- unexpected mismatches promote to BUG-FUNC streams or narrower repair beads
- POWER remains a fresh-confirmation sentinel, not an assumed current bug
