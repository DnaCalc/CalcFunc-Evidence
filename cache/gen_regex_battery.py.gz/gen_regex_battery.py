import json

# escape characters to probe (the char following a backslash)
escapes = list("dDwWsSbBAZzntrfv.*+?()[|^$/qkememghpcxyjo")
# dedupe preserving order
seen = set(); escapes = [e for e in escapes if not (e in seen or seen.add(e))]
escapes += ["\\"]  # backslash-backslash (escaped backslash)

teststr = "a1.B z"
out = []
for e in escapes:
    pat = "\\" + e
    cid = "esc_" + (e if e.isalnum() else "sym%d" % ord(e))
    out.append({
        "case_id": cid,
        "stream": "BUG-FUNC-041",
        "function_id": "FUNC.REGEXTEST",
        "formula_text": '=REGEXTEST("%s","%s")' % (teststr, pat),
        "args": [{"kind": "text", "value": teststr}, {"kind": "text", "value": pat}],
        "cell_fixture": [],
        "escape": e,
    })

with open("smart-fuzzer/cache/regex-escape-battery.jsonl", "w") as f:
    for o in out:
        f.write(json.dumps(o) + "\n")
print("wrote", len(out), "escape probes")
