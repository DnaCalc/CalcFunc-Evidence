# Array Support Roadmap Trace

- Run ID: text-slice-001
- Tranche: text-slice-probes-v0
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 20
- Formula cases executed: 21

## Axes touched

- Function family/category: Text functions.
- Array argument axes: text_slice_probe.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 21
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.FIND: exact_typed_bit_match=2
- FUNC.FINDB: exact_typed_bit_match=1
- FUNC.SEARCH: exact_typed_bit_match=1
- FUNC.SEARCHB: exact_typed_bit_match=1
- FUNC.MID: exact_typed_bit_match=1
- FUNC.MIDB: exact_typed_bit_match=1
- FUNC.LEFT: exact_typed_bit_match=1
- FUNC.LEFTB: exact_typed_bit_match=1
- FUNC.RIGHT: exact_typed_bit_match=1
- FUNC.RIGHTB: exact_typed_bit_match=1
- FUNC.LEN: exact_typed_bit_match=1
- FUNC.LENB: exact_typed_bit_match=1
- FUNC.REPLACE: exact_typed_bit_match=1
- FUNC.REPLACEB: exact_typed_bit_match=1
- FUNC.REGEXTEST: exact_typed_bit_match=1
- FUNC.REGEXEXTRACT: exact_typed_bit_match=1
- FUNC.REGEXREPLACE: exact_typed_bit_match=1
- FUNC.TEXTAFTER: exact_typed_bit_match=1
- FUNC.TEXTBEFORE: exact_typed_bit_match=1
- FUNC.TEXTSPLIT: exact_typed_bit_match=1

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
