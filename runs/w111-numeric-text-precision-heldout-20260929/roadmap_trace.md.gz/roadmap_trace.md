# Array Support Roadmap Trace

- Run ID: w111-numeric-text-precision-heldout-20260929
- Tranche: w111-numeric-text-precision-heldout-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 5
- Formula cases executed: 3226

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: ascii_numeric_text_crossfunction_heldout, ascii_numeric_text_precision_heldout.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 3196
- unexpected_mismatch: 30
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.ABS: exact_typed_bit_match=2428, unexpected_mismatch=30
- FUNC.INT: exact_typed_bit_match=192
- FUNC.ROUND: exact_typed_bit_match=192
- FUNC.SUM: exact_typed_bit_match=192
- FUNC.ADDRESS: exact_typed_bit_match=192

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
