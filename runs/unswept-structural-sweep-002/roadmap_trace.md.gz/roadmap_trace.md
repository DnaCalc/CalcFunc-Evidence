# Array Support Roadmap Trace

- Run ID: unswept-structural-sweep-002
- Tranche: unswept-structural-probes-v0
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 75
- Formula cases executed: 450

## Axes touched

- Function family/category: Compatibility, Date and time functions, Engineering functions, Financial functions, Information functions, Lookup and reference functions, Math and trigonometry functions, Our 10 featured functions, Statistical functions, Text functions.
- Array argument axes: unswept_structural_probe.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- excel_harness_blocked: 348
- exact_typed_bit_match: 76
- unexpected_mismatch: 26
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.ACCRINT: excel_harness_blocked=6
- FUNC.ACCRINTM: excel_harness_blocked=6
- FUNC.AMORDEGRC: excel_harness_blocked=6
- FUNC.AMORLINC: excel_harness_blocked=6
- FUNC.ARRAYTOTEXT: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.CHISQ.TEST: excel_harness_blocked=6
- FUNC.CHITEST: excel_harness_blocked=6
- FUNC.CONVERT: excel_harness_blocked=6
- FUNC.COUPDAYBS: excel_harness_blocked=6
- FUNC.COUPDAYS: excel_harness_blocked=6
- FUNC.COUPDAYSNC: excel_harness_blocked=6
- FUNC.COUPNCD: excel_harness_blocked=6
- FUNC.COUPNUM: excel_harness_blocked=6
- FUNC.COUPPCD: excel_harness_blocked=6
- FUNC.DATEDIF: excel_harness_blocked=6
- FUNC.DATEVALUE: exact_typed_bit_match=4, unexpected_mismatch=2
- FUNC.DAYS360: excel_harness_blocked=6
- FUNC.DURATION: excel_harness_blocked=6
- FUNC.EFFECT: excel_harness_blocked=6
- FUNC.F.TEST: excel_harness_blocked=6
- FUNC.FORECAST: excel_harness_blocked=6
- FUNC.FORECAST.LINEAR: excel_harness_blocked=6
- FUNC.FREQUENCY: excel_harness_blocked=6
- FUNC.FTEST: excel_harness_blocked=6
- FUNC.FV: excel_harness_blocked=6
- FUNC.FVSCHEDULE: excel_harness_blocked=6
- FUNC.GROWTH: unexpected_mismatch=2, exact_typed_bit_match=4
- FUNC.IRR: exact_typed_bit_match=3, unexpected_mismatch=3
- FUNC.ISERR: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.ISLOGICAL: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.ISNA: exact_typed_bit_match=6
- FUNC.ISNONTEXT: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.ISODD: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.ISPMT: excel_harness_blocked=6
- FUNC.ISREF: exact_typed_bit_match=6
- FUNC.ISTEXT: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.LINEST: unexpected_mismatch=2, exact_typed_bit_match=4
- FUNC.LOGEST: unexpected_mismatch=2, exact_typed_bit_match=4
- FUNC.LOOKUP: excel_harness_blocked=6
- FUNC.MDURATION: excel_harness_blocked=6
- FUNC.MIRR: excel_harness_blocked=6
- FUNC.MODE.MULT: exact_typed_bit_match=6
- FUNC.NOMINAL: excel_harness_blocked=6
- FUNC.NPER: excel_harness_blocked=6
- FUNC.NPV: excel_harness_blocked=6
- FUNC.ODDFPRICE: excel_harness_blocked=6
- FUNC.ODDFYIELD: excel_harness_blocked=6
- FUNC.ODDLPRICE: excel_harness_blocked=6
- FUNC.ODDLYIELD: excel_harness_blocked=6
- FUNC.PDURATION: excel_harness_blocked=6
- FUNC.PERCENTOF: excel_harness_blocked=6
- FUNC.PRICE: excel_harness_blocked=6
- FUNC.PRICEMAT: excel_harness_blocked=6
- FUNC.PROB: excel_harness_blocked=6
- FUNC.PV: excel_harness_blocked=6
- FUNC.RANDARRAY: unexpected_mismatch=5, exact_typed_bit_match=1
- FUNC.REGEXEXTRACT: excel_harness_blocked=6
- FUNC.REGEXREPLACE: excel_harness_blocked=6
- FUNC.REGEXTEST: excel_harness_blocked=6
- FUNC.RRI: excel_harness_blocked=6
- FUNC.T.TEST: excel_harness_blocked=6
- FUNC.TEXTAFTER: excel_harness_blocked=6
- FUNC.TEXTBEFORE: excel_harness_blocked=6
- FUNC.TEXTSPLIT: excel_harness_blocked=6
- FUNC.TIMEVALUE: exact_typed_bit_match=4, unexpected_mismatch=2
- FUNC.TREND: unexpected_mismatch=2, exact_typed_bit_match=4
- FUNC.TTEST: excel_harness_blocked=6
- FUNC.WEIBULL: excel_harness_blocked=6
- FUNC.WEIBULL.DIST: excel_harness_blocked=6
- FUNC.XIRR: excel_harness_blocked=6
- FUNC.XNPV: excel_harness_blocked=6
- FUNC.YIELD: excel_harness_blocked=6
- FUNC.YIELDDISC: excel_harness_blocked=6
- FUNC.YIELDMAT: excel_harness_blocked=6
- FUNC.ZTEST: excel_harness_blocked=6

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
