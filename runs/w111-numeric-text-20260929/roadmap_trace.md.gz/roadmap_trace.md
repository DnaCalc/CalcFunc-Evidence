# Array Support Roadmap Trace

- Run ID: w111-numeric-text-20260929
- Tranche: w111-numeric-text-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 53
- Formula cases executed: 2544

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: numeric_text_grammar.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 1336
- unexpected_mismatch: 1208
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.ABS: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.INT: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.TRUNC: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.SIGN: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.SQRT: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.FACT: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.FACTDOUBLE: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.ISEVEN: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.ISODD: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.SIN: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.COS: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.ATAN: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.ACOT: exact_typed_bit_match=22, unexpected_mismatch=26
- FUNC.LN: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.EXP: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.DAY: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.MONTH: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.YEAR: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.HOUR: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.MINUTE: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.SECOND: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.ISOWEEKNUM: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.NOT: unexpected_mismatch=24, exact_typed_bit_match=24
- FUNC.BASE: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.DEC2BIN: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.DEC2HEX: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.DEC2OCT: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.BITAND: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.BITOR: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.BITXOR: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.BITLSHIFT: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.BITRSHIFT: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.ADDRESS: exact_typed_bit_match=30, unexpected_mismatch=18
- FUNC.COMPLEX: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.SLN: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.DDB: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.DATE: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.DAYS: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.EDATE: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.EOMONTH: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.WEEKDAY: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.ROUND: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.QUOTIENT: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.MOD: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.POWER: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.SUM: exact_typed_bit_match=36, unexpected_mismatch=12
- FUNC.AVERAGE: exact_typed_bit_match=36, unexpected_mismatch=12
- FUNC.MIN: exact_typed_bit_match=36, unexpected_mismatch=12
- FUNC.MAX: exact_typed_bit_match=36, unexpected_mismatch=12
- FUNC.PRODUCT: exact_typed_bit_match=36, unexpected_mismatch=12
- FUNC.COMBIN: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.PERMUT: exact_typed_bit_match=24, unexpected_mismatch=24
- FUNC.PERMUTATIONA: exact_typed_bit_match=24, unexpected_mismatch=24

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
