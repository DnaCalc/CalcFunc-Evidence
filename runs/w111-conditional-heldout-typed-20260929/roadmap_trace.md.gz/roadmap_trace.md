# Array Support Roadmap Trace

- Run ID: w111-conditional-heldout-typed-20260929
- Tranche: w111-conditional-heldout-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 3
- Formula cases executed: 660

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: conditional_array_shape.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- local_harness_blocked: 140
- exact_typed_bit_match: 496
- unexpected_mismatch: 24
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.IF: local_harness_blocked=63, exact_typed_bit_match=147, unexpected_mismatch=10
- FUNC.IFERROR: exact_typed_bit_match=174, local_harness_blocked=39, unexpected_mismatch=7
- FUNC.IFNA: exact_typed_bit_match=175, local_harness_blocked=38, unexpected_mismatch=7

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
