﻿# Array Support Roadmap Trace

- Run ID: w092-scenario-compatibility-cycle-001
- Tranche: w089-scenario-seed-compatibility
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance.
- Surfaces executed: 30
- Formula cases executed: 33

## Axes touched

- Function family/category: Compatibility.
- Array argument axes: scenario_seed_literal_args.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.
- Scenario seed sources: docs\function-lane\W61_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W62_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W66_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W67_SCENARIO_MANIFEST_SEED.csv.

## Rollup

- exact_typed_bit_match: 20
- known_residual: 13
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.BETADIST: exact_typed_bit_match=1
- FUNC.BETAINV: known_residual=1
- FUNC.BINOMDIST: exact_typed_bit_match=1
- FUNC.CHIDIST: known_residual=1
- FUNC.CHIINV: known_residual=1
- FUNC.CONCATENATE: exact_typed_bit_match=1
- FUNC.CONFIDENCE: exact_typed_bit_match=1
- FUNC.COVAR: exact_typed_bit_match=1
- FUNC.CRITBINOM: exact_typed_bit_match=1
- FUNC.EXPONDIST: exact_typed_bit_match=1
- FUNC.FDIST: known_residual=1
- FUNC.FINV: known_residual=1
- FUNC.FLOOR: exact_typed_bit_match=3
- FUNC.GAMMADIST: known_residual=1
- FUNC.GAMMAINV: known_residual=1
- FUNC.HYPGEOMDIST: known_residual=1
- FUNC.LOGINV: exact_typed_bit_match=1
- FUNC.LOGNORMDIST: exact_typed_bit_match=1
- FUNC.MODE: exact_typed_bit_match=2
- FUNC.NEGBINOMDIST: known_residual=1
- FUNC.NORMDIST: exact_typed_bit_match=1
- FUNC.NORMINV: exact_typed_bit_match=1
- FUNC.NORMSDIST: known_residual=1
- FUNC.NORMSINV: known_residual=1
- FUNC.PERCENTILE: exact_typed_bit_match=1
- FUNC.PERCENTRANK: exact_typed_bit_match=1
- FUNC.POISSON: exact_typed_bit_match=1
- FUNC.QUARTILE: exact_typed_bit_match=1
- FUNC.TDIST: known_residual=1
- FUNC.TINV: known_residual=1

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
