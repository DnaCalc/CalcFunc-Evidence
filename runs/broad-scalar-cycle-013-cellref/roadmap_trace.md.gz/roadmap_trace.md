# Broad Scalar Explorer Trace

- Generated/evaluated locally: `1000000`
- Excel candidate samples selected: `800`
- Distinct coverage areas: `78704`
- Local throughput: `377902.56` cases/sec
