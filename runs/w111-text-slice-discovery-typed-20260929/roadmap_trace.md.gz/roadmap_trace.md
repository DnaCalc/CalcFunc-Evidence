# Array Support Roadmap Trace

- Run ID: w111-text-slice-discovery-typed-20260929
- Tranche: w111-text-slice-discovery-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 10
- Formula cases executed: 1952

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: text_absent_count, text_count_kind_and_error_order, text_explicit_error_order, text_mid_start_count, text_multiple_array_broadcast, text_reference_broadcast, text_unary_array, text_unary_reference_array, text_unary_scalar_control.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 1346
- unexpected_mismatch: 599
- excel_harness_blocked: 7
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.LEFT: exact_typed_bit_match=257, unexpected_mismatch=62, excel_harness_blocked=1
- FUNC.RIGHT: exact_typed_bit_match=257, unexpected_mismatch=62, excel_harness_blocked=1
- FUNC.LEFTB: exact_typed_bit_match=258, unexpected_mismatch=61, excel_harness_blocked=1
- FUNC.RIGHTB: exact_typed_bit_match=254, unexpected_mismatch=65, excel_harness_blocked=1
- FUNC.MID: exact_typed_bit_match=128, unexpected_mismatch=70
- FUNC.MIDB: exact_typed_bit_match=128, unexpected_mismatch=70
- FUNC.EXACT: exact_typed_bit_match=2, unexpected_mismatch=46
- FUNC.LEN: exact_typed_bit_match=18, excel_harness_blocked=1, unexpected_mismatch=57
- FUNC.LENB: exact_typed_bit_match=27, excel_harness_blocked=1, unexpected_mismatch=48
- FUNC.ENCODEURL: exact_typed_bit_match=17, excel_harness_blocked=1, unexpected_mismatch=58

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
