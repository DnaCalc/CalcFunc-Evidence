# Broad Scalar Explorer Trace

- Generated/evaluated locally: `1500000`
- Excel candidate samples selected: `600`
- Distinct coverage areas: `107705`
- Local throughput: `335182.73` cases/sec
