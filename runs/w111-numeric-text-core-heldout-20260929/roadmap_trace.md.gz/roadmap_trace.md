# Array Support Roadmap Trace

- Run ID: w111-numeric-text-core-heldout-20260929
- Tranche: w111-numeric-text-core-heldout-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 6
- Formula cases executed: 3576

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: numeric_text_core_heldout.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- unexpected_mismatch: 1250
- exact_typed_bit_match: 2326
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.ABS: unexpected_mismatch=384, exact_typed_bit_match=212
- FUNC.INT: exact_typed_bit_match=490, unexpected_mismatch=106
- FUNC.ROUND: exact_typed_bit_match=506, unexpected_mismatch=90
- FUNC.ADDRESS: exact_typed_bit_match=506, unexpected_mismatch=90
- FUNC.SUM: unexpected_mismatch=120, exact_typed_bit_match=476
- FUNC.NOT: unexpected_mismatch=460, exact_typed_bit_match=136

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
