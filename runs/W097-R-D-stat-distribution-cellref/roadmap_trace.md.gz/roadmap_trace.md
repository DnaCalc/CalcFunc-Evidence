# Stat Distribution Explorer Trace

- Generated/evaluated locally: `1000000`
- Excel candidate samples selected: `800`
- Distinct coverage areas: `23710`
- Local throughput: `125977.33` cases/sec
