# Array Support Roadmap Trace

- Run ID: w111-aggregate-prepared-audit-typed-20260929
- Tranche: w111-aggregate-prepared-audit-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 2
- Formula cases executed: 248

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: aggregate_array, aggregate_direct, aggregate_reference, array_order, blank_reference_aggregate, domain_coercion_error_order, reference_order, unit_array_origin.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 222
- unexpected_mismatch: 26
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.HARMEAN: exact_typed_bit_match=109, unexpected_mismatch=15
- FUNC.DEVSQ: exact_typed_bit_match=113, unexpected_mismatch=11

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
