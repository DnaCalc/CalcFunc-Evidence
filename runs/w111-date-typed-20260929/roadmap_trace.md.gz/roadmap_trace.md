# Array Support Roadmap Trace

- Run ID: w111-date-typed-20260929
- Tranche: w111-date-typed-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 13
- Formula cases executed: 173

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: array_lift, typed_argument.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 144
- excel_harness_blocked: 7
- unexpected_mismatch: 22
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.DAY: exact_typed_bit_match=8, excel_harness_blocked=1
- FUNC.MONTH: exact_typed_bit_match=8, excel_harness_blocked=1
- FUNC.YEAR: exact_typed_bit_match=8, excel_harness_blocked=1
- FUNC.HOUR: exact_typed_bit_match=8, excel_harness_blocked=1
- FUNC.MINUTE: exact_typed_bit_match=8, excel_harness_blocked=1
- FUNC.SECOND: exact_typed_bit_match=8, excel_harness_blocked=1
- FUNC.ISOWEEKNUM: exact_typed_bit_match=8, excel_harness_blocked=1
- FUNC.DATE: exact_typed_bit_match=19, unexpected_mismatch=6
- FUNC.DAYS: exact_typed_bit_match=15, unexpected_mismatch=2
- FUNC.EDATE: exact_typed_bit_match=13, unexpected_mismatch=4
- FUNC.EOMONTH: exact_typed_bit_match=13, unexpected_mismatch=4
- FUNC.WEEKDAY: exact_typed_bit_match=15, unexpected_mismatch=2
- FUNC.WEEKNUM: exact_typed_bit_match=13, unexpected_mismatch=4

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
