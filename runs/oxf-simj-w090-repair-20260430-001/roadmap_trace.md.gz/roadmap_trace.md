﻿# Array Support Roadmap Trace

- Run ID: oxf-simj-w090-repair-20260430-001
- Tranche: w090-successor-all-other-executable-v0
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance.
- Surfaces executed: 73
- Formula cases executed: 139

## Axes touched

- Function family/category: Compatibility, Engineering functions, Financial functions, Logical functions, Lookup and reference functions, Math and trigonometry functions, Statistical functions, Text functions.
- Risk bands: high, low, medium.
- Array argument axes: one_array_arg:arg1, one_array_arg:arg2, one_array_arg:arg3, one_array_arg:arg4.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.
- Scenario seed sources: docs\function-lane\W24_BATCH01_SWITCH_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W24_BATCH05_CONFIDENCE_TEST_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W39_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W40_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W60_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W61_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W62_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W64_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W66_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W67_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W68_SCENARIO_MANIFEST_SEED.csv.

## Rollup

- exact_typed_bit_match: 102
- unexpected_mismatch: 37

## Function highlights

- FUNC.BETADIST: exact_typed_bit_match=3
- FUNC.BETAINV: unexpected_mismatch=3
- FUNC.BINOMDIST: exact_typed_bit_match=3
- FUNC.CHIDIST: unexpected_mismatch=2
- FUNC.CHIINV: unexpected_mismatch=2
- FUNC.CONFIDENCE: exact_typed_bit_match=3
- FUNC.CRITBINOM: exact_typed_bit_match=3
- FUNC.EXPONDIST: exact_typed_bit_match=3
- FUNC.FDIST: unexpected_mismatch=3
- FUNC.FINV: unexpected_mismatch=3
- FUNC.GAMMADIST: unexpected_mismatch=3
- FUNC.GAMMAINV: unexpected_mismatch=3
- FUNC.HYPGEOMDIST: unexpected_mismatch=3
- FUNC.LOGNORMDIST: exact_typed_bit_match=3
- FUNC.NEGBINOMDIST: unexpected_mismatch=3
- FUNC.NORMDIST: exact_typed_bit_match=3
- FUNC.NORMINV: exact_typed_bit_match=3
- FUNC.NORMSDIST: unexpected_mismatch=1
- FUNC.NORMSINV: unexpected_mismatch=1
- FUNC.POISSON: exact_typed_bit_match=3
- FUNC.TDIST: unexpected_mismatch=3
- FUNC.TINV: unexpected_mismatch=2
- FUNC.CONCATENATE: exact_typed_bit_match=3
- FUNC.CHOOSECOLS: exact_typed_bit_match=2
- FUNC.CHOOSEROWS: exact_typed_bit_match=2
- FUNC.DROP: exact_typed_bit_match=2
- FUNC.EXPAND: exact_typed_bit_match=3
- FUNC.SORT: exact_typed_bit_match=2
- FUNC.TAKE: exact_typed_bit_match=2
- FUNC.TOCOL: exact_typed_bit_match=1
- FUNC.TOROW: exact_typed_bit_match=2
- FUNC.WRAPCOLS: exact_typed_bit_match=1
- FUNC.WRAPROWS: exact_typed_bit_match=1
- FUNC.COMPLEX: exact_typed_bit_match=2
- FUNC.IMABS: exact_typed_bit_match=1
- FUNC.IMAGINARY: exact_typed_bit_match=1
- FUNC.IMARGUMENT: exact_typed_bit_match=1
- FUNC.IMCONJUGATE: exact_typed_bit_match=1
- FUNC.IMCOS: exact_typed_bit_match=1
- FUNC.IMCOSH: exact_typed_bit_match=1
- FUNC.IMCOT: exact_typed_bit_match=1
- FUNC.IMCSC: exact_typed_bit_match=1
- FUNC.IMCSCH: exact_typed_bit_match=1
- FUNC.IMDIV: exact_typed_bit_match=2
- FUNC.IMEXP: exact_typed_bit_match=1
- FUNC.IMLN: exact_typed_bit_match=1
- FUNC.IMLOG10: exact_typed_bit_match=1
- FUNC.IMLOG2: exact_typed_bit_match=1
- FUNC.IMPOWER: exact_typed_bit_match=2
- FUNC.IMPRODUCT: exact_typed_bit_match=2
- FUNC.IMREAL: exact_typed_bit_match=1
- FUNC.IMSEC: exact_typed_bit_match=1
- FUNC.IMSECH: exact_typed_bit_match=1
- FUNC.IMSIN: exact_typed_bit_match=1
- FUNC.IMSINH: exact_typed_bit_match=1
- FUNC.IMSQRT: exact_typed_bit_match=1
- FUNC.IMSUB: exact_typed_bit_match=2
- FUNC.IMSUM: exact_typed_bit_match=2
- FUNC.IMTAN: exact_typed_bit_match=1
- FUNC.DOLLARFR: exact_typed_bit_match=2
- FUNC.SWITCH: exact_typed_bit_match=3
- FUNC.CONFIDENCE.T: unexpected_mismatch=3
- FUNC.UNICHAR: exact_typed_bit_match=1
- FUNC.IFS: exact_typed_bit_match=3
- FUNC.MUNIT: exact_typed_bit_match=1
- FUNC.Z.TEST: unexpected_mismatch=2
- FUNC.ADDRESS: exact_typed_bit_match=2
- FUNC.SERIESSUM: exact_typed_bit_match=3
- FUNC.TRIMMEAN: exact_typed_bit_match=1
- FUNC.LOGINV: exact_typed_bit_match=3
- FUNC.PERCENTILE: exact_typed_bit_match=1
- FUNC.PERCENTRANK: exact_typed_bit_match=1
- FUNC.QUARTILE: exact_typed_bit_match=1

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
