﻿# Array Support Roadmap Trace

- Run ID: w092-max20-lookup-reference-cycle-001
- Tranche: w089-scenario-seed-lookup-and-reference-functions
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 17
- Formula cases executed: 53

## Axes touched

- Function family/category: Lookup and reference functions.
- Array argument axes: scenario_seed_literal_args.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.
- Scenario seed sources: docs\function-lane\LOOKUP_XLL_BRIDGE_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W10_S2_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W12_S6_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W33_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W39_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W40_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\XMATCH_SCENARIO_MANIFEST_SEED.csv.

## Rollup

- exact_typed_bit_match: 53
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.ADDRESS: exact_typed_bit_match=3
- FUNC.CHOOSECOLS: exact_typed_bit_match=1
- FUNC.CHOOSEROWS: exact_typed_bit_match=1
- FUNC.DROP: exact_typed_bit_match=3
- FUNC.EXPAND: exact_typed_bit_match=1
- FUNC.HSTACK: exact_typed_bit_match=3
- FUNC.MATCH: exact_typed_bit_match=9
- FUNC.SORT: exact_typed_bit_match=2
- FUNC.SORTBY: exact_typed_bit_match=1
- FUNC.TAKE: exact_typed_bit_match=3
- FUNC.TOCOL: exact_typed_bit_match=1
- FUNC.TOROW: exact_typed_bit_match=1
- FUNC.TRANSPOSE: exact_typed_bit_match=1
- FUNC.VSTACK: exact_typed_bit_match=1
- FUNC.WRAPCOLS: exact_typed_bit_match=1
- FUNC.WRAPROWS: exact_typed_bit_match=1
- FUNC.XMATCH: exact_typed_bit_match=20

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
