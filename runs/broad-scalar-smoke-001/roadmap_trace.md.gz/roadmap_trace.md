# Broad Scalar Explorer Trace

- Generated/evaluated locally: `100000`
- Excel candidate samples selected: `200`
- Distinct coverage areas: `11920`
- Local throughput: `328505.18` cases/sec
