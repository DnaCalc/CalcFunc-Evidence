﻿# Array Support Roadmap Trace

- Run ID: w090-repair-final-statistical-functions-001
- Tranche: w090-successor-statistical-functions
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance.
- Surfaces executed: 3
- Formula cases executed: 6

## Axes touched

- Function family/category: Statistical functions.
- Risk bands: high, medium.
- Array argument axes: one_array_arg:arg1, one_array_arg:arg2, one_array_arg:arg3.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.
- Scenario seed sources: docs\function-lane\W24_BATCH05_CONFIDENCE_TEST_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W62_SCENARIO_MANIFEST_SEED.csv.

## Rollup

- unexpected_mismatch: 5
- exact_typed_bit_match: 1

## Function highlights

- FUNC.CONFIDENCE.T: unexpected_mismatch=3
- FUNC.Z.TEST: unexpected_mismatch=2
- FUNC.TRIMMEAN: exact_typed_bit_match=1

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
