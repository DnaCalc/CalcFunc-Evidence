# W108 Phase D — POWER fractional-exponent puzzle

Status: `open_puzzle` (characterized, not yet fixed)
Catalog row: `docs/OXFUNC_EXCEL_DISCREPANCY_CATALOG.md` G4 (POWER)

## The finding

64-bit Excel `POWER(x, y)` for a **fractional exponent and positive base** is
`exp(y · ln x)` computed with the x87 `exp`/`ln` (`crate::excel_numeric::x87`)
and **f64 intermediates** — NOT `powf` (UCRT) and NOT the fused x87 `x^y`
(`FYL2X` + `F2XM1`) chain. Live Excel 16.0 build 20131, Value2 cell-ref plumbing.

Composition bake-off (220-row live sweep, `x87lab`):

| candidate | bit-exact |
|-----------|-----------|
| `exp(y · ln x)`, f64 intermediates | **189 / 220 (86%)** |
| `powf(x, y)` (current OxFunc) | 12 / 220 |
| fused x87 `2^(y · log2 x)` (`FYL2X`+`F2XM1`) | ~10 / 220 |
| `y · ln x` product at 80-bit then exp | 22 / 220 |
| `2^(y · log2 x)` with f64 product | ~12 / 220 |

Head-to-head on a 90-row sweep: `exp(y·ln x)` was **strictly closer to Excel
than `powf` on 84/90 rows**, tied on 5, and worse on exactly 1 (a 1-ULP case
where `powf` happened to be exact). So `exp(y·ln x)` dominates `powf`.

## What's unresolved

The remaining ~14% (`power_witnesses.tsv`, DIVERGE section) are **all exactly 1
ULP** off. Every sub-op (x87 `exp`, x87 `ln`, the f64 `*`) is individually
bit-exact to Excel, yet the composition lands 1 ULP off on these rows. The
intermediate-precision detail that decides them (e.g. whether Excel's internal
POWER uses a different `ln`, or a fused reduction) is the open question — the
same class of "bespoke internal routine" mystery that EXP/LN needed a full
reverse-engineering pass (`C:/Temp/ExcelExpFunction`) to crack.

## Decision (Phase A, 2026-07-04)

Kept `powf` in `power_kernel` for now (no partial 86% swap into a "bit-exact"
commit). Integer exponents keep the validated `powi` publication path
(unaffected). A dedicated Phase-D pass should either reverse-engineer the last
1-ULP detail (target 100%) or land `exp(y·ln x)` as the best-achievable
improvement (86% exact, rest 1 ULP, strictly better than `powf`).

## Witnesses

`power_witnesses.tsv` — columns: `base_bits`, `exp_bits`, `excel_bits`,
`exp(y*lnx)_bits`, `powf_bits`, `exp_ulp` (dist Excel↔exp model), `powf_ulp`
(dist Excel↔powf), decimal `base`, `exp`. AGREE section: the model reproduces
Excel. DIVERGE section: the 1-ULP puzzle rows. All inputs are exact doubles.

Reproduce: the `x87lab` scratch harness (`x87lab4.rs` composition bake-off +
`compare_pow.ps1` driving Excel via `smart-fuzzer/tools/CellRefBatch.psm1`).
