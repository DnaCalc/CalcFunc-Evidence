﻿# Array Support Roadmap Trace

- Run ID: w090-repair-final-financial-functions-001
- Tranche: w090-successor-financial-functions
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance.
- Surfaces executed: 1
- Formula cases executed: 2

## Axes touched

- Function family/category: Financial functions.
- Risk bands: high.
- Array argument axes: one_array_arg:arg1, one_array_arg:arg2.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.
- Scenario seed sources: docs\function-lane\W64_SCENARIO_MANIFEST_SEED.csv.

## Rollup

- exact_typed_bit_match: 2

## Function highlights

- FUNC.DOLLARFR: exact_typed_bit_match=2

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
