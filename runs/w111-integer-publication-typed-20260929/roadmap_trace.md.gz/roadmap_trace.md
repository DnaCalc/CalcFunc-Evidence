# Array Support Roadmap Trace

- Run ID: w111-integer-publication-typed-20260929
- Tranche: w111-integer-publication-typed-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 14
- Formula cases executed: 302

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: array_lift, typed_argument.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 259
- excel_harness_blocked: 7
- unexpected_mismatch: 36
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.INT: exact_typed_bit_match=12, excel_harness_blocked=1
- FUNC.ISEVEN: exact_typed_bit_match=12, excel_harness_blocked=1
- FUNC.ISODD: exact_typed_bit_match=12, excel_harness_blocked=1
- FUNC.TRUNC: exact_typed_bit_match=23, unexpected_mismatch=2
- FUNC.SQRT: exact_typed_bit_match=12, excel_harness_blocked=1
- FUNC.PHI: exact_typed_bit_match=12, excel_harness_blocked=1
- FUNC.RADIANS: exact_typed_bit_match=12, excel_harness_blocked=1
- FUNC.STANDARDIZE: exact_typed_bit_match=34, unexpected_mismatch=3
- FUNC.SECH: exact_typed_bit_match=12, excel_harness_blocked=1
- FUNC.EXPONDIST: exact_typed_bit_match=32, unexpected_mismatch=5
- FUNC.EXPON.DIST: exact_typed_bit_match=29, unexpected_mismatch=8
- FUNC.PERMUTATIONA: exact_typed_bit_match=23, unexpected_mismatch=2
- FUNC.LCM: exact_typed_bit_match=17, unexpected_mismatch=8
- FUNC.GCD: exact_typed_bit_match=17, unexpected_mismatch=8

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
