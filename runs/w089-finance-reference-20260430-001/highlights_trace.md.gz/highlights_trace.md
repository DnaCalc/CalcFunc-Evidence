﻿# Expanded Smart-Fuzzer Highlights

Run id: `w089-finance-reference-20260430-001`

## Counts

1. Local generated/evaluated cases: `1000000`
2. Excel candidate samples: `256`
3. Exact sample matches: `197`
4. Expected known financial exactness or literal-encoding deviations: `59`
5. Unexpected mismatches: `0`
6. Blocked sample rows: `0`

## Explored Areas

See `roadmap_trace.md` and `roadmap_trace.json` in this run directory. The run
covered PMT, PPMT, and IPMT across arity, rate, horizon, present/future value,
payment timing, and period-position bands.

## Interpretation

Known PMT/PPMT/IPMT non-zero-rate exactness drift is treated as expected pending
further investigation. Tiny differences caused by formula literal decimal
encoding are tracked separately from repair-grade failures. Unexpected
mismatches, if any, are written as failure packets under `failure_packets/`.
