# Broad Scalar Explorer Trace

- Generated/evaluated locally: `1500000`
- Excel candidate samples selected: `600`
- Distinct coverage areas: `107498`
- Local throughput: `196015.93` cases/sec
