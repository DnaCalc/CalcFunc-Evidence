# Array Support Roadmap Trace

- Run ID: w111-address-refinement-20260929
- Tranche: address-refinement-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 1
- Formula cases executed: 597

## Axes touched

- Function family/category: Lookup & Reference.
- Array argument axes: coercion-before-error, escaped-length-and-rendering, explicit-error-order, sheet-reference-token, style-text, unicode-identifier.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 252
- unexpected_mismatch: 341
- excel_harness_blocked: 4
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.ADDRESS: exact_typed_bit_match=252, unexpected_mismatch=341, excel_harness_blocked=4

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
