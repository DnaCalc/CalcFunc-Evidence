# Array Support Roadmap Trace

- Run ID: w111-explicit-number-text-typed-20260929
- Tranche: w111-explicit-number-text-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 3
- Formula cases executed: 584

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: explicit_array_serializer, explicit_general_format, explicit_number_serializer.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 46
- unexpected_mismatch: 538
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.VALUETOTEXT: exact_typed_bit_match=23, unexpected_mismatch=257
- FUNC.ARRAYTOTEXT: exact_typed_bit_match=23, unexpected_mismatch=257
- FUNC.TEXT: unexpected_mismatch=24

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
