# Broad Scalar Explorer Trace

- Generated/evaluated locally: `50000`
- Excel candidate samples selected: `10`
- Distinct coverage areas: `6732`
- Local throughput: `223567.40` cases/sec
