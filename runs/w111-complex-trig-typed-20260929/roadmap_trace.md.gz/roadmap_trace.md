# Array Support Roadmap Trace

- Run ID: w111-complex-trig-typed-20260929
- Tranche: w111-complex-trig-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 6
- Formula cases executed: 928

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: typed_argument.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 557
- unexpected_mismatch: 371
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.IMCOS: exact_typed_bit_match=116, unexpected_mismatch=84
- FUNC.IMSIN: exact_typed_bit_match=113, unexpected_mismatch=87
- FUNC.IMTAN: exact_typed_bit_match=127, unexpected_mismatch=73
- FUNC.IMCOT: exact_typed_bit_match=109, unexpected_mismatch=91
- FUNC.IMSQRT: exact_typed_bit_match=48, unexpected_mismatch=16
- FUNC.IMARGUMENT: exact_typed_bit_match=44, unexpected_mismatch=20

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
