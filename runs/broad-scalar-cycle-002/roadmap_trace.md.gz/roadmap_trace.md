# Broad Scalar Explorer Trace

- Generated/evaluated locally: `1000000`
- Excel candidate samples selected: `200`
- Distinct coverage areas: `77017`
- Local throughput: `156719.64` cases/sec
