﻿# Array Support Roadmap Trace

- Run ID: w092-max20-math-cycle-001
- Tranche: w089-scenario-seed-math-and-trigonometry-functions
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 20
- Formula cases executed: 61

## Axes touched

- Function family/category: Math and trigonometry functions.
- Array argument axes: scenario_seed_literal_args.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.
- Scenario seed sources: docs\function-lane\ABS_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\COERCION_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W10_S3_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W12_S2_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W66_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W67_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\XLL_ADDIN_BRIDGE_VALIDATION_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\XMATCH_SCENARIO_MANIFEST_SEED.csv.

## Rollup

- exact_typed_bit_match: 58
- known_residual: 1
- adapter_or_seam_mismatch: 2
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.ABS: exact_typed_bit_match=8
- FUNC.ASIN: exact_typed_bit_match=2
- FUNC.CEILING.MATH: exact_typed_bit_match=2
- FUNC.CEILING.PRECISE: exact_typed_bit_match=1
- FUNC.FLOOR.MATH: exact_typed_bit_match=2
- FUNC.FLOOR.PRECISE: exact_typed_bit_match=1
- FUNC.ISO.CEILING: exact_typed_bit_match=1
- FUNC.MDETERM: exact_typed_bit_match=3
- FUNC.MINVERSE: known_residual=1, adapter_or_seam_mismatch=1, exact_typed_bit_match=1
- FUNC.MMULT: exact_typed_bit_match=2, adapter_or_seam_mismatch=1
- FUNC.MUNIT: exact_typed_bit_match=2
- FUNC.PI: exact_typed_bit_match=1
- FUNC.ROUND: exact_typed_bit_match=4
- FUNC.SEQUENCE: exact_typed_bit_match=11
- FUNC.SERIESSUM: exact_typed_bit_match=3
- FUNC.SIN: exact_typed_bit_match=3
- FUNC.SUMPRODUCT: exact_typed_bit_match=5
- FUNC.SUMX2MY2: exact_typed_bit_match=4
- FUNC.SUMX2PY2: exact_typed_bit_match=1
- FUNC.SUMXMY2: exact_typed_bit_match=1

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
