# Array Support Roadmap Trace

- Run ID: w111-mod-production-typed-20260929
- Tranche: w111-mod-production-typed-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 1
- Formula cases executed: 353

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: numeric_array_binding, numeric_broadcast_binding, typed_discovery, typed_reference_discovery.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 335
- unexpected_mismatch: 18
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.MOD: exact_typed_bit_match=335, unexpected_mismatch=18

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
