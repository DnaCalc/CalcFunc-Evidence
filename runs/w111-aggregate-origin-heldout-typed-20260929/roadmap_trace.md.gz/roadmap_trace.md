# Array Support Roadmap Trace

- Run ID: w111-aggregate-origin-heldout-typed-20260929
- Tranche: w111-aggregate-origin-heldout-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 3
- Formula cases executed: 2190

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: independent_cross_origin_precedence, original_value_order.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 2190
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.MEDIAN: exact_typed_bit_match=730
- FUNC.HARMEAN: exact_typed_bit_match=730
- FUNC.DEVSQ: exact_typed_bit_match=730

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
