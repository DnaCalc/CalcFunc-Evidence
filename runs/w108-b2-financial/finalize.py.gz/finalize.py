"""Finalize: lock winning models, produce per-case tables, compositions.json."""
from fin import *
import mpmath, json
mpmath.mp.prec=200
def cr_log(x): return float(mpmath.log(mpmath.mpf(x)))

# ---------- winning models ----------
def fv_exp(rate,m,pmt,pv,typ):
    if m==0: return -pv
    if rate==0.0: return -(pv+pmt*m)
    L=m*log1p(rate); F=exp(L); em=expm1(L); tf=1.0+rate*typ
    return -(pv*F+pmt*tf*(em/rate))

def pmt_model(rate,nper,pv,fv,typ):
    if rate==0.0: return -(fv+pv)/nper
    negL=-nper*log1p(rate); invF=exp(negL); denom=-expm1(negL); tf=1.0+rate*typ
    return -(pv+fv*invF)*rate*(1.0/(tf*denom))

def ipmt_model(rate,per,nper,pv,fv,typ):
    per=int(per); rpmt=pmt_model(rate,nper,pv,fv,typ)
    if per==1:
        rip = 0.0 if typ>0 else -pv
    elif typ>0:
        rip = fv_exp(rate,per-2,rpmt,pv,1) - rpmt
    else:
        rip = fv_exp(rate,per-1,rpmt,pv,0)
    return rip*rate

def ppmt_model(rate,per,nper,pv,fv,typ):
    return pmt_model(rate,nper,pv,fv,typ) - ipmt_model(rate,per,nper,pv,fv,typ)

def cumprinc_model(rate,nper,pv,start,end,typ):
    acc=0.0
    for k in range(int(start),int(end)+1):
        acc += ppmt_model(rate,k,nper,pv,0.0,typ)
    return acc

def cumipmt_model(rate,nper,pv,start,end,typ):
    acc=0.0
    for k in range(int(start),int(end)+1):
        acc += ipmt_model(rate,k,nper,pv,0.0,typ)
    return acc

def nper_model(rate,pmt,pv,fv,typ):
    if rate==0.0: return -(pv+fv)/pmt
    tf=1.0+rate*typ
    ratio=(tf*pmt - fv*rate)/(tf*pmt + pv*rate)
    return cr_log(ratio)/log(1.0+rate)

MODELS={'PMT':pmt_model,'IPMT':ipmt_model,'PPMT':ppmt_model,
        'CUMPRINC':cumprinc_model,'CUMIPMT':cumipmt_model,'NPER':nper_model}

# degenerate (non-realistic) probe ids to flag separately
def is_degenerate(fn,args):
    if fn=='PMT' and args[0]==1.0 and args[1]==1023: return True
    if fn=='PMT' and args[2]==0.0: return True   # pv=0 FV-style probe
    return False

rows=load_corpus()
report={}
for fn,model in MODELS.items():
    frows=by_fn(rows,fn)
    matched=0; realistic_total=0; realistic_matched=0; ubh={}; cases=[]
    for r in frows:
        exb=r['out_bits']; deg=is_degenerate(fn,r['args'])
        try: gb=bits(model(*r['args']))
        except Exception: gb='ERR'
        m=(gb==exb)
        u=0 if m else (ulp(frombits(gb),frombits(exb)) if gb!='ERR' else -1)
        if m: matched+=1
        if not deg:
            realistic_total+=1
            if m: realistic_matched+=1
            ubh[u]=ubh.get(u,0)+1
        cases.append({'id':r['id'],'args':r['args'],'model_bits':gb,'excel_bits':exb,
                      'match':m,'ulp':u,'degenerate':deg})
    report[fn]={'matched_all':matched,'total_all':len(frows),
                'realistic_matched':realistic_matched,'realistic_total':realistic_total,
                'realistic_ulp_hist':dict(sorted(ubh.items())),'cases':cases}

print("=== FINAL SUMMARY (realistic cases) ===")
for fn,s in report.items():
    print(f"{fn}: {s['realistic_matched']}/{s['realistic_total']} exact  ulp_hist={s['realistic_ulp_hist']}")

json.dump(report, open('final_report.json','w'), indent=1)
print("\nwrote final_report.json")
