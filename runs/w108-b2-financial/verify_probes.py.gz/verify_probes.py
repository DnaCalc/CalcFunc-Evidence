"""Verify winning models against the ORIGINAL probe/conf ground truth (P8-P20, C1-C11)."""
import json, os, sys
sys.path.insert(0, os.getcwd())
from fin import *
import mpmath; mpmath.mp.prec=200
def cr_log(x): return float(mpmath.log(mpmath.mpf(x)))

SCR_OLD = r"C:\Users\GOVERT~1\AppData\Local\Temp\claude\C--Work-DnaCalc-OxFunc\87ad2a27-b42e-48bb-9404-39e6b7d02cd9\scratchpad"
probes = {p['id']:p for p in json.load(open(os.path.join(SCR_OLD,'excel_probe_results.json')))['probes']}
conf   = {c['id']:c for c in json.load(open(os.path.join(SCR_OLD,'conf_excel_out.json')))}

def fv_exp(rate,m,pmt,pv,typ):
    if m==0: return -pv
    if rate==0.0: return -(pv+pmt*m)
    L=m*log1p(rate); F=exp(L); em=expm1(L); tf=1.0+rate*typ
    return -(pv*F+pmt*tf*(em/rate))
def pmt_model(rate,nper,pv,fv,typ):
    if rate==0.0: return -(fv+pv)/nper
    negL=-nper*log1p(rate); invF=exp(negL); denom=-expm1(negL); tf=1.0+rate*typ
    return -(pv+fv*invF)*rate*(1.0/(tf*denom))
def ipmt_model(rate,per,nper,pv,fv,typ):
    per=int(per); rpmt=pmt_model(rate,nper,pv,fv,typ)
    if per==1: rip = 0.0 if typ>0 else -pv
    elif typ>0: rip = fv_exp(rate,per-2,rpmt,pv,1)-rpmt
    else: rip = fv_exp(rate,per-1,rpmt,pv,0)
    return rip*rate
def ppmt_model(rate,per,nper,pv,fv,typ):
    return pmt_model(rate,nper,pv,fv,typ)-ipmt_model(rate,per,nper,pv,fv,typ)
def cumprinc_model(rate,nper,pv,s,e,typ):
    acc=0.0
    for k in range(int(s),int(e)+1): acc+=ppmt_model(rate,k,nper,pv,0.0,typ)
    return acc
def cumipmt_model(rate,nper,pv,s,e,typ):
    acc=0.0
    for k in range(int(s),int(e)+1): acc+=ipmt_model(rate,k,nper,pv,0.0,typ)
    return acc
def nper_model(rate,pmt,pv,fv,typ):
    if rate==0.0: return -(pv+fv)/pmt
    tf=1.0+rate*typ; ratio=(tf*pmt-fv*rate)/(tf*pmt+pv*rate)
    return cr_log(ratio)/log(1.0+rate)

# map probe ids to (fn, args in Excel order)
tests = [
    # PMT probes: input_decimal is [rate,nper,pv,fv,type]
    ('P8','PMT',probes['P8']['input_decimal']),
    ('P9','PMT',probes['P9']['input_decimal']),
    ('P10','PMT',probes['P10']['input_decimal']),
    ('P11','PMT',probes['P11']['input_decimal']),
    ('C1','PMT',None),('C2','PMT',None),('C3','PMT',None),('C10','PMT',None),
    # IPMT: input [rate,per,nper,pv,fv,type]
    ('P12','IPMT',probes['P12']['input_decimal']),
    ('P13','IPMT',probes['P13']['input_decimal']),
    ('P15b','IPMT',probes['P15b']['input_decimal']),
    ('C5','IPMT',None),
    # PPMT
    ('P14','PPMT',probes['P14']['input_decimal']),
    ('P15a','PPMT',probes['P15a']['input_decimal']),
    ('C4','PPMT',None),('C11','PPMT',None),
    # CUMPRINC / CUMIPMT: [rate,nper,pv,start,end,type]
    ('P16','CUMPRINC',probes['P16']['input_decimal']),
    ('P17a','CUMPRINC',probes['P17a']['input_decimal']),
    ('P17b','CUMIPMT',probes['P17b']['input_decimal']),
    # NPER: [rate,pmt,pv,fv,type]
    ('P20','NPER',probes['P20']['input_decimal']),
    ('C6','NPER',None),('C7','NPER',None),('C8','NPER',None),('C9','NPER',None),
]
# conf cases need args reconstructed - they were computed earlier; we only have output bits.
# For C* we don't have inputs here, so only report P* (have inputs) + note.
MODELS={'PMT':pmt_model,'IPMT':ipmt_model,'PPMT':ppmt_model,
        'CUMPRINC':cumprinc_model,'CUMIPMT':cumipmt_model,'NPER':nper_model}

print(f"{'ID':6} {'FN':9} {'MODEL':20} {'EXCEL':20} {'RESULT'}")
tot=0; mat=0
for pid,fn,args in tests:
    if args is None:  # conf case - only have output bits, skip model calc
        exb=conf[pid]['bits']
        print(f"{pid:6} {fn:9} {'(no inputs saved)':20} {exb:20} SKIP")
        continue
    exb=probes[pid]['output_bits']
    try: gb=bits(MODELS[fn](*args))
    except Exception as e: gb='ERR:%s'%e
    m=(gb==exb); tot+=1; mat+= m
    u='0' if m else (str(ulp(frombits(gb),frombits(exb))) if gb.startswith('0x') else '-')
    print(f"{pid:6} {fn:9} {gb:20} {exb:20} {'MATCH' if m else 'ULP='+u}")
print(f"\nProbe cases with inputs: {mat}/{tot} exact")
