"""W108-B2 financial corpus generator.

Emits corpus.jsonl rows: {id, fn, args (Excel arg order, raw f64 decimals)}.
Args are the EXACT doubles that will be pushed into Excel cells via Value2,
so the reverse-engineering model and Excel see bit-identical inputs.

Excel arg orders:
  PMT(rate,nper,pv,fv,type)
  IPMT(rate,per,nper,pv,fv,type)
  PPMT(rate,per,nper,pv,fv,type)
  CUMPRINC(rate,nper,pv,start,end,type)
  CUMIPMT(rate,nper,pv,start,end,type)
  NPER(rate,pmt,pv,fv,type)
"""
import json, os

SCR = os.path.dirname(os.path.abspath(__file__))
rows = []

def add(fn, args, tags=""):
    rid = f"{fn}-{len([r for r in rows if r['fn']==fn]):04d}"
    rows.append({"id": rid, "fn": fn, "args": [float(a) for a in args], "tags": tags})

# ---- rate regimes -------------------------------------------------
rates = [
    0.05/12,        # canonical monthly 5% (the 1-ULP residual regime)
    0.08/12,
    0.10/12,
    0.03/4,
    0.065/12,
    0.0725/12,
    0.045/12,
    0.12/12,        # 0.01 exact
    0.06/12,        # 0.005 exact
    0.04/2,         # 0.02 exact
    0.09/12,
    0.055/12,
    1e-9,
    1e-13,
    1e-17,
    -0.01/12,
    -0.005,
    0.25,
    1.0,
    0.5,
    0.0008333333333333334,  # P-series probe rate
    0.004166666666666667,   # P-series probe rate
]

# ---- PMT: ~40 (r,n,pv,fv,type) ------------------------------------
pmt_grid = [
    (0.05/12, 360, 200000, 0, 0),
    (0.05/12, 360, 200000, 0, 1),
    (0.05/12, 180, 200000, 0, 0),
    (0.05/12, 120, 100000, 0, 0),
    (0.08/12, 10, 10000, 0, 0),
    (0.08/12, 60, 25000, 0, 0),
    (0.10/12, 36, 8000, 0, 0),
    (0.03/4, 16, 5000, 1000, 0),
    (0.03/4, 16, 5000, 1000, 1),
    (0.065/12, 240, 150000, 0, 0),
    (0.0725/12, 360, 275000, 0, 0),
    (0.045/12, 300, 180000, 0, 0),
    (0.06/12, 48, 20000, 0, 0),
    (0.12/12, 12, 5000, 0, 0),
    (0.04/2, 20, 10000, 0, 0),
    (0.09/12, 84, 32000, 0, 0),
    (0.055/12, 360, 200000, 5000, 0),
    (0.055/12, 360, 200000, 5000, 1),
    (0.05/12, 360, 200000, 10000, 0),
    (0.05/12, 360, 200000, 10000, 1),
    (0.05/12, 360, 200000, -10000, 0),
    (0.05/12, 359, 200000, 0, 0),
    (0.05/12, 361, 200000, 0, 0),
    (0.08/12, 12, 10000, 0, 0),   # P8 analog
    (1e-9, 120, 100000, 0, 0),    # P9
    (1e-13, 12, 1000, 0, 0),      # P10
    (1e-17, 10, 1000, 0, 0),      # P11
    (-0.01/12, 12, 1000, 0, 0),
    (0.25, 10, 1000, 0, 0),
    (1.0, 1023, 0, -1, 0),
    (0.5, 24, 5000, 0, 0),
    (0.0008333333333333334, 12, 10000, 0, 0),  # P8 exact
    (0.05/12, 360, -200000, 0, 0),
    (0.05/12, 360, 200000, 0, 0),
    (0.02, 40, 15000, 2000, 0),
    (0.02, 40, 15000, 2000, 1),
    (0.075/12, 180, 95000, 0, 0),
    (0.0333333333333/12, 240, 120000, 0, 0),
    (0.11/12, 60, 18000, 500, 0),
    (0.0125, 48, 22000, 0, 1),
    (0.0025, 720, 0, -1, 0),
    (0.09/12, 300, 210000, 15000, 1),
]
for g in pmt_grid:
    add("PMT", g, "pmt_grid")

# ---- IPMT & PPMT over many per for a few (r,n,pv) -----------------
ip_bases = [
    (0.05/12, 360, 200000, 0, 0),
    (0.05/12, 360, 200000, 0, 1),
    (0.08/12, 60, 25000, 0, 0),
    (0.10/12, 36, 8000, 0, 0),
    (0.03/4, 16, 5000, 1000, 0),
]
per_list = [1, 2, 3, 4, 5, 6, 12, 24, 36, 60]
for (r, n, pv, fv, typ) in ip_bases:
    for per in per_list:
        if per > n:
            continue
        # IPMT(rate,per,nper,pv,fv,type)
        add("IPMT", (r, per, n, pv, fv, typ), "ipmt_grid")
        add("PPMT", (r, per, n, pv, fv, typ), "ppmt_grid")
    # also last period
    add("IPMT", (r, n, n, pv, fv, typ), "ipmt_last")
    add("PPMT", (r, n, n, pv, fv, typ), "ppmt_last")

# ---- CUMPRINC & CUMIPMT over multi-period ranges ------------------
cum_bases = [
    (0.05/12, 360, 200000, 0),
    (0.05/12, 360, 200000, 1),
    (0.08/12, 60, 25000, 0),
    (0.10/12, 36, 8000, 0),
    (0.065/12, 240, 150000, 0),
]
cum_ranges = [(1, 1), (1, 2), (1, 3), (1, 12), (13, 24), (1, 6), (7, 12), (2, 5)]
for (r, n, pv, typ) in cum_bases:
    for (s, e) in cum_ranges:
        if e > n:
            continue
        # CUMPRINC(rate,nper,pv,start,end,type)
        add("CUMPRINC", (r, n, pv, s, e, typ), "cumprinc_grid")
        add("CUMIPMT", (r, n, pv, s, e, typ), "cumipmt_grid")
    # full range 1..n
    add("CUMPRINC", (r, n, pv, 1, n, typ), "cumprinc_full")
    add("CUMIPMT", (r, n, pv, 1, n, typ), "cumipmt_full")

# ---- NPER confirmation --------------------------------------------
nper_grid = [
    (0.0008333333333333334, -100, 10000, 0, 0),   # P20
    (0.05/12, -1500, 200000, 0, 0),
    (0.08/12, -500, 25000, 0, 0),
    (0.10/12, -300, 8000, 0, 0),
    (0.03/4, -400, 5000, 0, 0),
    (0.065/12, -1200, 150000, 0, 1),
    (0.05/12, -1500, 200000, 10000, 0),
    (0.02, -900, 15000, 0, 0),
]
for g in nper_grid:
    add("NPER", g, "nper_grid")

out = os.path.join(SCR, "corpus.jsonl")
with open(out, "w") as f:
    for r in rows:
        f.write(json.dumps(r) + "\n")

from collections import Counter
c = Counter(r["fn"] for r in rows)
print("wrote", len(rows), "rows to", out)
print(dict(c))
