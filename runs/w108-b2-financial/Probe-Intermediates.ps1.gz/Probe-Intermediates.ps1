[CmdletBinding()]
param([string] $OutPath)
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoRoot = (Resolve-Path (Join-Path $here "..\..\..")).Path
Import-Module (Join-Path $repoRoot "smart-fuzzer\tools\CellRefBatch.psm1") -Force
if ([string]::IsNullOrWhiteSpace($OutPath)) { $OutPath = Join-Path $here "intermediates.jsonl" }

# We drive Excel directly with cell formulas to isolate PMT internals.
# For a set of (rate, nper, pv) we ask Excel:
#   pmt      = PMT(rate,nper,pv)
#   fvfac    = FV(rate,nper,0,-1,0)      == (1+rate)^nper   (Excel's own factor)
#   annterm  = FV(rate,nper,-1,0,0)      == ((1+rate)^nper - 1)/rate  (Excel annuity term, type0)
#   annterm1 = FV(rate,nper,-1,0,1)      == annuity term type1
#   pw       = POWER(1+rate,nper)
# All via Value2 cell refs for the numeric inputs.

$cases = @(
    ,@((0.05/12), 360, 200000)
    ,@((0.05/12), 180, 200000)
    ,@((0.08/12), 60, 25000)
    ,@((0.10/12), 36, 8000)
    ,@((0.03/4), 16, 5000)
    ,@((0.065/12), 240, 150000)
    ,@((0.0725/12), 360, 275000)
    ,@((0.045/12), 300, 180000)
    ,@((0.09/12), 84, 32000)
    ,@((0.055/12), 360, 200000)
)

$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false; $excel.DisplayAlerts = $false
$wb = $excel.Workbooks.Add(); $ws = $wb.Worksheets.Item(1)

if (Test-Path -LiteralPath $OutPath) { Remove-Item -LiteralPath $OutPath }
$results = @()
$row = 1
foreach ($c in $cases) {
    $r = [double]$c[0]; $n = [double]$c[1]; $pv = [double]$c[2]
    $ws.Range("A$row").Value2 = $r
    $ws.Range("B$row").Value2 = $n
    $ws.Range("C$row").Value2 = $pv
    $ws.Range("D$row").Formula2 = "=PMT(A$row,B$row,C$row)"
    $ws.Range("E$row").Formula2 = "=FV(A$row,B$row,0,-1,0)"       # (1+r)^n
    $ws.Range("F$row").Formula2 = "=FV(A$row,B$row,-1,0,0)"       # ((1+r)^n-1)/r type0
    $ws.Range("G$row").Formula2 = "=FV(A$row,B$row,-1,0,1)"       # type1 annuity term
    $ws.Range("H$row").Formula2 = "=POWER(1+A$row,B$row)"
    $ws.Range("I$row").Formula2 = "=(1+A$row)^B$row"
    $ws.Range("J$row").Formula2 = "=PV(A$row,B$row,-1,0,0)"       # annuity PV factor
    $row++
}
$ws.Calculate()

$row = 1
foreach ($c in $cases) {
    $rec = [ordered]@{
        rate = [double]$c[0]; nper = [double]$c[1]; pv = [double]$c[2]
        pmt_bits      = (Get-F64BitsHex ([double]$ws.Range("D$row").Value2))
        fvfac_bits    = (Get-F64BitsHex ([double]$ws.Range("E$row").Value2))
        annterm0_bits = (Get-F64BitsHex ([double]$ws.Range("F$row").Value2))
        annterm1_bits = (Get-F64BitsHex ([double]$ws.Range("G$row").Value2))
        power_bits    = (Get-F64BitsHex ([double]$ws.Range("H$row").Value2))
        caret_bits    = (Get-F64BitsHex ([double]$ws.Range("I$row").Value2))
        pvfac_bits    = (Get-F64BitsHex ([double]$ws.Range("J$row").Value2))
    }
    ($rec | ConvertTo-Json -Compress) | Add-Content -LiteralPath $OutPath -Encoding UTF8
    $row++
}

$wb.Close($false); $excel.Quit()
[System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($ws) | Out-Null
[System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($wb) | Out-Null
[System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel) | Out-Null
[System.GC]::Collect(); [System.GC]::WaitForPendingFinalizers()
Write-Host "Wrote intermediates to $OutPath"
