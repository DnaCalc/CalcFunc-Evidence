[CmdletBinding()]
param([string] $OutPath)
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoRoot = (Resolve-Path (Join-Path $here "..\..\..")).Path
Import-Module (Join-Path $repoRoot "smart-fuzzer\tools\CellRefBatch.psm1") -Force
if ([string]::IsNullOrWhiteSpace($OutPath)) { $OutPath = Join-Path $here "transcendentals.jsonl" }

# For each (rate, nper) probe Excel's LN(1+rate), rate stored exactly, and
# EXP(nper*LN(1+rate)) built entirely inside Excel cells, plus LN(1+rate)
# directly and the product. This reveals whether Excel's EXP/LN at these
# args equals UCRT.
$cases = @(
    ,@((0.05/12), 360)
    ,@((0.05/12), 180)
    ,@((0.08/12), 60)
    ,@((0.10/12), 36)
    ,@((0.065/12), 240)
    ,@((0.0725/12), 360)
    ,@((0.045/12), 300)
    ,@((0.055/12), 360)
    ,@((0.09/12), 84)
    ,@((0.04166666666666667/12), 12)
)

$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false; $excel.DisplayAlerts = $false
$wb = $excel.Workbooks.Add(); $ws = $wb.Worksheets.Item(1)
if (Test-Path -LiteralPath $OutPath) { Remove-Item -LiteralPath $OutPath }

$row = 1
foreach ($c in $cases) {
    $r = [double]$c[0]; $n = [double]$c[1]
    $ws.Range("A$row").Value2 = $r
    $ws.Range("B$row").Value2 = $n
    $ws.Range("C$row").Formula2 = "=LN(1+A$row)"            # ln(1+r)
    $ws.Range("D$row").Formula2 = "=B$row*LN(1+A$row)"      # n*ln(1+r)
    $ws.Range("E$row").Formula2 = "=EXP(B$row*LN(1+A$row))" # exp(n*ln(1+r))
    $ws.Range("F$row").Formula2 = "=EXP(D$row)"             # exp of stored product
    $ws.Range("G$row").Formula2 = "=LN(1+A$row)*B$row"      # ln(1+r)*n (order)
    $row++
}
$ws.Calculate()
$row = 1
foreach ($c in $cases) {
    $rec = [ordered]@{
        rate = [double]$c[0]; nper = [double]$c[1]
        ln1pr_bits   = (Get-F64BitsHex ([double]$ws.Range("C$row").Value2))
        n_ln_bits    = (Get-F64BitsHex ([double]$ws.Range("D$row").Value2))
        exp_nln_bits = (Get-F64BitsHex ([double]$ws.Range("E$row").Value2))
        exp_stored   = (Get-F64BitsHex ([double]$ws.Range("F$row").Value2))
        ln_n_bits    = (Get-F64BitsHex ([double]$ws.Range("G$row").Value2))
    }
    ($rec | ConvertTo-Json -Compress) | Add-Content -LiteralPath $OutPath -Encoding UTF8
    $row++
}
$wb.Close($false); $excel.Quit()
[System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($ws) | Out-Null
[System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($wb) | Out-Null
[System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel) | Out-Null
[System.GC]::Collect(); [System.GC]::WaitForPendingFinalizers()
Write-Host "Wrote transcendentals to $OutPath"
