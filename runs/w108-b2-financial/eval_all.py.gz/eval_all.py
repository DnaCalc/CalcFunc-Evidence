"""Evaluate best-known models for each function across the full corpus.
Records per-case match/ulp and summary. Uses CR log for NPER numerator."""
from fin import *
try:
    import mpmath; mpmath.mp.prec=200
    def cr_log(x): return float(mpmath.log(mpmath.mpf(x)))
    HAVE_MP=True
except Exception:
    cr_log=log; HAVE_MP=False

def fv_powi(rate,n,pmt,pv,typ):
    if n==0: return -pv
    if rate==0.0: return -(pv+pmt*n)
    F=factor_powi(rate,n); term=(F-1.0)/rate; tf=1.0+rate*typ
    return -(pv*F + pmt*tf*term)

def fv_exp(rate,m,pmt,pv,typ):
    if m==0: return -pv
    if rate==0.0: return -(pv+pmt*m)
    L=m*log1p(rate); F=exp(L); em=expm1(L); tf=1.0+rate*typ
    return -(pv*F + pmt*tf*(em/rate))

def pmt_model(rate,nper,pv,fv,typ):
    # PV-side stable discount form (winner, 22/39 realistic, minimal residual)
    if rate==0.0: return -(fv+pv)/nper
    negL=-nper*log1p(rate)
    invF=exp(negL)          # (1+r)^-n
    denom=-expm1(negL)      # 1 - (1+r)^-n  (stable, no cancellation)
    tf=1.0+rate*typ
    return -(pv+fv*invF)*rate*(1.0/(tf*denom))

def pmt_internal(rate,nper,pv,fv,typ):
    return pmt_model(rate,nper,pv,fv,typ)

def ipmt_model(rate,per,nper,pv,fv,typ):
    per=int(per)
    rpmt=pmt_internal(rate,nper,pv,fv,typ)
    if per==1:
        rip = 0.0 if typ>0 else -pv
    elif typ>0:
        rip = fv_exp(rate,per-2,rpmt,pv,1) - rpmt
    else:
        rip = fv_exp(rate,per-1,rpmt,pv,0)
    return rip*rate

def ppmt_model(rate,per,nper,pv,fv,typ):
    return pmt_internal(rate,nper,pv,fv,typ) - ipmt_model(rate,per,nper,pv,fv,typ)

def cumprinc_model(rate,nper,pv,start,end,typ):
    s=int(start); e=int(end); acc=0.0
    for k in range(s,e+1):
        acc += ppmt_model(rate,k,nper,pv,0.0,typ)
    return acc

def cumipmt_model(rate,nper,pv,start,end,typ):
    s=int(start); e=int(end); acc=0.0
    for k in range(s,e+1):
        acc += ipmt_model(rate,k,nper,pv,0.0,typ)
    return acc

def nper_model(rate,pmt,pv,fv,typ):
    if rate==0.0: return -(pv+fv)/pmt
    tf=1.0+rate*typ
    ratio=(tf*pmt - fv*rate)/(tf*pmt + pv*rate)
    return cr_log(ratio)/log(1.0+rate)

MODELS={'PMT':pmt_model,'IPMT':ipmt_model,'PPMT':ppmt_model,
        'CUMPRINC':cumprinc_model,'CUMIPMT':cumipmt_model,'NPER':nper_model}

rows=load_corpus()
summary={}
per_case={}
for fn,model in MODELS.items():
    frows=by_fn(rows,fn)
    matched=0; ubh={}; cases=[]
    for r in frows:
        exb=r['out_bits']
        try:
            got=model(*r['args']); gb=bits(got)
        except Exception as e:
            gb='ERR'
        m=(gb==exb)
        if m: matched+=1
        u=0 if m else (ulp(frombits(gb),frombits(exb)) if gb!='ERR' else -1)
        ubh[u]=ubh.get(u,0)+1
        cases.append({'id':r['id'],'args':r['args'],'model':gb,'excel':exb,'match':m,'ulp':u})
    summary[fn]={'matched':matched,'total':len(frows),'ulp_hist':dict(sorted(ubh.items()))}
    per_case[fn]=cases

print("=== SUMMARY ===")
for fn,s in summary.items():
    print(f"{fn}: {s['matched']}/{s['total']}  ulp_hist={s['ulp_hist']}")

import json
json.dump({'summary':summary,'per_case':per_case}, open('eval_results.json','w'), indent=1)
print("\nwrote eval_results.json")
