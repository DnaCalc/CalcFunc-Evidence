[CmdletBinding()]
param(
    [string] $CorpusPath,
    [string] $OutPath
)
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoRoot = (Resolve-Path (Join-Path $here "..\..\..")).Path
if ([string]::IsNullOrWhiteSpace($CorpusPath)) { $CorpusPath = Join-Path $here "corpus.jsonl" }
if ([string]::IsNullOrWhiteSpace($OutPath))    { $OutPath    = Join-Path $here "excel_out.jsonl" }

Import-Module (Join-Path $repoRoot "smart-fuzzer\tools\CellRefBatch.psm1") -Force

$rows = @()
foreach ($line in Get-Content -LiteralPath $CorpusPath) {
    if ([string]::IsNullOrWhiteSpace($line)) { continue }
    $rows += ($line | ConvertFrom-Json)
}

# Build candidates preserving order.
$candidates = @()
foreach ($r in $rows) {
    $candidates += @{ function_name = [string] $r.fn; args = @($r.args | ForEach-Object { [double] $_ }) }
}

Write-Host "Evaluating $($candidates.Count) candidates in Excel..."
$batch = Invoke-ExcelCellRefBatch -Candidates $candidates
if ($batch.blocked) {
    throw "Excel batch blocked: $($batch.blocker)"
}

if (Test-Path -LiteralPath $OutPath) { Remove-Item -LiteralPath $OutPath }
for ($i = 0; $i -lt $rows.Count; $i++) {
    $r = $rows[$i]
    $o = $batch.outcomes[$i]
    # Recompute exact input bits for each arg for the record.
    $argBits = @()
    foreach ($a in @($r.args)) {
        $argBits += (Get-F64BitsHex ([double] $a))
    }
    $rec = [ordered]@{
        id = [string] $r.id
        fn = [string] $r.fn
        args = @($r.args)
        arg_bits = @($argBits)
        kind = [string] $o.kind
    }
    if ($o.kind -eq "number") {
        $rec["out_bits"]  = [string] $o.bits_hex
        $rec["out_value"] = [double] $o.value
    } elseif ($o.kind -eq "error") {
        $rec["out_error"] = [string] $o.code
    } else {
        $rec["out_raw"] = [string] $o.value
    }
    ($rec | ConvertTo-Json -Compress -Depth 8) | Add-Content -LiteralPath $OutPath -Encoding UTF8
}

Write-Host "Environment: $($batch.environment | ConvertTo-Json -Compress)"
Write-Host "Wrote $($rows.Count) results to $OutPath"
