"""Build harness cases.jsonl from excel_out.jsonl for array_tranche_local_eval.

Each case: {case_id, function_id:"FUNC.<FN>", formula_text, args:[{kind:number,value}]}
Args are in Excel arg order (already how the corpus stores them).
"""
import json, os, sys

SCR = os.path.dirname(os.path.abspath(__file__))
FNMAP = {
    "PMT": "FUNC.PMT", "IPMT": "FUNC.IPMT", "PPMT": "FUNC.PPMT",
    "NPER": "FUNC.NPER", "CUMIPMT": "FUNC.CUMIPMT", "CUMPRINC": "FUNC.CUMPRINC",
    "FV": "FUNC.FV", "PV": "FUNC.PV", "POWER": "FUNC.POWER",
}

def main(src, dst):
    rows = [json.loads(l) for l in open(os.path.join(SCR, src)) if l.strip()]
    with open(os.path.join(SCR, dst), "w") as f:
        for r in rows:
            fn = r["fn"]
            case = {
                "case_id": r["id"],
                "function_id": FNMAP[fn],
                "formula_text": f"={fn}(...)",
                "args": [{"kind": "number", "value": a} for a in r["args"]],
            }
            f.write(json.dumps(case) + "\n")
    print(f"wrote {len(rows)} cases to {dst}")

if __name__ == "__main__":
    src = sys.argv[1] if len(sys.argv) > 1 else "excel_out.jsonl"
    dst = sys.argv[2] if len(sys.argv) > 2 else "harness_cases.jsonl"
    main(src, dst)
