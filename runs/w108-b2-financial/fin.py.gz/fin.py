"""W108-B2 financial composition search harness. Pure f64 (Python float=IEEE754 double,
UCRT libm on Windows CPython == Excel per established facts)."""
import struct, math, json, os

SCR = os.path.dirname(os.path.abspath(__file__))

def bits(x):
    return '0x' + struct.pack('>d', float(x)).hex()

def frombits(s):
    if isinstance(s, str):
        s = int(s, 16)
    return struct.unpack('>d', struct.pack('>Q', s))[0]

def ord_int(x):
    b = struct.unpack('>Q', struct.pack('>d', float(x)))[0]
    return -(b & 0x7FFFFFFFFFFFFFFF) if (b & 0x8000000000000000) else b

def ulp(a, b):
    return abs(ord_int(a) - ord_int(b))

# --- libm (UCRT) ---
exp, log, log1p, expm1, powf = math.exp, math.log, math.log1p, math.expm1, math.pow

def powi(base, n):
    """Excel integer power by binary exponentiation, pure f64."""
    r = 1.0; b = base; e = int(n)
    while e > 0:
        if e & 1: r = r * b
        e >>= 1
        if e > 0: b = b * b
    return r

def factor_powi(r, n):
    base = 1.0 + r
    ni = int(n)
    if float(ni) == n:
        return powi(base, ni)
    return powf(base, n)

def load_corpus():
    rows = [json.loads(l) for l in open(os.path.join(SCR, 'excel_out.jsonl'))]
    return rows

def by_fn(rows, fn):
    return [r for r in rows if r['fn'] == fn]

if __name__ == '__main__':
    rows = load_corpus()
    from collections import Counter
    print(dict(Counter(r['fn'] for r in rows)))
