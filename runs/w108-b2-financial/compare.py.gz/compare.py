"""Compare harness out.jsonl (local OxFunc) bits vs excel_out.jsonl bits.
Reports per-function: exact %, <=1 ULP %, <=2 ULP %, max ULP, and a residual tail list.
"""
import json, os, struct, sys, collections

SCR = os.path.dirname(os.path.abspath(__file__))

def frombits(s):
    if isinstance(s, str): s = int(s, 16)
    return struct.unpack('>d', struct.pack('>Q', s))[0]
def ord_int(x):
    b = struct.unpack('>Q', struct.pack('>d', float(x)))[0]
    return -(b & 0x7FFFFFFFFFFFFFFF) if (b & 0x8000000000000000) else b
def ulp(a_bits, b_bits):
    return abs(ord_int(frombits(a_bits)) - ord_int(frombits(b_bits)))

def main(out_file):
    excel = {r["id"]: r for r in (json.loads(l) for l in open(os.path.join(SCR, "excel_out.jsonl")) if l.strip())}
    local = {}
    for l in open(os.path.join(SCR, out_file)):
        if not l.strip(): continue
        r = json.loads(l)
        local[r["case_id"]] = r

    byfn = collections.defaultdict(list)
    for cid, er in excel.items():
        fn = er["fn"]
        lr = local.get(cid)
        exb = er["out_bits"]
        if lr is None:
            byfn[fn].append((cid, exb, "MISSING", -1)); continue
        oc = lr["outcome"]
        if oc.get("kind") != "number":
            byfn[fn].append((cid, exb, "NON_NUMBER:" + json.dumps(oc)[:60], -1)); continue
        gb = oc["bits_hex"]
        u = ulp(gb, exb)
        byfn[fn].append((cid, exb, gb, u))

    print(f"{'FN':<10} {'n':>4} {'exact':>7} {'<=1':>7} {'<=2':>7} {'<=3':>7} {'maxULP':>10}  ulp_hist")
    grand = collections.Counter()
    for fn in sorted(byfn):
        rows = byfn[fn]
        n = len(rows)
        us = [u for _,_,_,u in rows]
        valid = [u for u in us if u >= 0]
        exact = sum(1 for u in us if u == 0)
        le1 = sum(1 for u in us if 0 <= u <= 1)
        le2 = sum(1 for u in us if 0 <= u <= 2)
        le3 = sum(1 for u in us if 0 <= u <= 3)
        mx = max(valid) if valid else -1
        hist = collections.Counter(us)
        for k,v in hist.items(): grand[k]+=v
        hs = " ".join(f"{k}:{v}" for k,v in sorted(hist.items()))
        print(f"{fn:<10} {n:>4} {exact:>3}/{n:<3} {le1:>3}/{n:<3} {le2:>3}/{n:<3} {le3:>3}/{n:<3} {mx:>10}  {hs}")
    total = sum(grand.values())
    ex = grand.get(0,0)
    le1 = sum(v for k,v in grand.items() if 0<=k<=1)
    le2 = sum(v for k,v in grand.items() if 0<=k<=2)
    le3 = sum(v for k,v in grand.items() if 0<=k<=3)
    mx = max(k for k in grand if k>=0)
    print(f"{'ALL':<10} {total:>4} {ex:>3}/{total:<3} {le1:>3}/{total:<3} {le2:>3}/{total:<3} {le3:>3}/{total:<3} {mx:>10}")

    # residual tail (ulp > 3 or non-number)
    print("\n=== residual tail (ulp>3 or non-number) ===")
    for fn in sorted(byfn):
        for cid, exb, gb, u in byfn[fn]:
            if u > 3 or u < 0:
                print(f"  {cid:<14} {fn:<9} excel={exb} local={gb} ulp={u}")

if __name__ == "__main__":
    out_file = sys.argv[1] if len(sys.argv) > 1 else "harness_out.jsonl"
    main(out_file)
