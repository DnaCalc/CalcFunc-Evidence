"""Determine EXACTLY how Excel's financial (1+r)^n factor is computed, using the
855-row factor_isolation_grid ground truth."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fin import bits, frombits, ulp, powi, powf, exp, log, log1p, expm1, factor_powi

GRID = json.load(open(r"C:\Users\GOVERT~1\AppData\Local\Temp\claude\C--Work-DnaCalc-OxFunc\87ad2a27-b42e-48bb-9404-39e6b7d02cd9\scratchpad\excel_probe_results.json"))["factor_isolation_grid"]

def F_powi(r, n):        return powi(1.0 + r, int(n)) if float(int(n))==n else powf(1.0+r, n)
def F_powf(r, n):        return powf(1.0 + r, n)
def F_exp_log1p(r, n):   return exp(n * log1p(r))
def F_exp_lnp(r, n):     return exp(n * log(1.0 + r))
def F_1p_em(r, n):       return 1.0 + expm1(n * log1p(r))

models = {
    'powi': F_powi, 'powf': F_powf, 'exp_log1p': F_exp_log1p,
    'exp_lnp': F_exp_lnp, '1p_expm1_log1p': F_1p_em,
}
score = {k: [0,0,[]] for k in models}  # matched, total, fails
for g in GRID:
    if g['kind'] != 'number':
        continue
    r = g['r_value']; n = g['n']; exb = g['excel_factor_bits']
    for k, f in models.items():
        try:
            gb = bits(f(r, n)); m = (gb == exb)
        except Exception:
            gb = 'ERR'; m = False
        score[k][1] += 1
        if m: score[k][0] += 1
        elif len(score[k][2]) < 6:
            u = ulp(frombits(gb), frombits(exb)) if gb!='ERR' else '-'
            score[k][2].append((g['r_decimal'], n, gb, exb, u))

for k in sorted(score, key=lambda k:-score[k][0]):
    matched, total, fails = score[k]
    print(f"{k}: {matched}/{total}")
    for f in fails[:4]:
        print("    ", f)
