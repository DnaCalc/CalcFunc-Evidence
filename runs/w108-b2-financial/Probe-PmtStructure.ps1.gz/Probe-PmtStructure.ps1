[CmdletBinding()]
param([string] $OutPath)
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoRoot = (Resolve-Path (Join-Path $here "..\..\..")).Path
Import-Module (Join-Path $repoRoot "smart-fuzzer\tools\CellRefBatch.psm1") -Force
if ([string]::IsNullOrWhiteSpace($OutPath)) { $OutPath = Join-Path $here "pmt_structure.jsonl" }

# For each (rate,nper,pv): compute PMT and several in-sheet reconstructions
# to identify Excel's exact PMT tree. All intermediates use Excel's own ops.
$cases = @(
    ,@((0.05/12), 360, 200000)
    ,@((0.05/12), 180, 200000)
    ,@((0.08/12), 60, 25000)
    ,@((0.10/12), 36, 8000)
    ,@((0.065/12), 240, 150000)
    ,@((0.055/12), 360, 200000)
    ,@((0.045/12), 300, 180000)
    ,@((0.09/12), 84, 32000)
)
$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false; $excel.DisplayAlerts = $false
$wb = $excel.Workbooks.Add(); $ws = $wb.Worksheets.Item(1)
if (Test-Path -LiteralPath $OutPath) { Remove-Item -LiteralPath $OutPath }
$row = 1
foreach ($c in $cases) {
    $r=[double]$c[0]; $n=[double]$c[1]; $pv=[double]$c[2]
    $ws.Range("A$row").Value2=$r; $ws.Range("B$row").Value2=$n; $ws.Range("C$row").Value2=$pv
    $ws.Range("D$row").Formula2="=PMT(A$row,B$row,C$row)"
    # E = POWER(1+r,n)
    $ws.Range("E$row").Formula2="=POWER(1+A$row,B$row)"
    # F = div-grouped with POWER: -(pv*E)/((E-1)/r)
    $ws.Range("F$row").Formula2="=-(C$row*E$row)/((E$row-1)/A$row)"
    # G = classic distributed: -(pv*E)*r/(E-1)
    $ws.Range("G$row").Formula2="=-(C$row*E$row)*A$row/(E$row-1)"
    # H = -pv/PV-factor: -pv / ((1-1/E)/r)
    $ws.Range("H$row").Formula2="=-C$row/((1-1/E$row)/A$row)"
    # I = -pv*r/(1-1/E)
    $ws.Range("I$row").Formula2="=-C$row*A$row/(1-1/E$row)"
    # J = EXP(n*LN(1+r)) factor then div-grouped
    $ws.Range("J$row").Formula2="=-(C$row*EXP(B$row*LN(1+A$row)))/((EXP(B$row*LN(1+A$row))-1)/A$row)"
    $row++
}
$ws.Calculate()
$row=1
foreach ($c in $cases) {
    $rec=[ordered]@{
        rate=[double]$c[0]; nper=[double]$c[1]; pv=[double]$c[2]
        pmt=(Get-F64BitsHex ([double]$ws.Range("D$row").Value2))
        power=(Get-F64BitsHex ([double]$ws.Range("E$row").Value2))
        divgrp_power=(Get-F64BitsHex ([double]$ws.Range("F$row").Value2))
        classic_power=(Get-F64BitsHex ([double]$ws.Range("G$row").Value2))
        pvfac_power=(Get-F64BitsHex ([double]$ws.Range("H$row").Value2))
        pvfac2_power=(Get-F64BitsHex ([double]$ws.Range("I$row").Value2))
        divgrp_expln=(Get-F64BitsHex ([double]$ws.Range("J$row").Value2))
    }
    ($rec|ConvertTo-Json -Compress)|Add-Content -LiteralPath $OutPath -Encoding UTF8
    $row++
}
$wb.Close($false); $excel.Quit()
[System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($ws)|Out-Null
[System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($wb)|Out-Null
[System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)|Out-Null
[System.GC]::Collect(); [System.GC]::WaitForPendingFinalizers()
Write-Host "Wrote pmt_structure to $OutPath"
