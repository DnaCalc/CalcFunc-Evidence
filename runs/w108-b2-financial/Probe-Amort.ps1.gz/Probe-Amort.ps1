[CmdletBinding()]
param([string] $OutPath)
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoRoot = (Resolve-Path (Join-Path $here "..\..\..")).Path
Import-Module (Join-Path $repoRoot "smart-fuzzer\tools\CellRefBatch.psm1") -Force
if ([string]::IsNullOrWhiteSpace($OutPath)) { $OutPath = Join-Path $here "amort.jsonl" }

# For (r,n,pv) and several per, get Excel PMT, IPMT, PPMT, and CUMPRINC(per,per),
# CUMIPMT(per,per). Reveals: does PPMT+IPMT=PMT? does CUMPRINC(k,k)=PPMT(k)? does
# CUMIPMT(k,k)=IPMT(k)? And relationship of single-period CUM to per-period.
$bases = @(
    ,@((0.05/12), 360, 200000)
    ,@((0.08/12), 60, 25000)
    ,@((0.10/12), 36, 8000)
)
$pers = @(1,2,3,5,12,60)
$excel = New-Object -ComObject Excel.Application
$excel.Visible=$false; $excel.DisplayAlerts=$false
$wb=$excel.Workbooks.Add(); $ws=$wb.Worksheets.Item(1)
if (Test-Path -LiteralPath $OutPath) { Remove-Item -LiteralPath $OutPath }
$row=1
$meta=@()
foreach ($b in $bases) {
    $r=[double]$b[0]; $n=[double]$b[1]; $pv=[double]$b[2]
    foreach ($per in $pers) {
        if ($per -gt $n) { continue }
        $ws.Range("A$row").Value2=$r
        $ws.Range("B$row").Value2=$n
        $ws.Range("C$row").Value2=$pv
        $ws.Range("D$row").Value2=[double]$per
        $ws.Range("E$row").Formula2="=PMT(A$row,B$row,C$row)"
        $ws.Range("F$row").Formula2="=IPMT(A$row,D$row,B$row,C$row)"
        $ws.Range("G$row").Formula2="=PPMT(A$row,D$row,B$row,C$row)"
        $ws.Range("H$row").Formula2="=CUMPRINC(A$row,B$row,C$row,D$row,D$row,0)"
        $ws.Range("I$row").Formula2="=CUMIPMT(A$row,B$row,C$row,D$row,D$row,0)"
        $meta += ,@($r,$n,$pv,$per,$row)
        $row++
    }
}
$ws.Calculate()
foreach ($m in $meta) {
    $rr=$m[4]
    $rec=[ordered]@{
        rate=[double]$m[0]; nper=[double]$m[1]; pv=[double]$m[2]; per=[int]$m[3]
        pmt=(Get-F64BitsHex ([double]$ws.Range("E$rr").Value2))
        ipmt=(Get-F64BitsHex ([double]$ws.Range("F$rr").Value2))
        ppmt=(Get-F64BitsHex ([double]$ws.Range("G$rr").Value2))
        cumprinc=(Get-F64BitsHex ([double]$ws.Range("H$rr").Value2))
        cumipmt=(Get-F64BitsHex ([double]$ws.Range("I$rr").Value2))
    }
    ($rec|ConvertTo-Json -Compress)|Add-Content -LiteralPath $OutPath -Encoding UTF8
}
$wb.Close($false); $excel.Quit()
[System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($ws)|Out-Null
[System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($wb)|Out-Null
[System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)|Out-Null
[System.GC]::Collect(); [System.GC]::WaitForPendingFinalizers()
Write-Host "Wrote amort to $OutPath"
