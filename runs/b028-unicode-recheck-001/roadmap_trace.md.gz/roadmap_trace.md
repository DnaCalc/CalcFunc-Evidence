# Array Support Roadmap Trace

- Run ID: b028-unicode-recheck-001
- Tranche: b028-arraylift-state-v0
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 45
- Formula cases executed: 270

## Axes touched

- Function family/category: Date and time functions, Engineering functions, Financial functions, Information functions, Logical functions, Math and trigonometry functions, Statistical functions, Text functions.
- Array argument axes: unswept_structural_probe.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 209
- unexpected_mismatch: 61
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.ARABIC: exact_typed_bit_match=6
- FUNC.ARRAYTOTEXT: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.ASC: unexpected_mismatch=5, exact_typed_bit_match=1
- FUNC.BIN2OCT: exact_typed_bit_match=4, unexpected_mismatch=2
- FUNC.CLEAN: exact_typed_bit_match=6
- FUNC.DATEVALUE: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.DBCS: unexpected_mismatch=5, exact_typed_bit_match=1
- FUNC.DECIMAL: exact_typed_bit_match=6
- FUNC.DELTA: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.DOLLAR: exact_typed_bit_match=2, unexpected_mismatch=4
- FUNC.DOLLARDE: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.EOMONTH: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.FACTDOUBLE: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.FIXED: exact_typed_bit_match=2, unexpected_mismatch=4
- FUNC.GCD: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.GESTEP: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.ISERR: exact_typed_bit_match=6
- FUNC.ISEVEN: exact_typed_bit_match=6
- FUNC.ISLOGICAL: exact_typed_bit_match=6
- FUNC.ISNONTEXT: exact_typed_bit_match=6
- FUNC.ISODD: exact_typed_bit_match=6
- FUNC.ISOWEEKNUM: exact_typed_bit_match=6
- FUNC.ISTEXT: exact_typed_bit_match=6
- FUNC.LCM: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.LOG: unexpected_mismatch=3, exact_typed_bit_match=3
- FUNC.MULTINOMIAL: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.NETWORKDAYS: exact_typed_bit_match=4, unexpected_mismatch=2
- FUNC.NOT: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.NUMBERVALUE: exact_typed_bit_match=3, unexpected_mismatch=3
- FUNC.OCT2DEC: exact_typed_bit_match=4, unexpected_mismatch=2
- FUNC.QUOTIENT: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.ROMAN: exact_typed_bit_match=6
- FUNC.SQRTPI: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.STANDARDIZE: exact_typed_bit_match=6
- FUNC.TBILLEQ: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.TBILLPRICE: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.TBILLYIELD: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.TEXT: unexpected_mismatch=6
- FUNC.TIMEVALUE: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.UNICODE: exact_typed_bit_match=6
- FUNC.VALUE: exact_typed_bit_match=3, unexpected_mismatch=3
- FUNC.WEEKDAY: exact_typed_bit_match=6
- FUNC.WEEKNUM: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.WORKDAY: exact_typed_bit_match=4, unexpected_mismatch=2
- FUNC.YEARFRAC: exact_typed_bit_match=4, unexpected_mismatch=2

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
