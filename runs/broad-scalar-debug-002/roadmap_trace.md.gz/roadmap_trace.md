# Broad Scalar Explorer Trace

- Generated/evaluated locally: `50000`
- Excel candidate samples selected: `16`
- Distinct coverage areas: `6732`
- Local throughput: `100550.59` cases/sec
