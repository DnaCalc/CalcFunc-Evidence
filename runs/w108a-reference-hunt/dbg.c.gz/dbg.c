#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
int main(void){
  FILE *f=fopen("probe_in.txt","r");
  char func[16], xhex[64], ehex[64]; int idx;
  for(int n=0;n<3;n++){
    int got=fscanf(f,"%d %15s %63s %63s",&idx,func,xhex,ehex);
    unsigned long long xb=strtoull(xhex,NULL,16);
    printf("got=%d idx=%d func=%s xhex=[%s] xb=0x%016llx ehex=[%s]\n",got,idx,func,xhex,xb,ehex);
  }
  fclose(f); return 0;
}
