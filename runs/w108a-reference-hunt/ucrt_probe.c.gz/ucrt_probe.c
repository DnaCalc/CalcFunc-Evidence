#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
static uint64_t d2b(double x){uint64_t b;memcpy(&b,&x,8);return b;}
static double b2d(uint64_t b){double x;memcpy(&x,&b,8);return x;}
int main(void){
  FILE*f=fopen("probe_in.txt","r");
  char fn[16],xh[64],eh[64]; int idx;
  while(fscanf(f,"%d %15s %63s %63s",&idx,fn,xh,eh)==4){
    double x=b2d((uint64_t)strtoull(xh,NULL,16)); double r;
    if(!strcmp(fn,"EXP")) r=exp(x);
    else if(!strcmp(fn,"LN")) r=log(x);
    else if(!strcmp(fn,"SQRT")) r=sqrt(x);
    else continue;
    printf("%d %s %s 0x%016llx %s\n",idx,fn,xh,(unsigned long long)d2b(r),eh);
  }
  return 0;
}
