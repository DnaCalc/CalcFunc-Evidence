#include <stdio.h>
#include <stdint.h>
#include <string.h>
int main(void){
    double x = 1.5;
    uint64_t b;
    memcpy(&b, &x, 8);
    printf("bits=%016llx\n", (unsigned long long)b);
    return 0;
}
