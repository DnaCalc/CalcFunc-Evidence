import ctypes, os, json, struct

bindir=os.path.abspath('mkl_dl/mkl_extracted/mkl-2026.1.0.data/data/Library/bin')
# Force sequential threading (no libiomp5md needed) BEFORE loading rt
os.environ['MKL_THREADING_LAYER']='SEQUENTIAL'
os.environ['MKL_NUM_THREADS']='1'
os.add_dll_directory(bindir)
os.environ['PATH']=bindir+os.pathsep+os.environ['PATH']

# Preload dependency chain explicitly with WINMODE that searches the dir
def load(name):
    return ctypes.CDLL(os.path.join(bindir,name), winmode=0)

for dep in ['mkl_core.3.dll','mkl_sequential.3.dll','mkl_def.3.dll',
            'mkl_avx2.3.dll','mkl_vml_def.3.dll','mkl_vml_avx2.3.dll']:
    try:
        load(dep); 
    except Exception as e:
        print("warn preloading",dep,":",e)

mkl=load('mkl_rt.3.dll')
# Force sequential + single thread via API too
try:
    mkl.MKL_Set_Threading_Layer(1)  # 1 = SEQUENTIAL in some versions
except Exception: pass
try:
    mkl.mkl_set_num_threads_local(ctypes.c_int(1))
except Exception: pass

ver=ctypes.create_string_buffer(256)
mkl.MKL_Get_Version_String(ver, 256)
print("MKL:", ver.value.decode().strip())

VML_HA=0x00000001; VML_LA=0x00000002; VML_EP=0x00000003
mkl.vmdExp.argtypes=[ctypes.c_longlong, ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double), ctypes.c_longlong]
mkl.vmdLn.argtypes =[ctypes.c_longlong, ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double), ctypes.c_longlong]
mkl.vmdExp.restype=None; mkl.vmdLn.restype=None

def bits_to_d(b): return struct.unpack('<d', struct.pack('<Q', b))[0]
def d_to_bits(x): return struct.unpack('<Q', struct.pack('<d', x))[0]

# Quick smoke: exp(1)=e
inp=(ctypes.c_double*1)(1.0); out=(ctypes.c_double*1)()
mkl.vmdExp(1, inp, out, VML_HA)
print("smoke vmdExp(1.0)=", out[0], "hex", hex(d_to_bits(out[0])), "(e=2.718281828...)")

corpus=[json.loads(l) for l in open('C:/Work/DnaCalc/OxFunc/smart-fuzzer/runs/w108a-elementary-cr-vs-svml/corpus.jsonl')]

def run_vml(func, xs, mode):
    n=len(xs)
    inp=(ctypes.c_double*n)(*xs); out=(ctypes.c_double*n)()
    (mkl.vmdExp if func=='EXP' else mkl.vmdLn)(n, inp, out, mode)
    return [d_to_bits(out[i]) for i in range(n)]

results={}
for mode_name, mode in [('HA',VML_HA),('LA',VML_LA),('EP',VML_EP)]:
    res={}
    for fn in ['EXP','LN']:
        idxs=[i for i,r in enumerate(corpus) if r['function']==fn]
        xs=[bits_to_d(int(corpus[i]['x_bits'],16)) for i in idxs]
        outs=run_vml(fn, xs, mode)
        for i,o in zip(idxs, outs): res[i]=o
    results[mode_name]=res

with open('vml_out.json','w') as f:
    json.dump({k:{str(i):v for i,v in d.items()} for k,d in results.items()}, f)

dev=json.load(open('C:/Work/DnaCalc/OxFunc/smart-fuzzer/runs/w108a-elementary-cr-vs-svml/deviations_excel_vs_cr.json'))
ne=dev['excel_ne_cr']
key2idx={(r['function'], r['x_bits'].lower()):i for i,r in enumerate(corpus)}

for mode_name in ['HA','LA','EP']:
    res=results[mode_name]
    print(f"\n===== VML {mode_name} =====")
    for fn in ['EXP','LN']:
        idxs=[i for i,r in enumerate(corpus) if r['function']==fn]
        eq=sum(1 for i in idxs if res[i]==int(corpus[i]['excel_bits'],16))
        print(f"  {fn}: n={len(idxs)} ==Excel {eq} ({100*eq/len(idxs):.3f}%)")
    for fn,s in [('EXP','exp_hard_to_round'),('LN','ln_hard_to_round')]:
        idxs=[i for i,r in enumerate(corpus) if r['set']==s]
        eq=sum(1 for i in idxs if res[i]==int(corpus[i]['excel_bits'],16))
        print(f"  {s}: n={len(idxs)} ==Excel {eq} ({100*eq/len(idxs):.3f}%)")
    m=0; ml=[]
    for r in ne:
        i=key2idx[(r['function'], r['x_bits'].lower())]
        if res[i]==int(r['excel_bits'],16): m+=1; ml.append((r['function'],round(r['x'],3)))
    print(f"  >>> 36 discriminators matched: {m}/36")
    if 0<m: print("      matched:", ml)
