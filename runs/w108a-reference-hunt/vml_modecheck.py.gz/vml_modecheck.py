import ctypes, os, struct
bindir=os.path.abspath('mkl_dl/mkl_extracted/mkl-2026.1.0.data/data/Library/bin')
os.environ['MKL_THREADING_LAYER']='SEQUENTIAL'; os.environ['MKL_NUM_THREADS']='1'
os.add_dll_directory(bindir); os.environ['PATH']=bindir+os.pathsep+os.environ['PATH']
def load(n): return ctypes.CDLL(os.path.join(bindir,n), winmode=0)
for d in ['mkl_core.3.dll','mkl_sequential.3.dll','mkl_def.3.dll','mkl_avx2.3.dll','mkl_vml_def.3.dll','mkl_vml_avx2.3.dll']:
    try: load(d)
    except Exception as e: print('warn',d,e)
mkl=load('mkl_rt.3.dll')

def d2b(x): return struct.unpack('<Q',struct.pack('<d',x))[0]
def b2d(b): return struct.unpack('<d',struct.pack('<Q',b))[0]

for f in ['vmdExp','vmdLn','vmlSetMode','vmlGetMode']:
    getattr(mkl,f).restype = None if f.startswith('vmd') else ctypes.c_uint
mkl.vmlSetMode.argtypes=[ctypes.c_uint]; mkl.vmlSetMode.restype=ctypes.c_uint
mkl.vmlGetMode.restype=ctypes.c_uint
mkl.vmdExp.argtypes=[ctypes.c_longlong,ctypes.POINTER(ctypes.c_double),ctypes.POINTER(ctypes.c_double),ctypes.c_longlong]

# VML accuracy bits
VML_HA=0x1; VML_LA=0x2; VML_EP=0x3
# Also force computation library variants via mode high bits? Show current mode
print("default mode: 0x%x"%mkl.vmlGetMode())

# Test one of the UNMATCHED deviations under each global mode + per-call
x=b2d(0x41933b5948becb3a)  # x=18.2058..., excel=...cb3a, cr=...cb39
print("test x=18.20580474934059, excel=0x41933b5948becb3a cr=0x41933b5948becb39")
for name,mode in [('HA',VML_HA),('LA',VML_LA),('EP',VML_EP)]:
    mkl.vmlSetMode(mode)
    inp=(ctypes.c_double*1)(x); out=(ctypes.c_double*1)()
    mkl.vmdExp(1,inp,out,mode)
    print(f"  global+call {name}: 0x{d2b(out[0]):016x}")

# Force scalar def kernel by setting VML_DEF path via mode bit 0x00100000? Try each vml backend directly.
print("\n--- direct backend DLLs ---")
for bk in ['mkl_vml_def.3.dll','mkl_vml_avx2.3.dll','mkl_vml_avx512.3.dll','mkl_vml_mc3.3.dll']:
    try:
        h=load(bk)
        # exported name inside backend: vmdExp variants may differ; try
        got=hasattr(h,'vmdExp')
        print(bk,"has vmdExp:",got)
    except Exception as e:
        print(bk,"load err",e)
