# Stat Distribution Explorer Trace

- Generated/evaluated locally: `10000`
- Excel candidate samples selected: `100`
- Distinct coverage areas: `1741`
- Local throughput: `122974.15` cases/sec
