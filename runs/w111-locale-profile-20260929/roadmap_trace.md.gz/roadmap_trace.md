# Array Support Roadmap Trace

- Run ID: w111-locale-profile-20260929
- Tranche: w111-locale-profile-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 9
- Formula cases executed: 358

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: array_lift, typed_argument.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- unexpected_mismatch: 296
- exact_typed_bit_match: 62
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.DATEVALUE: unexpected_mismatch=15, exact_typed_bit_match=17
- FUNC.TIMEVALUE: exact_typed_bit_match=19, unexpected_mismatch=9
- FUNC.VALUE: unexpected_mismatch=17, exact_typed_bit_match=14
- FUNC.DOLLAR: unexpected_mismatch=65, exact_typed_bit_match=2
- FUNC.FIXED: unexpected_mismatch=72, exact_typed_bit_match=3
- FUNC.TEXT: unexpected_mismatch=65, exact_typed_bit_match=3
- FUNC.ASC: unexpected_mismatch=17, exact_typed_bit_match=2
- FUNC.DBCS: unexpected_mismatch=17, exact_typed_bit_match=2
- FUNC.JIS: unexpected_mismatch=19

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
