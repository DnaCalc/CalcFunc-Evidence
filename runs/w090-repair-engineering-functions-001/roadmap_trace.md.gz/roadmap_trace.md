﻿# Array Support Roadmap Trace

- Run ID: w090-repair-engineering-functions-001
- Tranche: w090-successor-engineering-functions
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance.
- Surfaces executed: 26
- Formula cases executed: 32

## Axes touched

- Function family/category: Engineering functions.
- Risk bands: high.
- Array argument axes: one_array_arg:arg1, one_array_arg:arg2.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.
- Scenario seed sources: docs\function-lane\W60_SCENARIO_MANIFEST_SEED.csv.

## Rollup

- exact_typed_bit_match: 13
- unexpected_mismatch: 19

## Function highlights

- FUNC.COMPLEX: exact_typed_bit_match=2
- FUNC.IMABS: exact_typed_bit_match=1
- FUNC.IMAGINARY: exact_typed_bit_match=1
- FUNC.IMARGUMENT: exact_typed_bit_match=1
- FUNC.IMCONJUGATE: exact_typed_bit_match=1
- FUNC.IMCOS: unexpected_mismatch=1
- FUNC.IMCOSH: unexpected_mismatch=1
- FUNC.IMCOT: unexpected_mismatch=1
- FUNC.IMCSC: unexpected_mismatch=1
- FUNC.IMCSCH: exact_typed_bit_match=1
- FUNC.IMDIV: unexpected_mismatch=2
- FUNC.IMEXP: unexpected_mismatch=1
- FUNC.IMLN: unexpected_mismatch=1
- FUNC.IMLOG10: unexpected_mismatch=1
- FUNC.IMLOG2: unexpected_mismatch=1
- FUNC.IMPOWER: exact_typed_bit_match=2
- FUNC.IMPRODUCT: unexpected_mismatch=2
- FUNC.IMREAL: exact_typed_bit_match=1
- FUNC.IMSEC: unexpected_mismatch=1
- FUNC.IMSECH: unexpected_mismatch=1
- FUNC.IMSIN: unexpected_mismatch=1
- FUNC.IMSINH: unexpected_mismatch=1
- FUNC.IMSQRT: exact_typed_bit_match=1
- FUNC.IMSUB: exact_typed_bit_match=2
- FUNC.IMSUM: unexpected_mismatch=2
- FUNC.IMTAN: unexpected_mismatch=1

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
