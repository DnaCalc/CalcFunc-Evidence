# Expanded Finance Exploration Trace

Status: `generated_local_pending_or_with_excel_sample`

## Areas Explored

1. Functions: `PMT`, `PPMT`, `IPMT`.
2. Arities: PMT `3`/`5`, PPMT/IPMT `4`/`6`.
3. Rates: zero, tiny positive, ordinary monthly/quarterly, negative small, large positive, known witness neighborhood.
4. Horizons: short, medium, mortgage-like, long, very long.
5. Amounts: zero/small/ordinary/large/huge PV with both signs, zero and nonzero FV.
6. Timing and period lanes: end/beginning timing, invalid periods, first/middle/last/interior periods.

## Local Summary

- Generated/evaluated locally: `10000`
- Excel candidate samples selected: `16`
- Local throughput: `130502.98` cases/sec
- Known PMT/PPMT/IPMT non-zero-rate exactness drift is treated as expected reference behavior for this run.
