# Array Support Roadmap Trace

- Run ID: w111-radix-typed-heldout-20260929-002
- Tranche: w111-radix-heldout-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 13
- Formula cases executed: 1950

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: typed_argument.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 1950
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.BIN2DEC: exact_typed_bit_match=150
- FUNC.BIN2HEX: exact_typed_bit_match=150
- FUNC.BIN2OCT: exact_typed_bit_match=150
- FUNC.OCT2DEC: exact_typed_bit_match=150
- FUNC.OCT2BIN: exact_typed_bit_match=150
- FUNC.OCT2HEX: exact_typed_bit_match=150
- FUNC.HEX2DEC: exact_typed_bit_match=150
- FUNC.HEX2BIN: exact_typed_bit_match=150
- FUNC.HEX2OCT: exact_typed_bit_match=150
- FUNC.DEC2BIN: exact_typed_bit_match=150
- FUNC.DEC2HEX: exact_typed_bit_match=150
- FUNC.DEC2OCT: exact_typed_bit_match=150
- FUNC.BASE: exact_typed_bit_match=150

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
