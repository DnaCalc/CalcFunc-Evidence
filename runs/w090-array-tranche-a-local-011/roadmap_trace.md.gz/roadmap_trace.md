﻿# W090 Array Support Tranche A Roadmap Trace

- Run ID: w090-array-tranche-a-local-011
- Tranche: w090-tranche-a-math-scalar-numeric-array-lift
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance.
- Surfaces executed: 14
- Formula cases executed: 34

## Axes touched

- Function family: first non-text successor tranche after W080, focused on scalar numeric math surfaces with array-lift risk.
- Array position: first argument, later numeric parameter, optional parameter, and same-shape two-array argument cases.
- Shape: horizontal 1x2 vectors and vertical 2x1 vectors.
- Result kind: numeric arrays, text arrays from BASE, and per-cell error propagation from ATAN2 zero-vector cells.
- Optionality: omitted numeric optionals for TRUNC, CEILING.MATH/PRECISE, FLOOR.MATH/PRECISE, and ISO.CEILING.

## Rollup

- exact_typed_bit_match: 34

## Function highlights

- FUNC.ROUND: exact_typed_bit_match=3
- FUNC.ROUNDDOWN: exact_typed_bit_match=2
- FUNC.ROUNDUP: exact_typed_bit_match=2
- FUNC.TRUNC: exact_typed_bit_match=3
- FUNC.CEILING: exact_typed_bit_match=2
- FUNC.CEILING.MATH: exact_typed_bit_match=3
- FUNC.CEILING.PRECISE: exact_typed_bit_match=2
- FUNC.FLOOR: exact_typed_bit_match=2
- FUNC.FLOOR.MATH: exact_typed_bit_match=3
- FUNC.FLOOR.PRECISE: exact_typed_bit_match=2
- FUNC.ISO.CEILING: exact_typed_bit_match=2
- FUNC.ATAN2: exact_typed_bit_match=3
- FUNC.BASE: exact_typed_bit_match=3
- FUNC.MROUND: exact_typed_bit_match=2

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
