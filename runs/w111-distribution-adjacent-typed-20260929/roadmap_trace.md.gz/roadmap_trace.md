# Array Support Roadmap Trace

- Run ID: w111-distribution-adjacent-typed-20260929
- Tranche: w111-distribution-adjacent-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 21
- Formula cases executed: 1620

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: typed_argument.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 1152
- unexpected_mismatch: 352
- excel_harness_blocked: 6
- known_residual: 110
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.CONFIDENCE: exact_typed_bit_match=63, unexpected_mismatch=7
- FUNC.CONFIDENCE.NORM: exact_typed_bit_match=56, unexpected_mismatch=14
- FUNC.NORM.INV: exact_typed_bit_match=58, unexpected_mismatch=12
- FUNC.NORMINV: exact_typed_bit_match=65, unexpected_mismatch=5
- FUNC.NORM.S.INV: exact_typed_bit_match=20, excel_harness_blocked=2, known_residual=2
- FUNC.NORMSINV: exact_typed_bit_match=22, excel_harness_blocked=2
- FUNC.NORMSDIST: exact_typed_bit_match=22, excel_harness_blocked=2
- FUNC.LOGNORM.INV: exact_typed_bit_match=58, unexpected_mismatch=12
- FUNC.LOGNORM.DIST: unexpected_mismatch=52, exact_typed_bit_match=56
- FUNC.LOGNORMDIST: exact_typed_bit_match=59, unexpected_mismatch=11
- FUNC.BINOM.DIST: exact_typed_bit_match=75, unexpected_mismatch=33
- FUNC.BINOMDIST: exact_typed_bit_match=84, unexpected_mismatch=24
- FUNC.BINOM.DIST.RANGE: unexpected_mismatch=26, exact_typed_bit_match=66
- FUNC.BINOM.INV: exact_typed_bit_match=36, unexpected_mismatch=34
- FUNC.CRITBINOM: exact_typed_bit_match=43, unexpected_mismatch=27
- FUNC.POISSON: exact_typed_bit_match=63, unexpected_mismatch=23
- FUNC.POISSON.DIST: exact_typed_bit_match=56, unexpected_mismatch=30
- FUNC.HYPGEOM.DIST: known_residual=60, exact_typed_bit_match=70
- FUNC.HYPGEOMDIST: known_residual=34, exact_typed_bit_match=58
- FUNC.NEGBINOM.DIST: exact_typed_bit_match=66, unexpected_mismatch=42
- FUNC.NEGBINOMDIST: exact_typed_bit_match=56, known_residual=14

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
