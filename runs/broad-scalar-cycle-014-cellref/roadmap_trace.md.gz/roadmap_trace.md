# Broad Scalar Explorer Trace

- Generated/evaluated locally: `1000000`
- Excel candidate samples selected: `800`
- Distinct coverage areas: `78665`
- Local throughput: `381921.02` cases/sec
