# Array Support Roadmap Trace

- Run ID: w111-radix-typed-20260929
- Tranche: w111-radix-typed-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 13
- Formula cases executed: 3261

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: typed_argument.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- unexpected_mismatch: 1137
- exact_typed_bit_match: 2112
- excel_harness_blocked: 12
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.BIN2DEC: unexpected_mismatch=10, exact_typed_bit_match=22, excel_harness_blocked=1
- FUNC.BIN2HEX: unexpected_mismatch=130, exact_typed_bit_match=221, excel_harness_blocked=1
- FUNC.BIN2OCT: unexpected_mismatch=130, exact_typed_bit_match=221, excel_harness_blocked=1
- FUNC.OCT2DEC: unexpected_mismatch=10, exact_typed_bit_match=22, excel_harness_blocked=1
- FUNC.OCT2BIN: unexpected_mismatch=130, exact_typed_bit_match=221, excel_harness_blocked=1
- FUNC.OCT2HEX: unexpected_mismatch=130, exact_typed_bit_match=221, excel_harness_blocked=1
- FUNC.HEX2DEC: unexpected_mismatch=10, exact_typed_bit_match=22, excel_harness_blocked=1
- FUNC.HEX2BIN: unexpected_mismatch=130, exact_typed_bit_match=221, excel_harness_blocked=1
- FUNC.HEX2OCT: unexpected_mismatch=130, exact_typed_bit_match=221, excel_harness_blocked=1
- FUNC.DEC2BIN: exact_typed_bit_match=125, unexpected_mismatch=70, excel_harness_blocked=1
- FUNC.DEC2HEX: exact_typed_bit_match=125, unexpected_mismatch=70, excel_harness_blocked=1
- FUNC.DEC2OCT: exact_typed_bit_match=125, unexpected_mismatch=70, excel_harness_blocked=1
- FUNC.BASE: exact_typed_bit_match=345, unexpected_mismatch=117

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
