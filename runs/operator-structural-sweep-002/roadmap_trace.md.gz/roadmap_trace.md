# Array Support Roadmap Trace

- Run ID: operator-structural-sweep-002
- Tranche: operator-structural-probes-v0
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 15
- Formula cases executed: 99

## Axes touched

- Function family/category: Operators.
- Array argument axes: operator_structural_probe.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 99
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.OP_ADD: exact_typed_bit_match=7
- FUNC.OP_SUBTRACT: exact_typed_bit_match=7
- FUNC.OP_MULTIPLY: exact_typed_bit_match=7
- FUNC.OP_DIVIDE: exact_typed_bit_match=7
- FUNC.OP_POWER: exact_typed_bit_match=7
- FUNC.OP_CONCAT: exact_typed_bit_match=7
- FUNC.OP_EQUAL: exact_typed_bit_match=7
- FUNC.OP_NOT_EQUAL: exact_typed_bit_match=7
- FUNC.OP_GREATER_THAN: exact_typed_bit_match=7
- FUNC.OP_GREATER_EQUAL: exact_typed_bit_match=7
- FUNC.OP_LESS_THAN: exact_typed_bit_match=7
- FUNC.OP_LESS_EQUAL: exact_typed_bit_match=7
- FUNC.OP_NEGATE: exact_typed_bit_match=5
- FUNC.OP_UNARY_PLUS: exact_typed_bit_match=5
- FUNC.OP_PERCENT: exact_typed_bit_match=5

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
