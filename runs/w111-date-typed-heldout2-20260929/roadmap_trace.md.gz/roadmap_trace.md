# Array Support Roadmap Trace

- Run ID: w111-date-typed-heldout2-20260929
- Tranche: w111-date-typed-heldout2-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 13
- Formula cases executed: 780

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: date_independent_mixed_broadcast.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 743
- unexpected_mismatch: 37
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.DAY: exact_typed_bit_match=58, unexpected_mismatch=2
- FUNC.MONTH: exact_typed_bit_match=53, unexpected_mismatch=7
- FUNC.YEAR: exact_typed_bit_match=53, unexpected_mismatch=7
- FUNC.HOUR: exact_typed_bit_match=54, unexpected_mismatch=6
- FUNC.MINUTE: exact_typed_bit_match=54, unexpected_mismatch=6
- FUNC.SECOND: exact_typed_bit_match=51, unexpected_mismatch=9
- FUNC.ISOWEEKNUM: exact_typed_bit_match=60
- FUNC.DATE: exact_typed_bit_match=60
- FUNC.DAYS: exact_typed_bit_match=60
- FUNC.EDATE: exact_typed_bit_match=60
- FUNC.EOMONTH: exact_typed_bit_match=60
- FUNC.WEEKDAY: exact_typed_bit_match=60
- FUNC.WEEKNUM: exact_typed_bit_match=60

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
