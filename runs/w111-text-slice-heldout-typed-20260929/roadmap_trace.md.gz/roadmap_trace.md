# Array Support Roadmap Trace

- Run ID: w111-text-slice-heldout-typed-20260929
- Tranche: w111-text-slice-heldout-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 10
- Formula cases executed: 2100

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: text_independent_numeric_boundaries, text_independent_typed_broadcast.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 2100
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.LEFT: exact_typed_bit_match=231
- FUNC.RIGHT: exact_typed_bit_match=228
- FUNC.LEFTB: exact_typed_bit_match=236
- FUNC.RIGHTB: exact_typed_bit_match=238
- FUNC.MID: exact_typed_bit_match=226
- FUNC.MIDB: exact_typed_bit_match=221
- FUNC.LEN: exact_typed_bit_match=180
- FUNC.LENB: exact_typed_bit_match=180
- FUNC.EXACT: exact_typed_bit_match=180
- FUNC.ENCODEURL: exact_typed_bit_match=180

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
