# Array Support Roadmap Trace

- Run ID: w111-distribution-unit-padding-typed-20260929
- Tranche: w111-distribution-unit-padding-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 22
- Formula cases executed: 132

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: typed_argument.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 81
- unexpected_mismatch: 36
- known_residual: 15
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.CONFIDENCE: exact_typed_bit_match=3, unexpected_mismatch=3
- FUNC.CONFIDENCE.NORM: exact_typed_bit_match=6
- FUNC.NORM.INV: exact_typed_bit_match=6
- FUNC.NORMINV: exact_typed_bit_match=3, unexpected_mismatch=3
- FUNC.LOGNORM.INV: exact_typed_bit_match=6
- FUNC.LOGNORM.DIST: unexpected_mismatch=6
- FUNC.LOGNORMDIST: exact_typed_bit_match=3, unexpected_mismatch=3
- FUNC.BINOM.DIST: exact_typed_bit_match=6
- FUNC.BINOMDIST: exact_typed_bit_match=3, unexpected_mismatch=3
- FUNC.BINOM.DIST.RANGE: unexpected_mismatch=6
- FUNC.BINOM.INV: exact_typed_bit_match=6
- FUNC.CRITBINOM: exact_typed_bit_match=3, unexpected_mismatch=3
- FUNC.POISSON: exact_typed_bit_match=3, unexpected_mismatch=3
- FUNC.POISSON.DIST: exact_typed_bit_match=6
- FUNC.HYPGEOM.DIST: known_residual=6
- FUNC.HYPGEOMDIST: known_residual=6
- FUNC.NEGBINOM.DIST: exact_typed_bit_match=6
- FUNC.NEGBINOMDIST: exact_typed_bit_match=3, known_residual=3
- FUNC.NORM.DIST: exact_typed_bit_match=6
- FUNC.NORMDIST: exact_typed_bit_match=3, unexpected_mismatch=3
- FUNC.EXPON.DIST: exact_typed_bit_match=6
- FUNC.EXPONDIST: exact_typed_bit_match=3, unexpected_mismatch=3

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
