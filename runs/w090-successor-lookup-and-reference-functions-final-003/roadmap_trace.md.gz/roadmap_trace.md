﻿# Array Support Roadmap Trace

- Run ID: w090-successor-lookup-and-reference-functions-final-003
- Tranche: w090-successor-lookup-and-reference-functions
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance.
- Surfaces executed: 11
- Formula cases executed: 20

## Axes touched

- Function family/category: Lookup and reference functions.
- Risk bands: high, medium.
- Array argument axes: one_array_arg:arg1, one_array_arg:arg2, one_array_arg:arg3, one_array_arg:arg4.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.
- Scenario seed sources: docs\function-lane\W39_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W40_SCENARIO_MANIFEST_SEED.csv.

## Rollup

- exact_typed_bit_match: 5
- unexpected_mismatch: 14
- local_harness_blocked: 1

## Function highlights

- FUNC.CHOOSECOLS: exact_typed_bit_match=2
- FUNC.CHOOSEROWS: exact_typed_bit_match=2
- FUNC.DROP: unexpected_mismatch=2
- FUNC.EXPAND: unexpected_mismatch=2, local_harness_blocked=1
- FUNC.SORT: unexpected_mismatch=1, exact_typed_bit_match=1
- FUNC.TAKE: unexpected_mismatch=2
- FUNC.TOCOL: unexpected_mismatch=1
- FUNC.TOROW: unexpected_mismatch=2
- FUNC.WRAPCOLS: unexpected_mismatch=1
- FUNC.WRAPROWS: unexpected_mismatch=1
- FUNC.ADDRESS: unexpected_mismatch=2

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
