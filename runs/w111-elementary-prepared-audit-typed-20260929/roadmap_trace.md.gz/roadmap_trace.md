# Array Support Roadmap Trace

- Run ID: w111-elementary-prepared-audit-typed-20260929
- Tranche: w111-elementary-prepared-audit-20260929-002
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 4
- Formula cases executed: 433

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: aggregate_origin, array_origin, broadcast_padding_order, mixed_reference_elements, omitted_default, ordered_coercion, reference_origin, scalar_origin, unit_array_origin.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 378
- unexpected_mismatch: 55
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.LOG: exact_typed_bit_match=105, unexpected_mismatch=44
- FUNC.POWER: exact_typed_bit_match=128, unexpected_mismatch=7
- FUNC.FISHER: exact_typed_bit_match=46
- FUNC.MEDIAN: exact_typed_bit_match=99, unexpected_mismatch=4

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
