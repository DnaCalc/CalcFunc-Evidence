# Broad Scalar Explorer Trace

- Generated/evaluated locally: `2000000`
- Excel candidate samples selected: `600`
- Distinct coverage areas: `133546`
- Local throughput: `332578.87` cases/sec
