# Array Support Roadmap Trace

- Run ID: w111-gcd-lcm-discovery2-typed-20260929
- Tranche: w111-gcd-lcm-discovery2-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 2
- Formula cases executed: 654

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: aggregate_origin_and_missing, coercion_domain_error_order, empty_reduction_and_required_slot.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 468
- unexpected_mismatch: 184
- excel_harness_blocked: 2
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.GCD: exact_typed_bit_match=234, unexpected_mismatch=92, excel_harness_blocked=1
- FUNC.LCM: exact_typed_bit_match=234, unexpected_mismatch=92, excel_harness_blocked=1

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
