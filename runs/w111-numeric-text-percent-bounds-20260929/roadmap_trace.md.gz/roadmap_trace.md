# Array Support Roadmap Trace

- Run ID: w111-numeric-text-percent-bounds-20260929
- Tranche: w111-numeric-text-percent-bounds-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 1
- Formula cases executed: 360

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: decimal_percent_admission.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- unexpected_mismatch: 200
- exact_typed_bit_match: 160
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.ABS: unexpected_mismatch=200, exact_typed_bit_match=160

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
