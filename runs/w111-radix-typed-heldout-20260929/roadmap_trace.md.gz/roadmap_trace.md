# Array Support Roadmap Trace

- Run ID: w111-radix-typed-heldout-20260929
- Tranche: w111-radix-heldout-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 13
- Formula cases executed: 1950

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: typed_argument.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 1677
- generator_invalid: 273
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.BIN2DEC: exact_typed_bit_match=150
- FUNC.BIN2HEX: exact_typed_bit_match=121, generator_invalid=29
- FUNC.BIN2OCT: exact_typed_bit_match=125, generator_invalid=25
- FUNC.OCT2DEC: exact_typed_bit_match=150
- FUNC.OCT2BIN: generator_invalid=31, exact_typed_bit_match=119
- FUNC.OCT2HEX: exact_typed_bit_match=122, generator_invalid=28
- FUNC.HEX2DEC: exact_typed_bit_match=150
- FUNC.HEX2BIN: exact_typed_bit_match=120, generator_invalid=30
- FUNC.HEX2OCT: generator_invalid=24, exact_typed_bit_match=126
- FUNC.DEC2BIN: exact_typed_bit_match=131, generator_invalid=19
- FUNC.DEC2HEX: exact_typed_bit_match=122, generator_invalid=28
- FUNC.DEC2OCT: exact_typed_bit_match=125, generator_invalid=25
- FUNC.BASE: generator_invalid=34, exact_typed_bit_match=116

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
