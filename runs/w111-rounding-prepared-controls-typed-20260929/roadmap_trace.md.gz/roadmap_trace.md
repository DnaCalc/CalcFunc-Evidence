# Array Support Roadmap Trace

- Run ID: w111-rounding-prepared-controls-typed-20260929
- Tranche: w111-rounding-prepared-controls-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 4
- Formula cases executed: 691

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: broadcast_padding_order, error_precedence, optional_count, reference_array, typed_origins.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 658
- unexpected_mismatch: 32
- excel_harness_blocked: 1
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.ROUND: exact_typed_bit_match=159, unexpected_mismatch=8
- FUNC.ROUNDDOWN: exact_typed_bit_match=159, unexpected_mismatch=8
- FUNC.ROUNDUP: exact_typed_bit_match=159, unexpected_mismatch=8
- FUNC.TRUNC: exact_typed_bit_match=181, unexpected_mismatch=8, excel_harness_blocked=1

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
