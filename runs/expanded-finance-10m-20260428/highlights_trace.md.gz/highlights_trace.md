# Expanded Smart-Fuzzer Highlights

Run id: `expanded-finance-10m-20260428`

## Counts

1. Local generated/evaluated cases: `10000000`
2. Excel candidate samples: `640`
3. Exact sample matches: `536`
4. Expected known financial exactness or literal-encoding deviations: `102`
5. Unexpected mismatches: `2`
6. Blocked sample rows: `0`

## Explored Areas

See `roadmap_trace.md` and `roadmap_trace.json` in this run directory. The run covered PMT, PPMT, and IPMT across arity, rate, horizon, present/future value, payment timing, and period-position bands.

## Deviations

1. Expected known class: PMT/PPMT/IPMT non-zero-rate exactness drift and formula-literal encoding drift in sampled numeric cases.
2. Unexpected samples: two high-rate/long-horizon PPMT cases where local returned `#NUM!` and Excel returned a tiny numeric value or zero; both are recorded under `failure_packets/`.

## Interpretation

The unexpected samples are adjacent evidence for the blocked `BUG-FUNC-015` financial-payment exactness lane, not a repair instruction.
