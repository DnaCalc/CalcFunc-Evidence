﻿# Array Support Roadmap Trace

- Run ID: w090-successor-compatibility-final-001
- Tranche: w090-successor-compatibility
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance.
- Surfaces executed: 27
- Formula cases executed: 68

## Axes touched

- Function family/category: Compatibility.
- Risk bands: high, low.
- Array argument axes: one_array_arg:arg1, one_array_arg:arg2, one_array_arg:arg3.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.
- Scenario seed sources: docs\function-lane\W61_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W62_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W66_SCENARIO_MANIFEST_SEED.csv.

## Rollup

- unexpected_mismatch: 68

## Function highlights

- FUNC.BETADIST: unexpected_mismatch=3
- FUNC.BETAINV: unexpected_mismatch=3
- FUNC.BINOMDIST: unexpected_mismatch=3
- FUNC.CHIDIST: unexpected_mismatch=2
- FUNC.CHIINV: unexpected_mismatch=2
- FUNC.CONFIDENCE: unexpected_mismatch=3
- FUNC.CRITBINOM: unexpected_mismatch=3
- FUNC.EXPONDIST: unexpected_mismatch=3
- FUNC.FDIST: unexpected_mismatch=3
- FUNC.FINV: unexpected_mismatch=3
- FUNC.GAMMADIST: unexpected_mismatch=3
- FUNC.GAMMAINV: unexpected_mismatch=3
- FUNC.HYPGEOMDIST: unexpected_mismatch=3
- FUNC.LOGNORMDIST: unexpected_mismatch=3
- FUNC.NEGBINOMDIST: unexpected_mismatch=3
- FUNC.NORMDIST: unexpected_mismatch=3
- FUNC.NORMINV: unexpected_mismatch=3
- FUNC.NORMSDIST: unexpected_mismatch=1
- FUNC.NORMSINV: unexpected_mismatch=1
- FUNC.POISSON: unexpected_mismatch=3
- FUNC.TDIST: unexpected_mismatch=3
- FUNC.TINV: unexpected_mismatch=2
- FUNC.CONCATENATE: unexpected_mismatch=3
- FUNC.LOGINV: unexpected_mismatch=3
- FUNC.PERCENTILE: unexpected_mismatch=1
- FUNC.PERCENTRANK: unexpected_mismatch=1
- FUNC.QUARTILE: unexpected_mismatch=1

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
