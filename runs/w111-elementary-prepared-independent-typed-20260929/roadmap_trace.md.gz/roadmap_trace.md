# Array Support Roadmap Trace

- Run ID: w111-elementary-prepared-independent-typed-20260929
- Tranche: w111-elementary-prepared-heldout-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 4
- Formula cases executed: 832

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: fresh_aggregate_origins, fresh_optional_base, fresh_reference_elements, fresh_scalar_pairs, fresh_shape_pairs, unchanged_unary_controls.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 824
- unexpected_mismatch: 8
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.LOG: exact_typed_bit_match=304
- FUNC.POWER: exact_typed_bit_match=240
- FUNC.MEDIAN: exact_typed_bit_match=184, unexpected_mismatch=8
- FUNC.FISHER: exact_typed_bit_match=96

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
