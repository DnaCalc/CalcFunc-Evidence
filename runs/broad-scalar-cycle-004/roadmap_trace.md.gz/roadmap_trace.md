# Broad Scalar Explorer Trace

- Generated/evaluated locally: `1500000`
- Excel candidate samples selected: `600`
- Distinct coverage areas: `107350`
- Local throughput: `233727.04` cases/sec
