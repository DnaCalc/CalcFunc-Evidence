# Array Support Roadmap Trace

- Run ID: w111-decimal-parser-midpoints-typed-20260929
- Tranche: w111-decimal-parser-midpoints-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 2
- Formula cases executed: 1960

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: decimal_parser_fresh_normal_control, decimal_parser_midpoint_discriminator.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 1902
- unexpected_mismatch: 58
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.ABS: exact_typed_bit_match=1451, unexpected_mismatch=29
- FUNC.IMREAL: exact_typed_bit_match=451, unexpected_mismatch=29

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
