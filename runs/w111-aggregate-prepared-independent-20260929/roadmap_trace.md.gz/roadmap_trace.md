# Array Support Roadmap Trace

- Run ID: w111-aggregate-prepared-independent-20260929
- Tranche: w111-aggregate-prepared-independent-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 2
- Formula cases executed: 566

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: independent_array_order, independent_coercion_before_domain, independent_empty_reference, independent_reference_order, independent_scalar_collection.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 566
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.HARMEAN: exact_typed_bit_match=283
- FUNC.DEVSQ: exact_typed_bit_match=283

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
