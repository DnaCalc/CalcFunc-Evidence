# Array Support Roadmap Trace

- Run ID: w111-date-array-heldout-typed-20260929
- Tranche: w111-date-array-heldout-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 6
- Formula cases executed: 720

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: date_array_error_publication.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 360
- unexpected_mismatch: 360
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.DAY: exact_typed_bit_match=60, unexpected_mismatch=60
- FUNC.MONTH: exact_typed_bit_match=60, unexpected_mismatch=60
- FUNC.YEAR: exact_typed_bit_match=60, unexpected_mismatch=60
- FUNC.HOUR: exact_typed_bit_match=60, unexpected_mismatch=60
- FUNC.MINUTE: exact_typed_bit_match=60, unexpected_mismatch=60
- FUNC.SECOND: exact_typed_bit_match=60, unexpected_mismatch=60

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
