# Array Support Roadmap Trace

- Run ID: w111-mround-reference-controls-run-typed-20260929
- Tranche: w111-mround-reference-controls-typed-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 1
- Formula cases executed: 80

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: mround_both_reference_intersection, mround_reference_intersection_discriminator.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- unexpected_mismatch: 54
- exact_typed_bit_match: 26
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.MROUND: unexpected_mismatch=54, exact_typed_bit_match=26

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
