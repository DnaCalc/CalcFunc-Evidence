﻿# Array Support Roadmap Trace

- Run ID: w090-repair3-engineering-functions-001
- Tranche: w090-successor-engineering-functions
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance.
- Surfaces executed: 26
- Formula cases executed: 32

## Axes touched

- Function family/category: Engineering functions.
- Risk bands: high.
- Array argument axes: one_array_arg:arg1, one_array_arg:arg2.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.
- Scenario seed sources: docs\function-lane\W60_SCENARIO_MANIFEST_SEED.csv.

## Rollup

- exact_typed_bit_match: 32

## Function highlights

- FUNC.COMPLEX: exact_typed_bit_match=2
- FUNC.IMABS: exact_typed_bit_match=1
- FUNC.IMAGINARY: exact_typed_bit_match=1
- FUNC.IMARGUMENT: exact_typed_bit_match=1
- FUNC.IMCONJUGATE: exact_typed_bit_match=1
- FUNC.IMCOS: exact_typed_bit_match=1
- FUNC.IMCOSH: exact_typed_bit_match=1
- FUNC.IMCOT: exact_typed_bit_match=1
- FUNC.IMCSC: exact_typed_bit_match=1
- FUNC.IMCSCH: exact_typed_bit_match=1
- FUNC.IMDIV: exact_typed_bit_match=2
- FUNC.IMEXP: exact_typed_bit_match=1
- FUNC.IMLN: exact_typed_bit_match=1
- FUNC.IMLOG10: exact_typed_bit_match=1
- FUNC.IMLOG2: exact_typed_bit_match=1
- FUNC.IMPOWER: exact_typed_bit_match=2
- FUNC.IMPRODUCT: exact_typed_bit_match=2
- FUNC.IMREAL: exact_typed_bit_match=1
- FUNC.IMSEC: exact_typed_bit_match=1
- FUNC.IMSECH: exact_typed_bit_match=1
- FUNC.IMSIN: exact_typed_bit_match=1
- FUNC.IMSINH: exact_typed_bit_match=1
- FUNC.IMSQRT: exact_typed_bit_match=1
- FUNC.IMSUB: exact_typed_bit_match=2
- FUNC.IMSUM: exact_typed_bit_match=2
- FUNC.IMTAN: exact_typed_bit_match=1

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
