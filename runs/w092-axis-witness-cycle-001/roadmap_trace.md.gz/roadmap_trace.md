﻿# Array Support Roadmap Trace

- Run ID: w092-axis-witness-cycle-001
- Tranche: w089-axis-witness-sweep-v0
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance.
- Surfaces executed: 17
- Formula cases executed: 38

## Axes touched

- Function family/category: arity, array, comparison, context, function_surface, logical_error_blank, numeric, reference, text, value_type.
- Array argument axes: blank_cell_vs_empty_text, caller_location, case_variant, empty_string_vs_whitespace, error_code_equality, error_value_vs_number, explicit_missing_optional, function_identity, logical_true_vs_false, optional_argument_present_vs_omitted, reference_vs_array_literal_contrast, row_vector_vs_column_vector, same_sheet_multi_area, scalar_control_vs_array_literal, scalar_text_numeric_vs_non_numeric, single_cell_vs_rectangular_area, tiny_negative_vs_zero, variadic_argument_count, zero_to_zero_power_edge.
- Invocation-space axis tags: blank_cell_vs_empty_text, caller_location, case_variant, empty_string_vs_whitespace, error_code_equality, error_value_vs_number, explicit_missing_optional, function_identity, logical_true_vs_false, optional_argument_present_vs_omitted, reference_vs_array_literal_contrast, row_vector_vs_column_vector, same_sheet_multi_area, scalar_control_vs_array_literal, scalar_text_numeric_vs_non_numeric, single_cell_vs_rectangular_area, tiny_negative_vs_zero, variadic_argument_count, zero_to_zero_power_edge.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 37
- unexpected_mismatch: 1
- axis witness pairs: total=19, differentiated=19, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.ABS: exact_typed_bit_match=3
- FUNC.SIGN: exact_typed_bit_match=3
- FUNC.TRUNC: exact_typed_bit_match=2
- FUNC.TAKE: exact_typed_bit_match=1, unexpected_mismatch=1
- FUNC.SUM: exact_typed_bit_match=4
- FUNC.IF: exact_typed_bit_match=2
- FUNC.ISERROR: exact_typed_bit_match=2
- FUNC.ISBLANK: exact_typed_bit_match=2
- FUNC.POWER: exact_typed_bit_match=2
- FUNC.LEN: exact_typed_bit_match=2
- FUNC.EXACT: exact_typed_bit_match=2
- FUNC.ROWS: exact_typed_bit_match=2
- FUNC.COUNTBLANK: exact_typed_bit_match=2
- FUNC.COLUMNS: exact_typed_bit_match=2
- FUNC.AREAS: exact_typed_bit_match=2
- FUNC.ROW: exact_typed_bit_match=2
- FUNC.ERROR.TYPE: exact_typed_bit_match=2

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
