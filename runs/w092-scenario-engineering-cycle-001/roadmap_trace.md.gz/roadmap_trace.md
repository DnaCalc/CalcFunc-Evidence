﻿# Array Support Roadmap Trace

- Run ID: w092-scenario-engineering-cycle-001
- Tranche: w089-scenario-seed-engineering-functions
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance.
- Surfaces executed: 40
- Formula cases executed: 56

## Axes touched

- Function family/category: Engineering functions.
- Array argument axes: scenario_seed_literal_args.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.
- Scenario seed sources: docs\function-lane\W59_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W60_SCENARIO_MANIFEST_SEED.csv.

## Rollup

- exact_typed_bit_match: 55
- unexpected_mismatch: 1
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.BESSELI: exact_typed_bit_match=3
- FUNC.BESSELJ: exact_typed_bit_match=2
- FUNC.BESSELK: exact_typed_bit_match=2
- FUNC.BESSELY: unexpected_mismatch=1, exact_typed_bit_match=1
- FUNC.BIN2DEC: exact_typed_bit_match=1
- FUNC.BIN2HEX: exact_typed_bit_match=2
- FUNC.COMPLEX: exact_typed_bit_match=3
- FUNC.DEC2BIN: exact_typed_bit_match=3
- FUNC.DEC2HEX: exact_typed_bit_match=2
- FUNC.DEC2OCT: exact_typed_bit_match=1
- FUNC.HEX2BIN: exact_typed_bit_match=1
- FUNC.HEX2DEC: exact_typed_bit_match=2
- FUNC.HEX2OCT: exact_typed_bit_match=1
- FUNC.IMABS: exact_typed_bit_match=1
- FUNC.IMAGINARY: exact_typed_bit_match=1
- FUNC.IMARGUMENT: exact_typed_bit_match=2
- FUNC.IMCONJUGATE: exact_typed_bit_match=1
- FUNC.IMCOS: exact_typed_bit_match=1
- FUNC.IMCOSH: exact_typed_bit_match=1
- FUNC.IMCOT: exact_typed_bit_match=1
- FUNC.IMCSC: exact_typed_bit_match=1
- FUNC.IMCSCH: exact_typed_bit_match=1
- FUNC.IMDIV: exact_typed_bit_match=1
- FUNC.IMEXP: exact_typed_bit_match=1
- FUNC.IMLN: exact_typed_bit_match=2
- FUNC.IMLOG10: exact_typed_bit_match=1
- FUNC.IMLOG2: exact_typed_bit_match=1
- FUNC.IMPOWER: exact_typed_bit_match=2
- FUNC.IMPRODUCT: exact_typed_bit_match=1
- FUNC.IMREAL: exact_typed_bit_match=1
- FUNC.IMSEC: exact_typed_bit_match=1
- FUNC.IMSECH: exact_typed_bit_match=1
- FUNC.IMSIN: exact_typed_bit_match=1
- FUNC.IMSINH: exact_typed_bit_match=1
- FUNC.IMSQRT: exact_typed_bit_match=1
- FUNC.IMSUB: exact_typed_bit_match=1
- FUNC.IMSUM: exact_typed_bit_match=2
- FUNC.IMTAN: exact_typed_bit_match=1
- FUNC.OCT2BIN: exact_typed_bit_match=1
- FUNC.OCT2HEX: exact_typed_bit_match=1

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
