﻿# Array Support Roadmap Trace

- Run ID: w090-repair2-lookup-and-reference-functions-001
- Tranche: w090-successor-lookup-and-reference-functions
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance.
- Surfaces executed: 11
- Formula cases executed: 20

## Axes touched

- Function family/category: Lookup and reference functions.
- Risk bands: high, medium.
- Array argument axes: one_array_arg:arg1, one_array_arg:arg2, one_array_arg:arg3, one_array_arg:arg4.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.
- Scenario seed sources: docs\function-lane\W39_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W40_SCENARIO_MANIFEST_SEED.csv.

## Rollup

- exact_typed_bit_match: 20

## Function highlights

- FUNC.CHOOSECOLS: exact_typed_bit_match=2
- FUNC.CHOOSEROWS: exact_typed_bit_match=2
- FUNC.DROP: exact_typed_bit_match=2
- FUNC.EXPAND: exact_typed_bit_match=3
- FUNC.SORT: exact_typed_bit_match=2
- FUNC.TAKE: exact_typed_bit_match=2
- FUNC.TOCOL: exact_typed_bit_match=1
- FUNC.TOROW: exact_typed_bit_match=2
- FUNC.WRAPCOLS: exact_typed_bit_match=1
- FUNC.WRAPROWS: exact_typed_bit_match=1
- FUNC.ADDRESS: exact_typed_bit_match=2

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
