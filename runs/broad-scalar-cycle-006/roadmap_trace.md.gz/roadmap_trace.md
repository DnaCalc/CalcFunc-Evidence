# Broad Scalar Explorer Trace

- Generated/evaluated locally: `2000000`
- Excel candidate samples selected: `600`
- Distinct coverage areas: `133964`
- Local throughput: `334133.77` cases/sec
