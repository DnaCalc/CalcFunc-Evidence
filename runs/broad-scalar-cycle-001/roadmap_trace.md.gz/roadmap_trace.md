# Broad Scalar Explorer Trace

- Generated/evaluated locally: `1000000`
- Excel candidate samples selected: `600`
- Distinct coverage areas: `77017`
- Local throughput: `377991.76` cases/sec
