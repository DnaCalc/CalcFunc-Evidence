# Broad Scalar Explorer Trace

- Generated/evaluated locally: `1000000`
- Excel candidate samples selected: `800`
- Distinct coverage areas: `79073`
- Local throughput: `365955.51` cases/sec
