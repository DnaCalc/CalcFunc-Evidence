use crate::function::{
    Arity, CoercionLiftProfile, DeterminismClass, FecDependencyProfile, FunctionMeta,
    HostInteractionClass, KernelSignatureClass, ThreadSafetyClass, VolatilityClass,
};
use crate::functions::unary_numeric::{
    UnaryNumericExecSpec, UnaryNumericSurfaceError, eval_unary_numeric_via_executor,
    map_unary_numeric_error_to_ws,
};
use crate::resolver::ReferenceSystemProvider;
use crate::value::CalcValue;
use crate::value::WorksheetErrorCode;

pub const INT_META: FunctionMeta = function_spec! {
    function_id: "FUNC.INT",
    arity: Arity::exact(1),
    determinism: DeterminismClass::Deterministic,
    volatility: VolatilityClass::NonVolatile,
    host_interaction: HostInteractionClass::None,
    thread_safety: ThreadSafetyClass::SafePure,
    coercion_lift_profile: CoercionLiftProfile::UnaryNumericScalarOrArrayElementwise,
    kernel_signature_class: KernelSignatureClass::NumToNum,
    fec_dependency_profile: FecDependencyProfile::None,
    surface_fec_dependency_profile: FecDependencyProfile::RefOnly,
};

pub fn int_kernel(n: f64) -> Result<f64, WorksheetErrorCode> {
    // Already integral binary64 values keep every bit; applying a decimal
    // precision reduction to those would incorrectly change large integers.
    if !n.is_finite() || n == n.floor() { return Ok(n); }
    // Once all fifteen significant decimal positions lie in the integer
    // part, Excel floors the input rather than discarding integer digits.
    if n.abs() >= 1e15 { return Ok(n.floor()); }
    // W111 distinguishes this initial half-away preparation from ROUND's
    // initial tie-down rule, including exact .5 ties at 15-digit magnitudes.
    let (digits, scale) = crate::functions::round_fn::fifteen_significant_digits(n, true);
    let magnitude: f64 = format!("{digits}e{scale}").parse().expect("finite decimal integer preparation");
    Ok(magnitude.copysign(n).floor())
}

pub fn eval_int_surface(
    args: &[crate::value::CalcValue],
    resolver: &(impl ReferenceSystemProvider + ?Sized),
) -> Result<CalcValue, UnaryNumericSurfaceError> {
    eval_unary_numeric_via_executor(
        args,
        resolver,
        UnaryNumericExecSpec::fallible(int_kernel, INT_META.real_result_policy),
    )
}

pub fn map_int_error_to_ws(e: &UnaryNumericSurfaceError) -> WorksheetErrorCode {
    map_unary_numeric_error_to_ws(e)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn int_meta_function_id_is_stable() {
        assert_eq!(INT_META.function_id, "FUNC.INT");
    }

    #[test]
    fn int_kernel_floors_negative_values() {
        assert_eq!(int_kernel(-1.1), Ok(-2.0));
    }
}
