# Array Support Roadmap Trace

- Run ID: erf-logical-recheck-001
- Tranche: erf-logical-recheck-v0
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 5
- Formula cases executed: 30

## Axes touched

- Function family/category: Engineering functions, Statistical functions.
- Array argument axes: unswept_structural_probe.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 20
- unexpected_mismatch: 10
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.ERF: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.ERF.PRECISE: exact_typed_bit_match=5, unexpected_mismatch=1
- FUNC.ERFC: unexpected_mismatch=3, exact_typed_bit_match=3
- FUNC.ERFC.PRECISE: unexpected_mismatch=3, exact_typed_bit_match=3
- FUNC.GAMMALN.PRECISE: exact_typed_bit_match=4, unexpected_mismatch=2

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
