# Array Support Roadmap Trace

- Run ID: w111-numeric-to-text-discovery-typed-20260929
- Tranche: w111-numeric-to-text-discovery-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 16
- Formula cases executed: 7048

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: function_specific_formatter_control, generic_numeric_text_additional_function, generic_numeric_text_candidate_equality, generic_numeric_text_cross_function, generic_numeric_text_exact_string, generic_numeric_text_length, generic_numeric_text_shortest_control.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 1578
- unexpected_mismatch: 5470
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.LEFT: exact_typed_bit_match=137, unexpected_mismatch=1328
- FUNC.LEN: exact_typed_bit_match=164, unexpected_mismatch=1301
- FUNC.EXACT: exact_typed_bit_match=864, unexpected_mismatch=811
- FUNC.RIGHT: exact_typed_bit_match=31, unexpected_mismatch=262
- FUNC.MID: exact_typed_bit_match=31, unexpected_mismatch=262
- FUNC.TRIM: exact_typed_bit_match=31, unexpected_mismatch=262
- FUNC.CONCAT: exact_typed_bit_match=31, unexpected_mismatch=262
- FUNC.ENCODEURL: exact_typed_bit_match=31, unexpected_mismatch=262
- FUNC.LOWER: exact_typed_bit_match=14, unexpected_mismatch=120
- FUNC.UPPER: exact_typed_bit_match=14, unexpected_mismatch=120
- FUNC.CLEAN: exact_typed_bit_match=14, unexpected_mismatch=120
- FUNC.REPT: exact_typed_bit_match=14, unexpected_mismatch=120
- FUNC.SUBSTITUTE: exact_typed_bit_match=14, unexpected_mismatch=120
- FUNC.TEXTJOIN: exact_typed_bit_match=14, unexpected_mismatch=120
- FUNC.COMPLEX: exact_typed_bit_match=87
- FUNC.ADDRESS: exact_typed_bit_match=87

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
