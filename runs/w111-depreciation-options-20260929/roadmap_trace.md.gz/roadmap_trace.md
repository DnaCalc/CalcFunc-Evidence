# Array Support Roadmap Trace

- Run ID: w111-depreciation-options-20260929
- Tranche: w111-depreciation-typed-options-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 3
- Formula cases executed: 44

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: typed_argument.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- unexpected_mismatch: 10
- exact_typed_bit_match: 34
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.DB: unexpected_mismatch=2, exact_typed_bit_match=9
- FUNC.DDB: unexpected_mismatch=2, exact_typed_bit_match=9
- FUNC.VDB: unexpected_mismatch=6, exact_typed_bit_match=16

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
