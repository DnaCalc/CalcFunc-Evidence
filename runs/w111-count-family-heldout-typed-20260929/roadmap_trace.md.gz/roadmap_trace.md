# Array Support Roadmap Trace

- Run ID: w111-count-family-heldout-typed-20260929
- Tranche: w111-count-family-heldout-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 3
- Formula cases executed: 1664

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: count_family_independent_mixed_origins, count_family_independent_ranges, countblank_independent_array_errors, countblank_independent_computed_scalar.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 1647
- unexpected_mismatch: 17
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.COUNT: exact_typed_bit_match=560
- FUNC.COUNTA: exact_typed_bit_match=560
- FUNC.COUNTBLANK: exact_typed_bit_match=527, unexpected_mismatch=17

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
