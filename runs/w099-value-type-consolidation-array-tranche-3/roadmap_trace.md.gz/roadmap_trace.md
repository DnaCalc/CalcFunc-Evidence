﻿# Array Support Roadmap Trace

- Run ID: w099-value-type-consolidation-array-tranche-3
- Tranche: w090-tranche-a-math-scalar-numeric-array-lift
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 14
- Formula cases executed: 34

## Axes touched

- Function family/category: tranche-defined surface set.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 34
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.ROUND: exact_typed_bit_match=3
- FUNC.ROUNDDOWN: exact_typed_bit_match=2
- FUNC.ROUNDUP: exact_typed_bit_match=2
- FUNC.TRUNC: exact_typed_bit_match=3
- FUNC.CEILING: exact_typed_bit_match=2
- FUNC.CEILING.MATH: exact_typed_bit_match=3
- FUNC.CEILING.PRECISE: exact_typed_bit_match=2
- FUNC.FLOOR: exact_typed_bit_match=2
- FUNC.FLOOR.MATH: exact_typed_bit_match=3
- FUNC.FLOOR.PRECISE: exact_typed_bit_match=2
- FUNC.ISO.CEILING: exact_typed_bit_match=2
- FUNC.ATAN2: exact_typed_bit_match=3
- FUNC.BASE: exact_typed_bit_match=3
- FUNC.MROUND: exact_typed_bit_match=2

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
