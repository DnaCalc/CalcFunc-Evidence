﻿# Array Support Roadmap Trace

- Run ID: w092-scenario-featured-cycle-001
- Tranche: w089-scenario-seed-our-10-featured-functions
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance.
- Surfaces executed: 5
- Formula cases executed: 9

## Axes touched

- Function family/category: Our 10 featured functions.
- Array argument axes: scenario_seed_literal_args.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.
- Scenario seed sources: docs\function-lane\COERCION_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W10_S1_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W10_S2_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W12_S1_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W39_SCENARIO_MANIFEST_SEED.csv.

## Rollup

- exact_typed_bit_match: 9
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.COUNT: exact_typed_bit_match=2
- FUNC.FILTER: exact_typed_bit_match=1
- FUNC.IF: exact_typed_bit_match=1
- FUNC.SUM: exact_typed_bit_match=4
- FUNC.UNIQUE: exact_typed_bit_match=1

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
