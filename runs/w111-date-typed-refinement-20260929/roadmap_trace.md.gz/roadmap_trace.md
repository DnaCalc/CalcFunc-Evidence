# Array Support Roadmap Trace

- Run ID: w111-date-typed-refinement-20260929
- Tranche: w111-date-typed-refinement-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 6
- Formula cases executed: 1137

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: date_array_coercion, date_error_precedence, date_reference_coercion.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 899
- unexpected_mismatch: 238
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.DATE: exact_typed_bit_match=161, unexpected_mismatch=46
- FUNC.DAYS: exact_typed_bit_match=160, unexpected_mismatch=26
- FUNC.EDATE: exact_typed_bit_match=136, unexpected_mismatch=50
- FUNC.EOMONTH: exact_typed_bit_match=136, unexpected_mismatch=50
- FUNC.WEEKDAY: exact_typed_bit_match=170, unexpected_mismatch=16
- FUNC.WEEKNUM: exact_typed_bit_match=136, unexpected_mismatch=50

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
