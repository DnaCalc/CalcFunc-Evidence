# Array Support Roadmap Trace

- Run ID: reference-fixture-002
- Tranche: reference-fixture-probes-v0
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 22
- Formula cases executed: 24

## Axes touched

- Function family/category: Information functions, Logical functions, Lookup and reference functions, Math and trigonometry functions, Statistical functions.
- Array argument axes: reference_fixture_probe.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 14
- unexpected_mismatch: 10
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.VLOOKUP: exact_typed_bit_match=2
- FUNC.HLOOKUP: exact_typed_bit_match=1
- FUNC.XLOOKUP: unexpected_mismatch=1
- FUNC.LOOKUP: exact_typed_bit_match=1
- FUNC.OFFSET: unexpected_mismatch=1
- FUNC.CHOOSE: exact_typed_bit_match=1
- FUNC.AGGREGATE: unexpected_mismatch=1
- FUNC.SUBTOTAL: unexpected_mismatch=1
- FUNC.CELL: exact_typed_bit_match=1
- FUNC.COLUMN: exact_typed_bit_match=1
- FUNC.FORMULATEXT: unexpected_mismatch=1
- FUNC.ISFORMULA: unexpected_mismatch=1
- FUNC.SHEET: unexpected_mismatch=1
- FUNC.SHEETS: unexpected_mismatch=1
- FUNC.IFNA: exact_typed_bit_match=2
- FUNC.RANK: exact_typed_bit_match=1
- FUNC.RANK.EQ: exact_typed_bit_match=1
- FUNC.RANK.AVG: exact_typed_bit_match=1
- FUNC.FORECAST: unexpected_mismatch=1
- FUNC.FORECAST.LINEAR: unexpected_mismatch=1
- FUNC.FREQUENCY: exact_typed_bit_match=1
- FUNC.PROB: exact_typed_bit_match=1

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
