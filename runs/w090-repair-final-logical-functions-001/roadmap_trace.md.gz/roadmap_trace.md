﻿# Array Support Roadmap Trace

- Run ID: w090-repair-final-logical-functions-001
- Tranche: w090-successor-logical-functions
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance.
- Surfaces executed: 2
- Formula cases executed: 6

## Axes touched

- Function family/category: Logical functions.
- Risk bands: high, medium.
- Array argument axes: one_array_arg:arg1, one_array_arg:arg2, one_array_arg:arg3.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.
- Scenario seed sources: docs\function-lane\W24_BATCH01_SWITCH_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W68_SCENARIO_MANIFEST_SEED.csv.

## Rollup

- exact_typed_bit_match: 6

## Function highlights

- FUNC.SWITCH: exact_typed_bit_match=3
- FUNC.IFS: exact_typed_bit_match=3

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
