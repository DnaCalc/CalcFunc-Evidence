﻿# Array Support Roadmap Trace

- Run ID: w092-scenario-statistical-cycle-001
- Tranche: w089-scenario-seed-statistical-functions
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance.
- Surfaces executed: 40
- Formula cases executed: 58

## Axes touched

- Function family/category: Statistical functions.
- Array argument axes: scenario_seed_literal_args.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.
- Scenario seed sources: docs\function-lane\W12_S1_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W24_BATCH05_CONFIDENCE_TEST_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W61_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W62_SCENARIO_MANIFEST_SEED.csv.

## Rollup

- exact_typed_bit_match: 34
- known_residual: 24
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.AVERAGE: exact_typed_bit_match=2
- FUNC.BETA.DIST: exact_typed_bit_match=2
- FUNC.BETA.INV: known_residual=1
- FUNC.BINOM.DIST: exact_typed_bit_match=2
- FUNC.BINOM.DIST.RANGE: exact_typed_bit_match=1
- FUNC.BINOM.INV: exact_typed_bit_match=1
- FUNC.CHISQ.DIST: known_residual=1, exact_typed_bit_match=1
- FUNC.CHISQ.DIST.RT: known_residual=1
- FUNC.CHISQ.INV: known_residual=1
- FUNC.CHISQ.INV.RT: known_residual=1
- FUNC.CONFIDENCE.NORM: exact_typed_bit_match=2
- FUNC.CONFIDENCE.T: known_residual=1, exact_typed_bit_match=2
- FUNC.COUNTA: exact_typed_bit_match=1
- FUNC.EXPON.DIST: exact_typed_bit_match=2
- FUNC.F.DIST: exact_typed_bit_match=2
- FUNC.F.DIST.RT: known_residual=1
- FUNC.F.INV: known_residual=1
- FUNC.F.INV.RT: known_residual=1
- FUNC.GAMMA.DIST: known_residual=1, exact_typed_bit_match=1
- FUNC.GAMMA.INV: known_residual=1
- FUNC.HYPGEOM.DIST: known_residual=1
- FUNC.KURT: known_residual=1
- FUNC.LOGNORM.DIST: exact_typed_bit_match=2
- FUNC.LOGNORM.INV: exact_typed_bit_match=1
- FUNC.NEGBINOM.DIST: exact_typed_bit_match=1
- FUNC.NORM.DIST: exact_typed_bit_match=1
- FUNC.NORM.INV: exact_typed_bit_match=1
- FUNC.NORM.S.DIST: known_residual=1
- FUNC.NORM.S.INV: known_residual=1, exact_typed_bit_match=1
- FUNC.POISSON.DIST: exact_typed_bit_match=2
- FUNC.SKEW: known_residual=1
- FUNC.SKEW.P: exact_typed_bit_match=1
- FUNC.STEYX: exact_typed_bit_match=1
- FUNC.T.DIST: known_residual=1
- FUNC.T.DIST.2T: known_residual=1, exact_typed_bit_match=1
- FUNC.T.DIST.RT: known_residual=1
- FUNC.T.INV: known_residual=1
- FUNC.T.INV.2T: known_residual=1
- FUNC.TRIMMEAN: exact_typed_bit_match=2
- FUNC.Z.TEST: known_residual=3, exact_typed_bit_match=1

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
