# Broad Scalar Explorer Trace

- Generated/evaluated locally: `1000000`
- Excel candidate samples selected: `600`
- Distinct coverage areas: `78886`
- Local throughput: `401172.08` cases/sec
