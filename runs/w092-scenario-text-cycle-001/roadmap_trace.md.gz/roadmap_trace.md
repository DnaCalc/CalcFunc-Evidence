﻿# Array Support Roadmap Trace

- Run ID: w092-scenario-text-cycle-001
- Tranche: w089-scenario-seed-text-functions
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance.
- Surfaces executed: 11
- Formula cases executed: 35

## Axes touched

- Function family/category: Text functions.
- Array argument axes: scenario_seed_literal_args.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.
- Scenario seed sources: docs\function-lane\STRING_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W12_S3_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W66_SCENARIO_MANIFEST_SEED.csv.

## Rollup

- exact_typed_bit_match: 35
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.CHAR: exact_typed_bit_match=5
- FUNC.CODE: exact_typed_bit_match=3
- FUNC.EXACT: exact_typed_bit_match=4
- FUNC.LOWER: exact_typed_bit_match=2
- FUNC.PROPER: exact_typed_bit_match=2
- FUNC.REPT: exact_typed_bit_match=5
- FUNC.SUBSTITUTE: exact_typed_bit_match=1
- FUNC.TEXTJOIN: exact_typed_bit_match=4
- FUNC.TRIM: exact_typed_bit_match=2
- FUNC.UNICHAR: exact_typed_bit_match=5
- FUNC.UPPER: exact_typed_bit_match=2

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
