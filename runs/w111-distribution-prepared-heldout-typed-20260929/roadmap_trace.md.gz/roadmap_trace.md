# Array Support Roadmap Trace

- Run ID: w111-distribution-prepared-heldout-typed-20260929
- Tranche: w111-distribution-prepared-heldout-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 26
- Formula cases executed: 2541

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: typed_argument.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 2255
- unexpected_mismatch: 146
- known_residual: 140
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.CONFIDENCE: exact_typed_bit_match=84
- FUNC.CONFIDENCE.NORM: exact_typed_bit_match=84
- FUNC.NORM.INV: exact_typed_bit_match=84
- FUNC.NORMINV: exact_typed_bit_match=84
- FUNC.NORM.S.INV: exact_typed_bit_match=25
- FUNC.NORMSINV: exact_typed_bit_match=25
- FUNC.NORMSDIST: exact_typed_bit_match=25
- FUNC.LOGNORM.INV: exact_typed_bit_match=84
- FUNC.LOGNORM.DIST: unexpected_mismatch=72, exact_typed_bit_match=64
- FUNC.LOGNORMDIST: exact_typed_bit_match=81, unexpected_mismatch=3
- FUNC.BINOM.DIST: exact_typed_bit_match=136
- FUNC.BINOMDIST: exact_typed_bit_match=136
- FUNC.BINOM.DIST.RANGE: unexpected_mismatch=59, exact_typed_bit_match=59
- FUNC.BINOM.INV: exact_typed_bit_match=81, unexpected_mismatch=3
- FUNC.CRITBINOM: exact_typed_bit_match=81, unexpected_mismatch=3
- FUNC.POISSON: exact_typed_bit_match=101, unexpected_mismatch=3
- FUNC.POISSON.DIST: exact_typed_bit_match=101, unexpected_mismatch=3
- FUNC.HYPGEOM.DIST: known_residual=86, exact_typed_bit_match=84
- FUNC.HYPGEOMDIST: known_residual=54, exact_typed_bit_match=62
- FUNC.NEGBINOM.DIST: exact_typed_bit_match=136
- FUNC.NEGBINOMDIST: exact_typed_bit_match=84
- FUNC.NORM.S.DIST: exact_typed_bit_match=74
- FUNC.NORM.DIST: exact_typed_bit_match=136
- FUNC.NORMDIST: exact_typed_bit_match=136
- FUNC.EXPON.DIST: exact_typed_bit_match=104
- FUNC.EXPONDIST: exact_typed_bit_match=104

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
