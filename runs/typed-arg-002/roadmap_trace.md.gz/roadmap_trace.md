# Array Support Roadmap Trace

- Run ID: typed-arg-002
- Tranche: typed-arg-probes-v0
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 53
- Formula cases executed: 53

## Axes touched

- Function family/category: Date and time functions, Engineering functions, Financial functions, Statistical functions.
- Array argument axes: typed_arg_probe.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- unexpected_mismatch: 15
- exact_typed_bit_match: 38
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.ACCRINT: unexpected_mismatch=1
- FUNC.ACCRINTM: exact_typed_bit_match=1
- FUNC.AMORDEGRC: exact_typed_bit_match=1
- FUNC.AMORLINC: exact_typed_bit_match=1
- FUNC.COUPDAYBS: exact_typed_bit_match=1
- FUNC.COUPDAYS: exact_typed_bit_match=1
- FUNC.COUPDAYSNC: exact_typed_bit_match=1
- FUNC.COUPNCD: exact_typed_bit_match=1
- FUNC.COUPNUM: exact_typed_bit_match=1
- FUNC.COUPPCD: exact_typed_bit_match=1
- FUNC.PRICE: exact_typed_bit_match=1
- FUNC.YIELD: unexpected_mismatch=1
- FUNC.PRICEDISC: exact_typed_bit_match=1
- FUNC.YIELDDISC: unexpected_mismatch=1
- FUNC.PRICEMAT: exact_typed_bit_match=1
- FUNC.YIELDMAT: unexpected_mismatch=1
- FUNC.DISC: exact_typed_bit_match=1
- FUNC.INTRATE: exact_typed_bit_match=1
- FUNC.RECEIVED: exact_typed_bit_match=1
- FUNC.DURATION: exact_typed_bit_match=1
- FUNC.MDURATION: exact_typed_bit_match=1
- FUNC.ODDFPRICE: unexpected_mismatch=1
- FUNC.ODDFYIELD: unexpected_mismatch=1
- FUNC.ODDLPRICE: exact_typed_bit_match=1
- FUNC.ODDLYIELD: exact_typed_bit_match=1
- FUNC.FV: exact_typed_bit_match=1
- FUNC.PV: exact_typed_bit_match=1
- FUNC.NPER: unexpected_mismatch=1
- FUNC.ISPMT: exact_typed_bit_match=1
- FUNC.CUMIPMT: exact_typed_bit_match=1
- FUNC.CUMPRINC: unexpected_mismatch=1
- FUNC.NPV: unexpected_mismatch=1
- FUNC.MIRR: exact_typed_bit_match=1
- FUNC.FVSCHEDULE: exact_typed_bit_match=1
- FUNC.XIRR: exact_typed_bit_match=1
- FUNC.XNPV: unexpected_mismatch=1
- FUNC.RRI: exact_typed_bit_match=1
- FUNC.PDURATION: exact_typed_bit_match=1
- FUNC.EFFECT: exact_typed_bit_match=1
- FUNC.NOMINAL: exact_typed_bit_match=1
- FUNC.DATEDIF: exact_typed_bit_match=1
- FUNC.DAYS360: exact_typed_bit_match=1
- FUNC.CHISQ.TEST: unexpected_mismatch=1
- FUNC.CHITEST: unexpected_mismatch=1
- FUNC.F.TEST: unexpected_mismatch=1
- FUNC.FTEST: unexpected_mismatch=1
- FUNC.T.TEST: exact_typed_bit_match=1
- FUNC.TTEST: exact_typed_bit_match=1
- FUNC.ZTEST: exact_typed_bit_match=1
- FUNC.WEIBULL: exact_typed_bit_match=1
- FUNC.WEIBULL.DIST: exact_typed_bit_match=1
- FUNC.CONVERT: unexpected_mismatch=1
- FUNC.PERCENTOF: exact_typed_bit_match=1

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
