# Array Support Roadmap Trace

- Run ID: w111-text-slice-numeric-boundaries-typed-20260929
- Tranche: w111-text-slice-numeric-boundaries-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 6
- Formula cases executed: 1888

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: text_count_binary_boundaries, text_mid_count_binary_boundaries, text_start_binary_boundaries.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 1360
- unexpected_mismatch: 528
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.LEFT: exact_typed_bit_match=139, unexpected_mismatch=97
- FUNC.RIGHT: exact_typed_bit_match=139, unexpected_mismatch=97
- FUNC.LEFTB: exact_typed_bit_match=139, unexpected_mismatch=97
- FUNC.RIGHTB: exact_typed_bit_match=139, unexpected_mismatch=97
- FUNC.MID: exact_typed_bit_match=402, unexpected_mismatch=70
- FUNC.MIDB: exact_typed_bit_match=402, unexpected_mismatch=70

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
