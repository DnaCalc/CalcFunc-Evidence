# Broad Scalar Explorer Trace

- Generated/evaluated locally: `2000000`
- Excel candidate samples selected: `600`
- Distinct coverage areas: `133714`
- Local throughput: `324608.61` cases/sec
