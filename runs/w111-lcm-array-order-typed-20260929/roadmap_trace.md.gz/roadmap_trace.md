# Array Support Roadmap Trace

- Run ID: w111-lcm-array-order-typed-20260929
- Tranche: w111-lcm-array-order-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 1
- Formula cases executed: 126

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: lcm_reduction_order.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- unexpected_mismatch: 70
- exact_typed_bit_match: 14
- local_harness_blocked: 42
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.LCM: unexpected_mismatch=70, exact_typed_bit_match=14, local_harness_blocked=42

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
