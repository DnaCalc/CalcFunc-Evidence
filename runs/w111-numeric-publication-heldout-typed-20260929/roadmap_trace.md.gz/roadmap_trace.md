# Array Support Roadmap Trace

- Run ID: w111-numeric-publication-heldout-typed-20260929
- Tranche: w111-numeric-publication-heldout-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 9
- Formula cases executed: 209

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: typed_argument.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 155
- excel_harness_blocked: 4
- unexpected_mismatch: 41
- known_residual: 9
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.SQRT: exact_typed_bit_match=10, excel_harness_blocked=1
- FUNC.PHI: exact_typed_bit_match=10, excel_harness_blocked=1
- FUNC.RADIANS: exact_typed_bit_match=10, excel_harness_blocked=1
- FUNC.SECH: exact_typed_bit_match=10, excel_harness_blocked=1
- FUNC.STANDARDIZE: exact_typed_bit_match=30, unexpected_mismatch=3
- FUNC.NORM.S.DIST: exact_typed_bit_match=13, known_residual=9
- FUNC.NORM.DIST: exact_typed_bit_match=24, unexpected_mismatch=20
- FUNC.EXPONDIST: exact_typed_bit_match=28, unexpected_mismatch=5
- FUNC.EXPON.DIST: exact_typed_bit_match=20, unexpected_mismatch=13

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
