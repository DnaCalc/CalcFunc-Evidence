# Array Support Roadmap Trace

- Run ID: w111-count-origin-typed-20260929
- Tranche: w111-count-origin-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 3
- Formula cases executed: 476

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: count_argument_origin, count_mixed_reference_scan.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 213
- unexpected_mismatch: 245
- excel_harness_blocked: 18
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.COUNT: exact_typed_bit_match=44, unexpected_mismatch=133
- FUNC.COUNTA: exact_typed_bit_match=136, unexpected_mismatch=41
- FUNC.COUNTBLANK: excel_harness_blocked=18, exact_typed_bit_match=33, unexpected_mismatch=71

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
