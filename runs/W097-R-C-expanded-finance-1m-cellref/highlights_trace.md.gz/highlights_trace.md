# Expanded Smart-Fuzzer Highlights

Run id: `W097-R-C-expanded-finance-1m-cellref`

## Counts

1. Local generated/evaluated cases: `1000000`
2. Excel candidate samples: `800`
3. Exact sample matches: `706`
4. Known residual PMT/PPMT/IPMT kernel-drift rows: `92`
5. Unexpected mismatches: `2`
6. Blocked sample rows: `0`

## Plumbing

Inputs are written through `Range.Value2` (bit-exact f64 round-trip) and the
formula references those cells; see
`smart-fuzzer/planning/EXCEL_RUNNER_PLUMBING_NOTE.md`. The legacy
`expected_formula_literal_encoding_drift` class no longer exists; rows that
would have landed there now resolve to `match` or to genuine kernel drift.

## Explored Areas

See `roadmap_trace.md` and `roadmap_trace.json` in this run directory. The run
covered PMT, PPMT, and IPMT across arity, rate, horizon, present/future value,
payment timing, and period-position bands.

## Interpretation

Known PMT/PPMT/IPMT non-zero-rate exactness drift is treated as expected pending
further investigation under BUG-FUNC-015. Unexpected mismatches, if any, are
written as failure packets under `failure_packets/`.
