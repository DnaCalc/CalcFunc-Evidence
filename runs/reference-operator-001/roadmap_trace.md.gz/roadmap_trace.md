# Array Support Roadmap Trace

- Run ID: reference-operator-001
- Tranche: reference-operator-probes-v0
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 4
- Formula cases executed: 4

## Axes touched

- Function family/category: Operators.
- Array argument axes: reference_operator_probe.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- unexpected_mismatch: 4
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.OP_RANGE_REF: unexpected_mismatch=1
- FUNC.OP_INTERSECTION_REF: unexpected_mismatch=1
- FUNC.OP_IMPLICIT_INTERSECTION: unexpected_mismatch=1
- FUNC.OP_SPILL_REF: unexpected_mismatch=1

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
