# Array Support Roadmap Trace

- Run ID: w111-numeric-to-text-heldout-typed-20260929
- Tranche: w111-numeric-to-text-heldout-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 15
- Formula cases executed: 8208

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: additional_formatter_consumer, address_formatter_binding, fresh_equality_control, fresh_number_to_text, number_array_origin, number_reference_origin.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 8208
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.LEFT: exact_typed_bit_match=2584
- FUNC.LEN: exact_typed_bit_match=2312
- FUNC.EXACT: exact_typed_bit_match=850
- FUNC.LEFTB: exact_typed_bit_match=211
- FUNC.RIGHTB: exact_typed_bit_match=211
- FUNC.MIDB: exact_typed_bit_match=211
- FUNC.LENB: exact_typed_bit_match=211
- FUNC.CONCATENATE: exact_typed_bit_match=211
- FUNC.UNICODE: exact_typed_bit_match=211
- FUNC.CODE: exact_typed_bit_match=211
- FUNC.FIND: exact_typed_bit_match=211
- FUNC.SEARCH: exact_typed_bit_match=211
- FUNC.REPLACE: exact_typed_bit_match=211
- FUNC.CONCAT: exact_typed_bit_match=272
- FUNC.ADDRESS: exact_typed_bit_match=80

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
