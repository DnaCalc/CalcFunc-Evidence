use crate::function::{
    Arity, CoercionLiftProfile, DeterminismClass, FecDependencyProfile, FunctionMeta,
    HostInteractionClass, KernelSignatureClass, ThreadSafetyClass, VolatilityClass,
};
use crate::functions::unary_numeric::{
    UnaryNumericExecSpec, UnaryNumericSurfaceError, eval_unary_numeric_via_executor,
    map_unary_numeric_error_to_ws,
};
use crate::resolver::ReferenceSystemProvider;
use crate::value::CalcValue;
use crate::value::WorksheetErrorCode;

pub const LOG10_META: FunctionMeta = function_spec! {
    function_id: "FUNC.LOG10",
    arity: Arity::exact(1),
    determinism: DeterminismClass::Deterministic,
    volatility: VolatilityClass::NonVolatile,
    host_interaction: HostInteractionClass::None,
    thread_safety: ThreadSafetyClass::SafePure,
    coercion_lift_profile: CoercionLiftProfile::UnaryNumericScalarOrArrayElementwise,
    kernel_signature_class: KernelSignatureClass::Custom,
    fec_dependency_profile: FecDependencyProfile::None,
    surface_fec_dependency_profile: FecDependencyProfile::RefOnly,
};

pub fn log10_kernel(n: f64) -> Result<f64, WorksheetErrorCode> {
    if n <= 0.0 {
        return Err(WorksheetErrorCode::Num);
    }
    // Excel's LOG10 is the x87 `fldlg2` + `fyl2x` fused op; match it bit-exact.
    Ok(crate::excel_numeric::excel_log10(n))
}

pub fn eval_log10_surface(
    args: &[crate::value::CalcValue],
    resolver: &(impl ReferenceSystemProvider + ?Sized),
) -> Result<CalcValue, UnaryNumericSurfaceError> {
    eval_unary_numeric_via_executor(
        args,
        resolver,
        UnaryNumericExecSpec::fallible(log10_kernel, LOG10_META.real_result_policy),
    )
}

pub fn map_log10_error_to_ws(e: &UnaryNumericSurfaceError) -> WorksheetErrorCode {
    map_unary_numeric_error_to_ws(e)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn log10_meta_function_id_is_stable() {
        assert_eq!(LOG10_META.function_id, "FUNC.LOG10");
    }

    #[test]
    fn log10_kernel_zero_is_num() {
        assert_eq!(log10_kernel(0.0), Err(WorksheetErrorCode::Num));
    }
}
