# Array Support Roadmap Trace

- Run ID: w111-logical-text-20260929
- Tranche: w111-logical-text-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 3
- Formula cases executed: 540

## Axes touched

- Function family/category: Logical functions.
- Array argument axes: logical_text_origin.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 540
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.AND: exact_typed_bit_match=180
- FUNC.OR: exact_typed_bit_match=180
- FUNC.XOR: exact_typed_bit_match=180

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
