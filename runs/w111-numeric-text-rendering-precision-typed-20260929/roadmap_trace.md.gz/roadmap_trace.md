# Array Support Roadmap Trace

- Run ID: w111-numeric-text-rendering-precision-typed-20260929
- Tranche: w111-numeric-text-rendering-precision-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 3
- Formula cases executed: 3204

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: initial_decimal_rounding_control, rational_midpoint_precision_discriminator.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 3156
- unexpected_mismatch: 48
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.LEFT: exact_typed_bit_match=1062, unexpected_mismatch=6
- FUNC.ADDRESS: exact_typed_bit_match=1062, unexpected_mismatch=6
- FUNC.ROUND: exact_typed_bit_match=1032, unexpected_mismatch=36

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
