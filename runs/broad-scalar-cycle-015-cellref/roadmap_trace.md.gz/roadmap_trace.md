# Broad Scalar Explorer Trace

- Generated/evaluated locally: `1000000`
- Excel candidate samples selected: `800`
- Distinct coverage areas: `78457`
- Local throughput: `389145.52` cases/sec
