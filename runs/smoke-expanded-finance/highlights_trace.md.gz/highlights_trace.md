﻿# Expanded Smart-Fuzzer Highlights

Run id: $RunId

## Counts

1. Local generated/evaluated cases: $CaseCount
2. Excel candidate samples: $(                                                               .Count)
3. Exact sample matches: $matches
4. Expected known financial exactness or literal-encoding deviations: $expectedKnown
5. Unexpected mismatches: $unexpected
6. Blocked sample rows: $blocked

## Explored Areas

See oadmap_trace.md and oadmap_trace.json in this run directory. The run
covered PMT, PPMT, and IPMT across arity, rate, horizon, present/future value,
payment timing, and period-position bands.

## Interpretation

Known PMT/PPMT/IPMT non-zero-rate exactness drift is treated as expected pending
further investigation. Tiny differences caused by formula literal decimal
encoding are tracked separately from repair-grade failures. Unexpected
mismatches, if any, are written as failure packets under ailure_packets/.
