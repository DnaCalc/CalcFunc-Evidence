﻿# Array Support Roadmap Trace

- Run ID: w092-max50-date-time-cycle-001
- Tranche: w089-scenario-seed-date-and-time-functions
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 10
- Formula cases executed: 40

## Axes touched

- Function family/category: Date and time functions.
- Array argument axes: scenario_seed_literal_args.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.
- Scenario seed sources: docs\function-lane\FORMAT_RENDER_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W12_S2_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W24_BATCH02_DATEVALUE_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W24_BATCH13_COUPON_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W27_BOND_ODD_BOND_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W63_SCENARIO_MANIFEST_SEED.csv, docs\function-lane\W64_SCENARIO_MANIFEST_SEED.csv.

## Rollup

- exact_typed_bit_match: 40
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.DATE: exact_typed_bit_match=28
- FUNC.DAY: exact_typed_bit_match=2
- FUNC.DAYS: exact_typed_bit_match=1
- FUNC.EDATE: exact_typed_bit_match=1
- FUNC.HOUR: exact_typed_bit_match=2
- FUNC.MINUTE: exact_typed_bit_match=1
- FUNC.MONTH: exact_typed_bit_match=1
- FUNC.SECOND: exact_typed_bit_match=1
- FUNC.TIME: exact_typed_bit_match=2
- FUNC.YEAR: exact_typed_bit_match=1

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
