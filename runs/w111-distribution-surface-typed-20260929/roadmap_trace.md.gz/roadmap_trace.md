# Array Support Roadmap Trace

- Run ID: w111-distribution-surface-typed-20260929
- Tranche: w111-distribution-surface-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 5
- Formula cases executed: 1083

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: typed_argument.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 1064
- local_harness_blocked: 16
- known_residual: 1
- unexpected_mismatch: 2
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.NORM.S.DIST: exact_typed_bit_match=162, local_harness_blocked=2, known_residual=1
- FUNC.NORM.DIST: exact_typed_bit_match=246, local_harness_blocked=4, unexpected_mismatch=1
- FUNC.NORMDIST: exact_typed_bit_match=246, local_harness_blocked=4, unexpected_mismatch=1
- FUNC.EXPON.DIST: exact_typed_bit_match=205, local_harness_blocked=3
- FUNC.EXPONDIST: exact_typed_bit_match=205, local_harness_blocked=3

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
