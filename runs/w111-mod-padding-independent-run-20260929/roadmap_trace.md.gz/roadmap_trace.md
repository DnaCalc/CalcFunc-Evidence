# Array Support Roadmap Trace

- Run ID: w111-mod-padding-independent-run-20260929
- Tranche: w111-mod-padding-heldout-20260929
- Comparison policy: exact typed equality with bit-exact numeric digests; no tolerance; known 1x1 publication seams and promoted residuals are classified separately.
- Surfaces executed: 1
- Formula cases executed: 288

## Axes touched

- Function family/category: typed_structural.
- Array argument axes: independent_omission_control, independent_positional_padding, independent_reference_padding, independent_unit_control.
- Shape/value pattern: inline array literals supplied by the case set, with exact Excel Formula2 spill capture.

## Rollup

- exact_typed_bit_match: 288
- axis witness pairs: total=0, differentiated=0, not_differentiated=0, blocked_or_incomplete=0

## Function highlights

- FUNC.MOD: exact_typed_bit_match=288

## Failure packet policy

Pass rows remain aggregate telemetry in comparisons.jsonl and rollup.json. Full per-case packets were written only for non-pass classifications.
